﻿using EcmaScript.NET;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebSiteCompiler
{
    public partial class MinifyFolderForm : Form
    {
        public MinifyFolderForm()
        {
            InitializeComponent();
            textBoxSourceFolderPath_TextChanged(this, null);
        }

        private void buttonBrowseFolder_Click(object sender, EventArgs e)
        {
            if (textBoxSourceFolderPath.Text.Length > 0)
            {
                minifyFolderBrowserDialog.SelectedPath = textBoxSourceFolderPath.Text;
            }
            if (minifyFolderBrowserDialog.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                // Clear the "min" subfolder
                textBoxSourceFolderPath.Text = minifyFolderBrowserDialog.SelectedPath;
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private int totalFileCount;
        private List<string> minifiedFileList = new List<string>();
        private List<string> failedToMinifyFileList = new List<string>();

        private void buttonMinify_Click(object sender, EventArgs e)
        {
            // Verify the source directory exists
            var sourceFolderPath = textBoxSourceFolderPath.Text;
            if (!Directory.Exists(sourceFolderPath))
            {
                MessageBox.Show("The folder \"" + sourceFolderPath + "\" does not exist.",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error,
                                MessageBoxDefaultButton.Button1);
                return;
            }

            var bMinifyResursively = checkBoxMinifyFolderRecursively.Checked;

            // File the total count of all files to be processed.
            //var htmlFiles = Directory.EnumerateFiles(sourceFolderPath, "*.html", bMinifyResursively ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
            var htmFiles = Directory.EnumerateFiles(sourceFolderPath, "*.htm", bMinifyResursively ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
            var aspxFiles = Directory.EnumerateFiles(sourceFolderPath, "*.aspx", bMinifyResursively ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
            var jsFiles = Directory.EnumerateFiles(sourceFolderPath, "*.js", bMinifyResursively ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
            var cssFiles = Directory.EnumerateFiles(sourceFolderPath, "*.css", bMinifyResursively ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);

            totalFileCount = htmFiles.Count() + aspxFiles.Count() + jsFiles.Count() + cssFiles.Count();
            if (totalFileCount == 0)
            {
                MessageBox.Show("The folder \"" + sourceFolderPath + "\" has no .html, .htm, .aspx files to minify.",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error,
                                MessageBoxDefaultButton.Button1);
                return;
            }

            labelProgress.Text = "Please wait..."; // String.Format("{0} of {1} files minified.", 0, totalFileCount);

            string minifyDestinationFolder = sourceFolderPath + "\\min";

            totalFileCount = 0;
            minifiedFileList.Clear();
            failedToMinifyFileList.Clear();
            MinifyFolder(sourceFolderPath, minifyDestinationFolder, bMinifyResursively,
                new List<string>() { ".html", ".htm", ".aspx", ".js", "css"}, 
                new List<string>() { "min", "scripts" } 
                );
            labelProgress.Text = "";

            if (failedToMinifyFileList.Count > 0)
            {
                string failedToMinifyFileListAsString = "";
                foreach (var fileName in failedToMinifyFileList)
                {
                    failedToMinifyFileListAsString += (fileName + System.Environment.NewLine);
                }

                MessageBox.Show(failedToMinifyFileList.Count() + " files failed to minify. " +
                                System.Environment.NewLine +
                                failedToMinifyFileListAsString,
                                    "Minification Completed With Error",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning,
                                    MessageBoxDefaultButton.Button1);
            }
            else
            {
                MessageBox.Show("\"" + sourceFolderPath + "\" has been minified. " +
                                System.Environment.NewLine + 
                                "Minified files can be found in \"" + minifyDestinationFolder + "\".",
                                    "Minification Completed Successfully",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information,
                                    MessageBoxDefaultButton.Button1);
            }
        }

        private void backgroundWorkerMinifyFolder_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void MinifyFolder(string sourceFolder, string destinationFolder, bool bMinifyResursively, List<string> fileExtensionsToMinify, List<string> folderNameToSkip)
        {
            DirectoryInfo dirInfoSourceFolder = new DirectoryInfo(sourceFolder);
            if (folderNameToSkip.Contains(dirInfoSourceFolder.Name.ToLower())) return;

            if (!Directory.Exists(destinationFolder))
                Directory.CreateDirectory(destinationFolder);

            string[] files = Directory.GetFiles(sourceFolder);
            foreach (string file in files)
            {
                if (fileExtensionsToMinify.Contains(Path.GetExtension(file)))
                {
                    string name = Path.GetFileName(file);
                    string dest = Path.Combine(destinationFolder, name);
                    if (!MinifyFile(file, dest))
                    {
                        failedToMinifyFileList.Add(Path.Combine(sourceFolder, name));
                    }
                }
            }

            if (bMinifyResursively)
            {
                string[] folders = Directory.GetDirectories(sourceFolder);
                foreach (string folder in folders)
                {
                    string name = Path.GetFileName(folder);
                    string dest = Path.Combine(destinationFolder, name);
                    MinifyFolder(folder, dest, bMinifyResursively, fileExtensionsToMinify, folderNameToSkip);
                }
            }
        }

        private bool MinifyFile(string sourceFile, string destinationFile)
        {
            bool bResult = false;
            bool jsCompressionFailureOccurred = false;
            FileInfo fileinf = new FileInfo(sourceFile);
            Yahoo.Yui.Compressor.JavaScriptCompressor jc = new Yahoo.Yui.Compressor.JavaScriptCompressor();
            if (string.Compare(fileinf.Extension, ".html", true) == 0 || string.Compare(fileinf.Extension, ".htm", true) == 0 || string.Compare(fileinf.Extension, ".aspx", true) == 0)
            {
                string html = File.ReadAllText(sourceFile);
                HtmlAgilityPack.HtmlDocument mDoc = new HtmlAgilityPack.HtmlDocument();
                mDoc.LoadHtml(html);

                // Javascript Minification
                foreach (HtmlAgilityPack.HtmlNode hn in GrandUnifier.GetScriptNodes(mDoc))
                {
                    string js = hn.InnerText;

                    // Make sure ASP content is always at index 1 after split.
                    if (js.StartsWith("<%"))
                        js += " ";

                    // Assume <% and %> always match
                    string[] jsSplitArray = js.Split(new string[] { "<%", "%>" }, StringSplitOptions.None);

                    StringBuilder stringBuilder = new StringBuilder(jsSplitArray[0]);
                    for (int i = 1; i < jsSplitArray.Length; i++)
                    {
                        if (i % 2 == 1)
                        {
                            stringBuilder.AppendFormat("ASP_BEGIN(ASP{0}+ASP_END)", i);
                        }
                        else
                        {
                            stringBuilder.Append(jsSplitArray[i]);
                        }
                    }

                    try
                    {
                        if (js.Length != 0) { js = jc.Compress(stringBuilder.ToString()); }


                        // Assume <% and %> always match
                        string[] compressedJsSplitArray = js.Split(new string[] { "ASP_BEGIN(ASP", "+ASP_END)" }, StringSplitOptions.None);

                        stringBuilder = new StringBuilder(compressedJsSplitArray[0]);
                        for (int i = 1; i < compressedJsSplitArray.Length; i++)
                        {
                            if (i % 2 == 1)
                            {
                                stringBuilder.AppendFormat("<%{0}%>", jsSplitArray[i]);  // ASP content is not compressed
                            }
                            else
                            {
                                stringBuilder.Append(compressedJsSplitArray[i]);
                            }
                        }
                        js = stringBuilder.ToString();

                        HtmlAgilityPack.HtmlNode nn = HtmlAgilityPack.HtmlNode.CreateNode("<script type=\"text/javascript\">" + js + "</script>");
                        hn.ParentNode.ReplaceChild(nn, hn); // Modify the HTML to inline the Java script
                    }
                    catch (EcmaScriptRuntimeException ex)
                    {
                        Console.WriteLine("File: " + sourceFile);
                        Console.WriteLine("Line " + ex.LineNumber + ": " + ex.LineSource);
                        jsCompressionFailureOccurred = true;
                    }
                    catch (Exception)
                    {
                        System.Diagnostics.Debugger.Break();
                        jsCompressionFailureOccurred = true;
                    }
                }

                // CSS Minification - Style Elements
                HtmlAgilityPack.HtmlNodeCollection nCollection = mDoc.DocumentNode.SelectNodes("//style");
                if (nCollection != null)
                {
                    foreach (HtmlAgilityPack.HtmlNode n in nCollection)
                    {
                        // Write back the minified CSS to the HTML document
                        HtmlAgilityPack.HtmlNode newCSSNode = HtmlAgilityPack.HtmlNode.CreateNode("<style>" + GrandUnifier.MinifyCSS(n.InnerText) + "</style>");
                        n.ParentNode.ReplaceChild(newCSSNode, n);
                    }
                }

                // CSS Minification - Style Attributes
                nCollection = mDoc.DocumentNode.SelectNodes("//@style");
                if (nCollection != null)
                {
                    foreach (HtmlAgilityPack.HtmlNode n in nCollection)
                    {
                        string css = n.GetAttributeValue("style", "");
                        css = GrandUnifier.MinifyCSS(css);
                        n.SetAttributeValue("style", css);
                    }
                }

                // HTML Minification
                ZetaHtmlCompressor.HtmlContentCompressor HtmlCompressor = new ZetaHtmlCompressor.HtmlContentCompressor();
                MemoryStream uncompressedStream = new MemoryStream();
                mDoc.Save(uncompressedStream);
                html = UTF8Encoding.UTF8.GetString(uncompressedStream.ToArray());
                html = HtmlCompressor.Compress(html);

                // Save the result
                File.WriteAllText(destinationFile, html);
                bResult = !jsCompressionFailureOccurred;
            }
            else if (string.Compare(fileinf.Extension, ".css", true) == 0)
            {
                string css = File.ReadAllText(sourceFile);
                GrandUnifier.MinifyCSS(css);
                File.WriteAllText(destinationFile, css);
                bResult = true;
            }
            else if (string.Compare(fileinf.Extension, ".js", true) == 0)
            {
                string js = File.ReadAllText(sourceFile);

                try
                {
                    js = jc.Compress(js);
                    File.WriteAllText(destinationFile, js);
                    bResult = true;
                }
                catch (EcmaScriptRuntimeException ex)
                {
                    Console.WriteLine("File: " + sourceFile);
                    Console.WriteLine("Line " + ex.LineNumber + ": " + ex.LineSource);
                }
            }

            return bResult;
        }

        private void textBoxSourceFolderPath_TextChanged(object sender, EventArgs e)
        {
            minifyButton.Enabled = Directory.Exists(textBoxSourceFolderPath.Text);
        }
    }
}
