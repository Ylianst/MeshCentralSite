﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace WebSiteCompiler
{
    public partial class EditFeaturesForm : Form
    {
        public EditFeaturesForm(string[] allfeatures, string[] selectedfeatures)
        {
            InitializeComponent();
            if (allfeatures == null || allfeatures.Length == 0)
            {
                noFeaturesLabel.Visible = true;
                featuresCheckedListBox.Visible = false;
            }
            else
            {
                noFeaturesLabel.Visible = false;
                featuresCheckedListBox.Visible = true;
                if (selectedfeatures == null) selectedfeatures = new string[0];
                foreach (string s in allfeatures) { featuresCheckedListBox.Items.Add(s, selectedfeatures.Contains(s)); }
            }
        }

        public string[] GetSelectedFeatures()
        {
            List<string> lst = new List<string>();
            foreach (string x in featuresCheckedListBox.CheckedItems) { lst.Add(x); }
            return lst.ToArray();
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }
    }
}
