﻿namespace WebSiteCompiler
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.targetContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editFeaturesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renameTargetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.duplicateTargetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeTargetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.addTargetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.treeImageList = new System.Windows.Forms.ImageList(this.components);
            this.mainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveConfigurationAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.generateSiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.minifyJavascriptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yahooToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closureBasicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closureAdvancedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closureAdvancedToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.deflateCompressionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.advancedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.highToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insaneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.minifyHTMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noneToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.zETAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zETAToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.inlineImagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.autogenerateOnChangeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.compileMultiLanguagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.includeWebServerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quickMinifyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.minifyFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputFolderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.outputSaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.configOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.configSaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.quickMinifyOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.generateTimer = new System.Windows.Forms.Timer(this.components);
            this.generateButton = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.variableNameTextBox = new System.Windows.Forms.TextBox();
            this.inputFolderTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.selectOutputPathButton = new System.Windows.Forms.Button();
            this.outputPathTextBox = new System.Windows.Forms.TextBox();
            this.selectInputFolderButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.mainTabControl = new System.Windows.Forms.TabControl();
            this.filesTabPage = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.outputListView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.outputContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.selectedToClipMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.javaScriptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.allToClipMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.javaScriptToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.featuresTabPage = new System.Windows.Forms.TabPage();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.editFeaturesButton = new System.Windows.Forms.Button();
            this.targetsTreeView = new System.Windows.Forms.TreeView();
            this.removeTargetButton = new System.Windows.Forms.Button();
            this.addTargetButton = new System.Windows.Forms.Button();
            this.securityTabPage = new System.Windows.Forms.TabPage();
            this.clearButton = new System.Windows.Forms.Button();
            this.eventsTextBox = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tabImageList = new System.Windows.Forms.ImageList(this.components);
            this.statusLabel = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.javaScriptEtagsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cEtagsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.javaScriptETagsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cEtagsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.targetContextMenuStrip.SuspendLayout();
            this.mainMenuStrip.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.mainTabControl.SuspendLayout();
            this.filesTabPage.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.outputContextMenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.featuresTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.securityTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // targetContextMenuStrip
            // 
            this.targetContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editFeaturesToolStripMenuItem,
            this.renameTargetToolStripMenuItem,
            this.duplicateTargetToolStripMenuItem,
            this.removeTargetToolStripMenuItem,
            this.toolStripMenuItem3,
            this.addTargetToolStripMenuItem});
            this.targetContextMenuStrip.Name = "targetContextMenuStrip";
            this.targetContextMenuStrip.Size = new System.Drawing.Size(169, 120);
            // 
            // editFeaturesToolStripMenuItem
            // 
            this.editFeaturesToolStripMenuItem.Name = "editFeaturesToolStripMenuItem";
            this.editFeaturesToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.editFeaturesToolStripMenuItem.Text = "&Edit Features...";
            this.editFeaturesToolStripMenuItem.Click += new System.EventHandler(this.editFeaturesButton_Click);
            // 
            // renameTargetToolStripMenuItem
            // 
            this.renameTargetToolStripMenuItem.Name = "renameTargetToolStripMenuItem";
            this.renameTargetToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.renameTargetToolStripMenuItem.Text = "R&ename Target...";
            this.renameTargetToolStripMenuItem.Click += new System.EventHandler(this.renameTargetToolStripMenuItem_Click);
            // 
            // duplicateTargetToolStripMenuItem
            // 
            this.duplicateTargetToolStripMenuItem.Name = "duplicateTargetToolStripMenuItem";
            this.duplicateTargetToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.duplicateTargetToolStripMenuItem.Text = "&Duplicate Target...";
            this.duplicateTargetToolStripMenuItem.Click += new System.EventHandler(this.duplicateTargetToolStripMenuItem_Click);
            // 
            // removeTargetToolStripMenuItem
            // 
            this.removeTargetToolStripMenuItem.Name = "removeTargetToolStripMenuItem";
            this.removeTargetToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.removeTargetToolStripMenuItem.Text = "&Remove Target";
            this.removeTargetToolStripMenuItem.Click += new System.EventHandler(this.removeTargetButton_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(165, 6);
            // 
            // addTargetToolStripMenuItem
            // 
            this.addTargetToolStripMenuItem.Name = "addTargetToolStripMenuItem";
            this.addTargetToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.addTargetToolStripMenuItem.Text = "Add &Target...";
            this.addTargetToolStripMenuItem.Click += new System.EventHandler(this.addTargetButton_Click);
            // 
            // treeImageList
            // 
            this.treeImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("treeImageList.ImageStream")));
            this.treeImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.treeImageList.Images.SetKeyName(0, "");
            this.treeImageList.Images.SetKeyName(1, "");
            this.treeImageList.Images.SetKeyName(2, "");
            this.treeImageList.Images.SetKeyName(3, "");
            this.treeImageList.Images.SetKeyName(4, "");
            this.treeImageList.Images.SetKeyName(5, "");
            this.treeImageList.Images.SetKeyName(6, "");
            this.treeImageList.Images.SetKeyName(7, "");
            this.treeImageList.Images.SetKeyName(8, "");
            this.treeImageList.Images.SetKeyName(9, "");
            this.treeImageList.Images.SetKeyName(10, "");
            this.treeImageList.Images.SetKeyName(11, "");
            this.treeImageList.Images.SetKeyName(12, "");
            this.treeImageList.Images.SetKeyName(13, "");
            this.treeImageList.Images.SetKeyName(14, "");
            this.treeImageList.Images.SetKeyName(15, "");
            this.treeImageList.Images.SetKeyName(16, "");
            this.treeImageList.Images.SetKeyName(17, "");
            this.treeImageList.Images.SetKeyName(18, "");
            this.treeImageList.Images.SetKeyName(19, "");
            this.treeImageList.Images.SetKeyName(20, "");
            this.treeImageList.Images.SetKeyName(21, "");
            this.treeImageList.Images.SetKeyName(22, "");
            this.treeImageList.Images.SetKeyName(23, "");
            this.treeImageList.Images.SetKeyName(24, "");
            this.treeImageList.Images.SetKeyName(25, "");
            this.treeImageList.Images.SetKeyName(26, "");
            this.treeImageList.Images.SetKeyName(27, "");
            // 
            // mainMenuStrip
            // 
            this.mainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.toolsToolStripMenuItem});
            this.mainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.mainMenuStrip.Name = "mainMenuStrip";
            this.mainMenuStrip.Size = new System.Drawing.Size(438, 24);
            this.mainMenuStrip.TabIndex = 7;
            this.mainMenuStrip.Text = "mainMenuStrip";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openConfigurationToolStripMenuItem,
            this.saveConfigurationToolStripMenuItem,
            this.saveConfigurationAsToolStripMenuItem,
            this.toolStripMenuItem1,
            this.generateSiteToolStripMenuItem,
            this.toolStripMenuItem2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            this.fileToolStripMenuItem.DropDownOpening += new System.EventHandler(this.fileToolStripMenuItem_DropDownOpening);
            // 
            // openConfigurationToolStripMenuItem
            // 
            this.openConfigurationToolStripMenuItem.Name = "openConfigurationToolStripMenuItem";
            this.openConfigurationToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.openConfigurationToolStripMenuItem.Text = "&Open Configuration...";
            this.openConfigurationToolStripMenuItem.Click += new System.EventHandler(this.loadButton_Click);
            // 
            // saveConfigurationToolStripMenuItem
            // 
            this.saveConfigurationToolStripMenuItem.Name = "saveConfigurationToolStripMenuItem";
            this.saveConfigurationToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.saveConfigurationToolStripMenuItem.Text = "&Save Configuration...";
            this.saveConfigurationToolStripMenuItem.Click += new System.EventHandler(this.saveConfigurationToolStripMenuItem_Click);
            // 
            // saveConfigurationAsToolStripMenuItem
            // 
            this.saveConfigurationAsToolStripMenuItem.Name = "saveConfigurationAsToolStripMenuItem";
            this.saveConfigurationAsToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.saveConfigurationAsToolStripMenuItem.Text = "&Save Configuration As...";
            this.saveConfigurationAsToolStripMenuItem.Click += new System.EventHandler(this.saveConfigurationAsToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(197, 6);
            // 
            // generateSiteToolStripMenuItem
            // 
            this.generateSiteToolStripMenuItem.Enabled = false;
            this.generateSiteToolStripMenuItem.Name = "generateSiteToolStripMenuItem";
            this.generateSiteToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.generateSiteToolStripMenuItem.Text = "Generate Site...";
            this.generateSiteToolStripMenuItem.Click += new System.EventHandler(this.generateButton_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(197, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.minifyJavascriptToolStripMenuItem,
            this.deflateCompressionToolStripMenuItem,
            this.minifyHTMLToolStripMenuItem,
            this.inlineImagesToolStripMenuItem,
            this.autogenerateOnChangeToolStripMenuItem,
            this.compileMultiLanguagesToolStripMenuItem,
            this.toolStripMenuItem5,
            this.includeWebServerToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.settingsToolStripMenuItem.Text = "&Settings";
            // 
            // minifyJavascriptToolStripMenuItem
            // 
            this.minifyJavascriptToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.noneToolStripMenuItem,
            this.yahooToolStripMenuItem,
            this.closureBasicToolStripMenuItem,
            this.closureAdvancedToolStripMenuItem,
            this.closureAdvancedToolStripMenuItem1});
            this.minifyJavascriptToolStripMenuItem.Name = "minifyJavascriptToolStripMenuItem";
            this.minifyJavascriptToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.minifyJavascriptToolStripMenuItem.Text = "Minify Javascript";
            // 
            // noneToolStripMenuItem
            // 
            this.noneToolStripMenuItem.Checked = true;
            this.noneToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.noneToolStripMenuItem.Name = "noneToolStripMenuItem";
            this.noneToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.noneToolStripMenuItem.Text = "None";
            this.noneToolStripMenuItem.Click += new System.EventHandler(this.noneToolStripMenuItem_Click);
            // 
            // yahooToolStripMenuItem
            // 
            this.yahooToolStripMenuItem.Name = "yahooToolStripMenuItem";
            this.yahooToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.yahooToolStripMenuItem.Text = "Yahoo";
            this.yahooToolStripMenuItem.Click += new System.EventHandler(this.yahooToolStripMenuItem_Click);
            // 
            // closureBasicToolStripMenuItem
            // 
            this.closureBasicToolStripMenuItem.Name = "closureBasicToolStripMenuItem";
            this.closureBasicToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.closureBasicToolStripMenuItem.Text = "Closure Basic";
            this.closureBasicToolStripMenuItem.Click += new System.EventHandler(this.closureBasicToolStripMenuItem_Click);
            // 
            // closureAdvancedToolStripMenuItem
            // 
            this.closureAdvancedToolStripMenuItem.Name = "closureAdvancedToolStripMenuItem";
            this.closureAdvancedToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.closureAdvancedToolStripMenuItem.Text = "Closure Advanced";
            this.closureAdvancedToolStripMenuItem.Click += new System.EventHandler(this.closureAdvancedToolStripMenuItem_Click);
            // 
            // closureAdvancedToolStripMenuItem1
            // 
            this.closureAdvancedToolStripMenuItem1.Name = "closureAdvancedToolStripMenuItem1";
            this.closureAdvancedToolStripMenuItem1.Size = new System.Drawing.Size(178, 22);
            this.closureAdvancedToolStripMenuItem1.Text = "Closure Advanced+";
            this.closureAdvancedToolStripMenuItem1.Click += new System.EventHandler(this.closureAdvancedToolStripMenuItem1_Click);
            // 
            // deflateCompressionToolStripMenuItem
            // 
            this.deflateCompressionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.normalToolStripMenuItem,
            this.advancedToolStripMenuItem,
            this.highToolStripMenuItem,
            this.insaneToolStripMenuItem});
            this.deflateCompressionToolStripMenuItem.Name = "deflateCompressionToolStripMenuItem";
            this.deflateCompressionToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.deflateCompressionToolStripMenuItem.Text = "Deflate Compression";
            // 
            // normalToolStripMenuItem
            // 
            this.normalToolStripMenuItem.Checked = true;
            this.normalToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.normalToolStripMenuItem.Name = "normalToolStripMenuItem";
            this.normalToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.normalToolStripMenuItem.Text = "Normal";
            this.normalToolStripMenuItem.Click += new System.EventHandler(this.normalToolStripMenuItem_Click);
            // 
            // advancedToolStripMenuItem
            // 
            this.advancedToolStripMenuItem.Name = "advancedToolStripMenuItem";
            this.advancedToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.advancedToolStripMenuItem.Text = "Advanced";
            this.advancedToolStripMenuItem.Click += new System.EventHandler(this.advancedToolStripMenuItem_Click);
            // 
            // highToolStripMenuItem
            // 
            this.highToolStripMenuItem.Name = "highToolStripMenuItem";
            this.highToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.highToolStripMenuItem.Text = "High";
            this.highToolStripMenuItem.Click += new System.EventHandler(this.highToolStripMenuItem_Click);
            // 
            // insaneToolStripMenuItem
            // 
            this.insaneToolStripMenuItem.Name = "insaneToolStripMenuItem";
            this.insaneToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.insaneToolStripMenuItem.Text = "Insane";
            this.insaneToolStripMenuItem.Click += new System.EventHandler(this.insaneToolStripMenuItem_Click);
            // 
            // minifyHTMLToolStripMenuItem
            // 
            this.minifyHTMLToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.noneToolStripMenuItem1,
            this.zETAToolStripMenuItem,
            this.zETAToolStripMenuItem1});
            this.minifyHTMLToolStripMenuItem.Name = "minifyHTMLToolStripMenuItem";
            this.minifyHTMLToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.minifyHTMLToolStripMenuItem.Text = "Minify HTML";
            // 
            // noneToolStripMenuItem1
            // 
            this.noneToolStripMenuItem1.Checked = true;
            this.noneToolStripMenuItem1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.noneToolStripMenuItem1.Name = "noneToolStripMenuItem1";
            this.noneToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.noneToolStripMenuItem1.Text = "None";
            this.noneToolStripMenuItem1.Click += new System.EventHandler(this.noneToolStripMenuItem1_Click);
            // 
            // zETAToolStripMenuItem
            // 
            this.zETAToolStripMenuItem.Name = "zETAToolStripMenuItem";
            this.zETAToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.zETAToolStripMenuItem.Text = "ZETA";
            this.zETAToolStripMenuItem.Click += new System.EventHandler(this.zETAToolStripMenuItem_Click);
            // 
            // zETAToolStripMenuItem1
            // 
            this.zETAToolStripMenuItem1.Name = "zETAToolStripMenuItem1";
            this.zETAToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.zETAToolStripMenuItem1.Text = "ZETA+";
            this.zETAToolStripMenuItem1.Click += new System.EventHandler(this.zETAToolStripMenuItem1_Click);
            // 
            // inlineImagesToolStripMenuItem
            // 
            this.inlineImagesToolStripMenuItem.Checked = true;
            this.inlineImagesToolStripMenuItem.CheckOnClick = true;
            this.inlineImagesToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.inlineImagesToolStripMenuItem.Name = "inlineImagesToolStripMenuItem";
            this.inlineImagesToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.inlineImagesToolStripMenuItem.Text = "Inline Images";
            // 
            // autogenerateOnChangeToolStripMenuItem
            // 
            this.autogenerateOnChangeToolStripMenuItem.Checked = true;
            this.autogenerateOnChangeToolStripMenuItem.CheckOnClick = true;
            this.autogenerateOnChangeToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.autogenerateOnChangeToolStripMenuItem.Name = "autogenerateOnChangeToolStripMenuItem";
            this.autogenerateOnChangeToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.autogenerateOnChangeToolStripMenuItem.Text = "Auto-generate on change";
            // 
            // compileMultiLanguagesToolStripMenuItem
            // 
            this.compileMultiLanguagesToolStripMenuItem.CheckOnClick = true;
            this.compileMultiLanguagesToolStripMenuItem.Name = "compileMultiLanguagesToolStripMenuItem";
            this.compileMultiLanguagesToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.compileMultiLanguagesToolStripMenuItem.Text = "Compile Multi-Languages";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(231, 6);
            // 
            // includeWebServerToolStripMenuItem
            // 
            this.includeWebServerToolStripMenuItem.CheckOnClick = true;
            this.includeWebServerToolStripMenuItem.Name = "includeWebServerToolStripMenuItem";
            this.includeWebServerToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.includeWebServerToolStripMenuItem.Text = "Embed Microstack Web Server";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quickMinifyToolStripMenuItem,
            this.minifyFolderToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.toolsToolStripMenuItem.Text = "&Tools";
            // 
            // quickMinifyToolStripMenuItem
            // 
            this.quickMinifyToolStripMenuItem.Name = "quickMinifyToolStripMenuItem";
            this.quickMinifyToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.quickMinifyToolStripMenuItem.Text = "&Minify File...";
            this.quickMinifyToolStripMenuItem.Click += new System.EventHandler(this.quickMinifyToolStripMenuItem_Click);
            // 
            // minifyFolderToolStripMenuItem
            // 
            this.minifyFolderToolStripMenuItem.Name = "minifyFolderToolStripMenuItem";
            this.minifyFolderToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.minifyFolderToolStripMenuItem.Text = "Minify &Folder...";
            this.minifyFolderToolStripMenuItem.Click += new System.EventHandler(this.minifyFolderToolStripMenuItem_Click);
            // 
            // outputSaveFileDialog
            // 
            this.outputSaveFileDialog.DefaultExt = "h";
            this.outputSaveFileDialog.Filter = "Header Files (*.h)|*.h|HTML Files (*.htm,*.html)|*.htm;*.html|GZIP Files (*.gz)|*" +
    ".gz|Brotli Files (*.br)|*.br|ASPX Files (*.aspx)|*.aspx|.JS Files (*.js)|*.js";
            this.outputSaveFileDialog.Title = "Generated Output File";
            // 
            // configOpenFileDialog
            // 
            this.configOpenFileDialog.DefaultExt = "wcc";
            this.configOpenFileDialog.Filter = "Website Compile Configuration Files (*.wcc)|*.wcc";
            this.configOpenFileDialog.Title = "Open Configuration";
            // 
            // configSaveFileDialog
            // 
            this.configSaveFileDialog.DefaultExt = "wcc";
            this.configSaveFileDialog.Filter = "Website Compiler Configuration Files (*.wcc)|*.wcc";
            this.configSaveFileDialog.Title = "Save Configuration";
            // 
            // quickMinifyOpenFileDialog
            // 
            this.quickMinifyOpenFileDialog.Filter = "Supported Files (*.html, *.htm, *.js, *.css, *.aspx)|*.html;*.html;*.js;*.css;*.a" +
    "spx";
            this.quickMinifyOpenFileDialog.Multiselect = true;
            // 
            // generateTimer
            // 
            this.generateTimer.Interval = 1000;
            this.generateTimer.Tick += new System.EventHandler(this.generateTimer_Tick);
            // 
            // generateButton
            // 
            this.generateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.generateButton.Enabled = false;
            this.generateButton.Location = new System.Drawing.Point(301, 439);
            this.generateButton.Name = "generateButton";
            this.generateButton.Size = new System.Drawing.Size(125, 23);
            this.generateButton.TabIndex = 11;
            this.generateButton.Text = "Generate...";
            this.generateButton.UseVisualStyleBackColor = true;
            this.generateButton.Click += new System.EventHandler(this.generateButton_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.variableNameTextBox);
            this.groupBox3.Controls.Add(this.inputFolderTextBox);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.selectOutputPathButton);
            this.groupBox3.Controls.Add(this.outputPathTextBox);
            this.groupBox3.Controls.Add(this.selectInputFolderButton);
            this.groupBox3.Location = new System.Drawing.Point(8, 44);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(354, 103);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Input && Output";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Output variable name";
            // 
            // variableNameTextBox
            // 
            this.variableNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.variableNameTextBox.Location = new System.Drawing.Point(147, 75);
            this.variableNameTextBox.Name = "variableNameTextBox";
            this.variableNameTextBox.Size = new System.Drawing.Size(202, 20);
            this.variableNameTextBox.TabIndex = 5;
            // 
            // inputFolderTextBox
            // 
            this.inputFolderTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.inputFolderTextBox.Location = new System.Drawing.Point(147, 19);
            this.inputFolderTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.inputFolderTextBox.Name = "inputFolderTextBox";
            this.inputFolderTextBox.ReadOnly = true;
            this.inputFolderTextBox.Size = new System.Drawing.Size(175, 20);
            this.inputFolderTextBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Output target";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Input web site folder";
            // 
            // selectOutputPathButton
            // 
            this.selectOutputPathButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.selectOutputPathButton.Location = new System.Drawing.Point(326, 47);
            this.selectOutputPathButton.Margin = new System.Windows.Forms.Padding(2);
            this.selectOutputPathButton.Name = "selectOutputPathButton";
            this.selectOutputPathButton.Size = new System.Drawing.Size(24, 20);
            this.selectOutputPathButton.TabIndex = 4;
            this.selectOutputPathButton.Text = "...";
            this.selectOutputPathButton.UseVisualStyleBackColor = true;
            this.selectOutputPathButton.Click += new System.EventHandler(this.pathButton_Click);
            // 
            // outputPathTextBox
            // 
            this.outputPathTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.outputPathTextBox.Location = new System.Drawing.Point(147, 47);
            this.outputPathTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.outputPathTextBox.Name = "outputPathTextBox";
            this.outputPathTextBox.ReadOnly = true;
            this.outputPathTextBox.Size = new System.Drawing.Size(175, 20);
            this.outputPathTextBox.TabIndex = 3;
            // 
            // selectInputFolderButton
            // 
            this.selectInputFolderButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.selectInputFolderButton.Location = new System.Drawing.Point(326, 19);
            this.selectInputFolderButton.Margin = new System.Windows.Forms.Padding(2);
            this.selectInputFolderButton.Name = "selectInputFolderButton";
            this.selectInputFolderButton.Size = new System.Drawing.Size(24, 20);
            this.selectInputFolderButton.TabIndex = 2;
            this.selectInputFolderButton.Text = "...";
            this.selectInputFolderButton.UseVisualStyleBackColor = true;
            this.selectInputFolderButton.Click += new System.EventHandler(this.SelectButton_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(367, 50);
            this.label1.TabIndex = 16;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = global::WebSiteCompiler.Properties.Resources.WebSiteCompiler;
            this.pictureBox1.Location = new System.Drawing.Point(385, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(41, 50);
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // mainTabControl
            // 
            this.mainTabControl.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.mainTabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mainTabControl.Controls.Add(this.filesTabPage);
            this.mainTabControl.Controls.Add(this.featuresTabPage);
            this.mainTabControl.Controls.Add(this.securityTabPage);
            this.mainTabControl.ImageList = this.tabImageList;
            this.mainTabControl.ItemSize = new System.Drawing.Size(50, 40);
            this.mainTabControl.Location = new System.Drawing.Point(11, 89);
            this.mainTabControl.Multiline = true;
            this.mainTabControl.Name = "mainTabControl";
            this.mainTabControl.SelectedIndex = 0;
            this.mainTabControl.Size = new System.Drawing.Size(415, 346);
            this.mainTabControl.TabIndex = 17;
            // 
            // filesTabPage
            // 
            this.filesTabPage.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.filesTabPage.Controls.Add(this.groupBox1);
            this.filesTabPage.Controls.Add(this.pictureBox4);
            this.filesTabPage.Controls.Add(this.label6);
            this.filesTabPage.Controls.Add(this.groupBox3);
            this.filesTabPage.ImageIndex = 5;
            this.filesTabPage.Location = new System.Drawing.Point(44, 4);
            this.filesTabPage.Name = "filesTabPage";
            this.filesTabPage.Size = new System.Drawing.Size(367, 338);
            this.filesTabPage.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.outputListView);
            this.groupBox1.Location = new System.Drawing.Point(8, 152);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(354, 183);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Generated Output";
            // 
            // outputListView
            // 
            this.outputListView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.outputListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.outputListView.ContextMenuStrip = this.outputContextMenuStrip;
            this.outputListView.FullRowSelect = true;
            this.outputListView.GridLines = true;
            this.outputListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.outputListView.Location = new System.Drawing.Point(8, 19);
            this.outputListView.Name = "outputListView";
            this.outputListView.Size = new System.Drawing.Size(340, 158);
            this.outputListView.SmallImageList = this.treeImageList;
            this.outputListView.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.outputListView.TabIndex = 0;
            this.outputListView.UseCompatibleStateImageBehavior = false;
            this.outputListView.View = System.Windows.Forms.View.Details;
            this.outputListView.SelectedIndexChanged += new System.EventHandler(this.outputListView_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            this.columnHeader1.Width = 154;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Minifyed";
            this.columnHeader2.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Compressed";
            this.columnHeader3.Width = 80;
            // 
            // outputContextMenuStrip
            // 
            this.outputContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selectedToClipMenuItem,
            this.toolStripSeparator1,
            this.allToClipMenuItem});
            this.outputContextMenuStrip.Name = "targetContextMenuStrip";
            this.outputContextMenuStrip.Size = new System.Drawing.Size(188, 76);
            this.outputContextMenuStrip.Opening += new System.ComponentModel.CancelEventHandler(this.outputContextMenuStrip_Opening);
            // 
            // selectedToClipMenuItem
            // 
            this.selectedToClipMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.javaScriptToolStripMenuItem,
            this.javaScriptETagsToolStripMenuItem1,
            this.cToolStripMenuItem,
            this.cEtagsToolStripMenuItem1});
            this.selectedToClipMenuItem.Name = "selectedToClipMenuItem";
            this.selectedToClipMenuItem.Size = new System.Drawing.Size(187, 22);
            this.selectedToClipMenuItem.Text = "&Selected to Clipboard";
            // 
            // javaScriptToolStripMenuItem
            // 
            this.javaScriptToolStripMenuItem.Name = "javaScriptToolStripMenuItem";
            this.javaScriptToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.javaScriptToolStripMenuItem.Text = "&JavaScript";
            this.javaScriptToolStripMenuItem.Click += new System.EventHandler(this.javaScriptToolStripMenuItem_Click);
            // 
            // cToolStripMenuItem
            // 
            this.cToolStripMenuItem.Name = "cToolStripMenuItem";
            this.cToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.cToolStripMenuItem.Text = "&C#";
            this.cToolStripMenuItem.Click += new System.EventHandler(this.cToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(184, 6);
            // 
            // allToClipMenuItem
            // 
            this.allToClipMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.javaScriptToolStripMenuItem1,
            this.javaScriptEtagsToolStripMenuItem,
            this.cToolStripMenuItem1,
            this.cEtagsToolStripMenuItem});
            this.allToClipMenuItem.Name = "allToClipMenuItem";
            this.allToClipMenuItem.Size = new System.Drawing.Size(187, 22);
            this.allToClipMenuItem.Text = "&All to Clipboard";
            // 
            // javaScriptToolStripMenuItem1
            // 
            this.javaScriptToolStripMenuItem1.Name = "javaScriptToolStripMenuItem1";
            this.javaScriptToolStripMenuItem1.Size = new System.Drawing.Size(168, 22);
            this.javaScriptToolStripMenuItem1.Text = "&JavaScript";
            this.javaScriptToolStripMenuItem1.Click += new System.EventHandler(this.javaScriptToolStripMenuItem1_Click);
            // 
            // cToolStripMenuItem1
            // 
            this.cToolStripMenuItem1.Name = "cToolStripMenuItem1";
            this.cToolStripMenuItem1.Size = new System.Drawing.Size(168, 22);
            this.cToolStripMenuItem1.Text = "&C#";
            this.cToolStripMenuItem1.Click += new System.EventHandler(this.cToolStripMenuItem1_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.pictureBox4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox4.Location = new System.Drawing.Point(0, 33);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(200, 2);
            this.pictureBox4.TabIndex = 14;
            this.pictureBox4.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(6, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "Files";
            // 
            // featuresTabPage
            // 
            this.featuresTabPage.BackColor = System.Drawing.SystemColors.Control;
            this.featuresTabPage.Controls.Add(this.pictureBox2);
            this.featuresTabPage.Controls.Add(this.label5);
            this.featuresTabPage.Controls.Add(this.editFeaturesButton);
            this.featuresTabPage.Controls.Add(this.targetsTreeView);
            this.featuresTabPage.Controls.Add(this.removeTargetButton);
            this.featuresTabPage.Controls.Add(this.addTargetButton);
            this.featuresTabPage.ImageIndex = 3;
            this.featuresTabPage.Location = new System.Drawing.Point(44, 4);
            this.featuresTabPage.Name = "featuresTabPage";
            this.featuresTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.featuresTabPage.Size = new System.Drawing.Size(367, 338);
            this.featuresTabPage.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(0, 33);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(200, 2);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(6, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Features";
            // 
            // editFeaturesButton
            // 
            this.editFeaturesButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.editFeaturesButton.Enabled = false;
            this.editFeaturesButton.Location = new System.Drawing.Point(34, 309);
            this.editFeaturesButton.Name = "editFeaturesButton";
            this.editFeaturesButton.Size = new System.Drawing.Size(105, 23);
            this.editFeaturesButton.TabIndex = 8;
            this.editFeaturesButton.Text = "Edit Features...";
            this.editFeaturesButton.UseVisualStyleBackColor = true;
            this.editFeaturesButton.Click += new System.EventHandler(this.editFeaturesButton_Click);
            // 
            // targetsTreeView
            // 
            this.targetsTreeView.AllowDrop = true;
            this.targetsTreeView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.targetsTreeView.ContextMenuStrip = this.targetContextMenuStrip;
            this.targetsTreeView.Enabled = false;
            this.targetsTreeView.ImageIndex = 0;
            this.targetsTreeView.ImageList = this.treeImageList;
            this.targetsTreeView.Location = new System.Drawing.Point(11, 40);
            this.targetsTreeView.Margin = new System.Windows.Forms.Padding(2);
            this.targetsTreeView.Name = "targetsTreeView";
            this.targetsTreeView.SelectedImageIndex = 0;
            this.targetsTreeView.Size = new System.Drawing.Size(351, 264);
            this.targetsTreeView.TabIndex = 5;
            this.targetsTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.targetsTreeView_AfterSelect);
            // 
            // removeTargetButton
            // 
            this.removeTargetButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.removeTargetButton.Enabled = false;
            this.removeTargetButton.Location = new System.Drawing.Point(145, 309);
            this.removeTargetButton.Name = "removeTargetButton";
            this.removeTargetButton.Size = new System.Drawing.Size(105, 23);
            this.removeTargetButton.TabIndex = 7;
            this.removeTargetButton.Text = "Remove Target";
            this.removeTargetButton.UseVisualStyleBackColor = true;
            this.removeTargetButton.Click += new System.EventHandler(this.removeTargetButton_Click);
            // 
            // addTargetButton
            // 
            this.addTargetButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.addTargetButton.Location = new System.Drawing.Point(256, 309);
            this.addTargetButton.Name = "addTargetButton";
            this.addTargetButton.Size = new System.Drawing.Size(105, 23);
            this.addTargetButton.TabIndex = 6;
            this.addTargetButton.Text = "Add Target...";
            this.addTargetButton.UseVisualStyleBackColor = true;
            this.addTargetButton.Click += new System.EventHandler(this.addTargetButton_Click);
            // 
            // securityTabPage
            // 
            this.securityTabPage.BackColor = System.Drawing.SystemColors.Control;
            this.securityTabPage.Controls.Add(this.clearButton);
            this.securityTabPage.Controls.Add(this.eventsTextBox);
            this.securityTabPage.Controls.Add(this.pictureBox3);
            this.securityTabPage.Controls.Add(this.label11);
            this.securityTabPage.ImageIndex = 2;
            this.securityTabPage.Location = new System.Drawing.Point(44, 4);
            this.securityTabPage.Name = "securityTabPage";
            this.securityTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.securityTabPage.Size = new System.Drawing.Size(367, 338);
            this.securityTabPage.TabIndex = 1;
            // 
            // clearButton
            // 
            this.clearButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.clearButton.Location = new System.Drawing.Point(256, 309);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(105, 23);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // eventsTextBox
            // 
            this.eventsTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.eventsTextBox.BackColor = System.Drawing.Color.White;
            this.eventsTextBox.Location = new System.Drawing.Point(11, 41);
            this.eventsTextBox.Multiline = true;
            this.eventsTextBox.Name = "eventsTextBox";
            this.eventsTextBox.ReadOnly = true;
            this.eventsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.eventsTextBox.Size = new System.Drawing.Size(350, 262);
            this.eventsTextBox.TabIndex = 8;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.pictureBox3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox3.Location = new System.Drawing.Point(0, 33);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(200, 2);
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(6, 5);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 25);
            this.label11.TabIndex = 4;
            this.label11.Text = "Events";
            // 
            // tabImageList
            // 
            this.tabImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("tabImageList.ImageStream")));
            this.tabImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.tabImageList.Images.SetKeyName(0, "ArrowWorld.png");
            this.tabImageList.Images.SetKeyName(1, "Computer.png");
            this.tabImageList.Images.SetKeyName(2, "DocumentFolder.png");
            this.tabImageList.Images.SetKeyName(3, "FindComputer.png");
            this.tabImageList.Images.SetKeyName(4, "Firewall.png");
            this.tabImageList.Images.SetKeyName(5, "FloppyDisk.png");
            // 
            // statusLabel
            // 
            this.statusLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.statusLabel.Location = new System.Drawing.Point(9, 444);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(284, 13);
            this.statusLabel.TabIndex = 11;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox5.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.pictureBox5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox5.Location = new System.Drawing.Point(14, 85);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(411, 2);
            this.pictureBox5.TabIndex = 18;
            this.pictureBox5.TabStop = false;
            // 
            // javaScriptEtagsToolStripMenuItem
            // 
            this.javaScriptEtagsToolStripMenuItem.Name = "javaScriptEtagsToolStripMenuItem";
            this.javaScriptEtagsToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.javaScriptEtagsToolStripMenuItem.Text = "JavaScript + etags";
            this.javaScriptEtagsToolStripMenuItem.Click += new System.EventHandler(this.javaScriptEtagsToolStripMenuItem_Click);
            // 
            // cEtagsToolStripMenuItem
            // 
            this.cEtagsToolStripMenuItem.Name = "cEtagsToolStripMenuItem";
            this.cEtagsToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.cEtagsToolStripMenuItem.Text = "C# + etags";
            this.cEtagsToolStripMenuItem.Click += new System.EventHandler(this.cEtagsToolStripMenuItem_Click);
            // 
            // javaScriptETagsToolStripMenuItem1
            // 
            this.javaScriptETagsToolStripMenuItem1.Name = "javaScriptETagsToolStripMenuItem1";
            this.javaScriptETagsToolStripMenuItem1.Size = new System.Drawing.Size(168, 22);
            this.javaScriptETagsToolStripMenuItem1.Text = "JavaScript + etags";
            this.javaScriptETagsToolStripMenuItem1.Click += new System.EventHandler(this.javaScriptETagsToolStripMenuItem1_Click);
            // 
            // cEtagsToolStripMenuItem1
            // 
            this.cEtagsToolStripMenuItem1.Name = "cEtagsToolStripMenuItem1";
            this.cEtagsToolStripMenuItem1.Size = new System.Drawing.Size(168, 22);
            this.cEtagsToolStripMenuItem1.Text = "C# + etags";
            this.cEtagsToolStripMenuItem1.Click += new System.EventHandler(this.cEtagsToolStripMenuItem1_Click);
            // 
            // MainForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 467);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.mainTabControl);
            this.Controls.Add(this.generateButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.mainMenuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mainMenuStrip;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "Web Site Compiler";
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.targetsTreeView_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.targetsTreeView_DragEnter);
            this.targetContextMenuStrip.ResumeLayout(false);
            this.mainMenuStrip.ResumeLayout(false);
            this.mainMenuStrip.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.mainTabControl.ResumeLayout(false);
            this.filesTabPage.ResumeLayout(false);
            this.filesTabPage.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.outputContextMenuStrip.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.featuresTabPage.ResumeLayout(false);
            this.featuresTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.securityTabPage.ResumeLayout(false);
            this.securityTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip mainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openConfigurationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveConfigurationToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem generateSiteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem minifyJavascriptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem minifyHTMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inlineImagesToolStripMenuItem;
        private System.Windows.Forms.FolderBrowserDialog inputFolderBrowserDialog;
        private System.Windows.Forms.SaveFileDialog outputSaveFileDialog;
        private System.Windows.Forms.OpenFileDialog configOpenFileDialog;
        private System.Windows.Forms.SaveFileDialog configSaveFileDialog;
        private System.Windows.Forms.ContextMenuStrip targetContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem addTargetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeTargetToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem saveConfigurationAsToolStripMenuItem;
        private System.Windows.Forms.ImageList treeImageList;
        private System.Windows.Forms.ToolStripMenuItem editFeaturesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem includeWebServerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quickMinifyToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog quickMinifyOpenFileDialog;
        private System.Windows.Forms.ToolStripMenuItem minifyFolderToolStripMenuItem;
        private System.Windows.Forms.Timer generateTimer;
        private System.Windows.Forms.ToolStripMenuItem autogenerateOnChangeToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button generateButton;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox variableNameTextBox;
        private System.Windows.Forms.TextBox inputFolderTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button selectOutputPathButton;
        private System.Windows.Forms.TextBox outputPathTextBox;
        private System.Windows.Forms.Button selectInputFolderButton;
        private System.Windows.Forms.TabControl mainTabControl;
        private System.Windows.Forms.TabPage featuresTabPage;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button editFeaturesButton;
        private System.Windows.Forms.TreeView targetsTreeView;
        private System.Windows.Forms.Button removeTargetButton;
        private System.Windows.Forms.Button addTargetButton;
        private System.Windows.Forms.TabPage securityTabPage;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.TextBox eventsTextBox;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage filesTabPage;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.ImageList tabImageList;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListView outputListView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ToolStripMenuItem noneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yahooToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closureBasicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closureAdvancedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deflateCompressionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem advancedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insaneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem duplicateTargetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem highToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem renameTargetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noneToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem zETAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zETAToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem closureAdvancedToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip outputContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem selectedToClipMenuItem;
        private System.Windows.Forms.ToolStripMenuItem javaScriptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem allToClipMenuItem;
        private System.Windows.Forms.ToolStripMenuItem javaScriptToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem compileMultiLanguagesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem javaScriptETagsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cEtagsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem javaScriptEtagsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cEtagsToolStripMenuItem;
    }
}

