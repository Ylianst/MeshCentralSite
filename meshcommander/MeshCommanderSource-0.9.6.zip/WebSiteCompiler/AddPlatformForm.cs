﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebSiteCompiler
{
    public partial class AddPlatformForm : Form
    {
        public AddPlatformForm() { InitializeComponent(); }
        public string TargetName { get { return targetTextBox.Text; } set { targetTextBox.Text = value; } }
        private void targetTextBox_TextChanged(object sender, EventArgs e) { okButton.Enabled = targetTextBox.Text.Length > 0; }
        private void okButton_Click(object sender, EventArgs e) { DialogResult = System.Windows.Forms.DialogResult.OK; }
        private void cancelButton_Click(object sender, EventArgs e) { DialogResult = System.Windows.Forms.DialogResult.Cancel; }
    }
}
