﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebSiteCompiler
{
    public class Permutation<T>
    {
        public delegate void PermutationHandler(T[] definedValues, T[] undefinedValues);
        public static void Permutate(PermutationHandler callback, params T[] values)
        {
            int num = (int)Math.Pow(2, values.Length);
            for (int i = 0; i < num; ++i)
            {
                List<T> valueList = new List<T>();
                List<T> undefList = new List<T>();
                for (int v = 0; v < values.Length; ++v)
                {
                    int val = (int)Math.Pow(2, v);
                    if ((i & val) == val)
                    {
                        valueList.Add(values[v]);
                    }
                    else
                    {
                        undefList.Add(values[v]);
                    }
                }
                callback(valueList.ToArray(), undefList.ToArray());
            }
        }
    }
}
