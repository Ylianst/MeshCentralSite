﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Data;
using System.Drawing;
using System.Threading;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Collections.Generic;
using EcmaScript.NET;

namespace WebSiteCompiler
{
    public partial class MainForm : Form
    {
        private GrandUnifier mUnifier = null;
        private Hashtable configurationTable = new Hashtable();
        private string[] features = null;
        private string title = null;
        private List<FileSystemWatcher> watchers = new List<FileSystemWatcher>();
        private int generateInSeconds = 2;
        public static MainForm Main = null;

        public MainForm(Hashtable newConfiguration = null)
        {
            InitializeComponent();
            Main = this;
            title = this.Text;
            statusLabel.Text = "v" + Application.ProductVersion;

            /*
            byte[] comment = new byte[6];
            comment[0] = 0x66;
            comment[1] = 0x66;
            comment[2] = 0x66;
            comment[3] = 0x66;
            comment[4] = 0x66;
            comment[5] = 0x66;
            bool r = GrandUnifier.SetGZipComment("C:\\Users\\Default.DESKTOP-9CGK2DI\\Desktop\\AmtWebApp\\ManageabilityCommander\\Firmware\\AmtFirmware-Default.gz", "C:\\Temp\\x.gz", comment);
            byte[] comment2 = GrandUnifier.GetGZipComment("C:\\Temp\\x.gz");
            */

            if (newConfiguration != null)
            {
                configurationTable = newConfiguration;
                ReadUIFromTable();

                if(configurationTable.ContainsKey("WebSitePath"))
                {
                    inputFolderBrowserDialog.SelectedPath = (string)configurationTable["WebSitePath"];
                    mUnifier = new GrandUnifier(new DirectoryInfo(inputFolderBrowserDialog.SelectedPath));
                    features = mUnifier.GetFeatures();
                    targetsTreeView.Enabled = true;
                }
            }
            outputContextMenuStrip_Opening(this, null);
        }

        private void SelectButton_Click(object sender, EventArgs e)
        {         
            if (inputFolderBrowserDialog.ShowDialog(this) == DialogResult.OK)
            {
                StopWatch();
                inputFolderTextBox.Text = inputFolderBrowserDialog.SelectedPath;
                generateButton.Enabled = generateSiteToolStripMenuItem.Enabled = true;
                mUnifier = new GrandUnifier(new DirectoryInfo(inputFolderBrowserDialog.SelectedPath));
                configurationTable["WebSitePath"] = inputFolderBrowserDialog.SelectedPath;
                features = mUnifier.GetFeatures();
                targetsTreeView.Enabled = true;
                StartWatch(inputFolderBrowserDialog.SelectedPath);
            }
        }
        private void SaveUIToTable(bool relativePaths)
        {
            if (mUnifier == null) return;

            configurationTable.Clear();
            configurationTable["ConfigurationFile"] = configSaveFileDialog.FileName;
            if (relativePaths)
            {
                configurationTable["WebSitePath"] = MakeRelativePath(mUnifier.websiteInfo.FullName, new FileInfo(configSaveFileDialog.FileName).Directory.FullName + "\\");
                configurationTable["Output"] = MakeRelativePath(outputPathTextBox.Text, new FileInfo(configSaveFileDialog.FileName).Directory.FullName + "\\");
            }
            else
            {
                configurationTable["WebSitePath"] = mUnifier.websiteInfo.FullName;
                configurationTable["Output"] = outputPathTextBox.Text;
            }

            if (noneToolStripMenuItem.Checked) configurationTable["JSSCompression"] = 0;
            else if (yahooToolStripMenuItem.Checked) configurationTable["JSSCompression"] = 1;
            else if (closureBasicToolStripMenuItem.Checked) configurationTable["JSSCompression"] = 2;
            else if (closureAdvancedToolStripMenuItem.Checked) configurationTable["JSSCompression"] = 3;
            else if (closureAdvancedToolStripMenuItem1.Checked) configurationTable["JSSCompression"] = 4;

            if (normalToolStripMenuItem.Checked) configurationTable["GZIPCompression"] = 0;
            else if (advancedToolStripMenuItem.Checked) configurationTable["GZIPCompression"] = 1;
            else if (highToolStripMenuItem.Checked) configurationTable["GZIPCompression"] = 2;
            else if (insaneToolStripMenuItem.Checked) configurationTable["GZIPCompression"] = 3;

            if (noneToolStripMenuItem1.Checked) configurationTable["HTMLCompression2"] = 0;
            else if (zETAToolStripMenuItem.Checked) configurationTable["HTMLCompression2"] = 1;
            else if (zETAToolStripMenuItem1.Checked) configurationTable["HTMLCompression2"] = 2;

            configurationTable["InlineImages"] = inlineImagesToolStripMenuItem.Checked;
            configurationTable["EmbedWebServer"] = includeWebServerToolStripMenuItem.Checked;
            configurationTable["AutoGen"] = autogenerateOnChangeToolStripMenuItem.Checked;
            configurationTable["MultiLang"] = compileMultiLanguagesToolStripMenuItem.Checked;
            configurationTable["VariableName"] = variableNameTextBox.Text != "" ? variableNameTextBox.Text : "html";

            List<string> features2 = new List<string>();
            foreach (string s in features) { features2.Add(s); }
            configurationTable["FeatureList"] = features2;

            List<Tuple<string, List<string>>> platforms = new List<Tuple<string, List<string>>>();
            foreach (TreeNode n in targetsTreeView.Nodes)
            {
                List<string> addedFeatures = new List<string>();
                foreach (TreeNode sn in n.Nodes) { addedFeatures.Add(sn.Text); }
                platforms.Add(Tuple.Create<string, List<string>>(n.Text, addedFeatures));
            }
            configurationTable["PlatformTree"] = platforms;
        }

        private void ReadUIFromTable()
        {
            targetsTreeView.Nodes.Clear();

            // Check the input path
            if (Directory.Exists((string)configurationTable["WebSitePath"]))
            {
                mUnifier = new GrandUnifier(new DirectoryInfo((string)configurationTable["WebSitePath"]));
                features = mUnifier.GetFeatures();
            }
            else
            {
                inputFolderBrowserDialog.Description = "Invalid Input Path, please update the input path:";
                StopWatch();
                if (inputFolderBrowserDialog.ShowDialog(this) == DialogResult.OK)
                {
                    inputFolderTextBox.Text = inputFolderBrowserDialog.SelectedPath;
                    generateButton.Enabled = generateSiteToolStripMenuItem.Enabled = true;
                    configurationTable["WebSitePath"] = inputFolderTextBox.Text = inputFolderBrowserDialog.SelectedPath;
                    mUnifier = new GrandUnifier(new DirectoryInfo(inputFolderBrowserDialog.SelectedPath));
                    features = mUnifier.GetFeatures();
                }
                targetsTreeView.Enabled = true;
                inputFolderBrowserDialog.Description = "";
            }
            inputFolderTextBox.Text = (string)configurationTable["WebSitePath"];
            StartWatch(inputFolderTextBox.Text);

            // Check the output path
            string outputpath = configurationTable.ContainsKey("Output") ? (string)configurationTable["Output"] : "";
            if (outputpath.Length > 0)
            {
                try
                {
                    FileInfo f = new FileInfo(outputpath);
                    if (f.Directory.Exists == false) outputpath = "";
                }
                catch (Exception) { outputpath = ""; }
            }
            outputPathTextBox.Text = outputpath;

            // Set the configuration file name and title
            if (File.Exists((string)configurationTable["ConfigurationFile"]))
            {
                configSaveFileDialog.FileName = (string)configurationTable["ConfigurationFile"];
                this.Text = title + " - " + new FileInfo(configSaveFileDialog.FileName).Name;
            }

            // Setup all of the menu settings

            if (!configurationTable.ContainsKey("JSSCompression")) { configurationTable["JSSCompression"] = 0; }
            noneToolStripMenuItem.Checked = ((int)configurationTable["JSSCompression"] == 0);
            yahooToolStripMenuItem.Checked = ((int)configurationTable["JSSCompression"] == 1);
            closureBasicToolStripMenuItem.Checked = ((int)configurationTable["JSSCompression"] == 2);
            closureAdvancedToolStripMenuItem.Checked = ((int)configurationTable["JSSCompression"] == 3);
            closureAdvancedToolStripMenuItem1.Checked = ((int)configurationTable["JSSCompression"] == 4);

            if (!configurationTable.ContainsKey("GZIPCompression")) { configurationTable["GZIPCompression"] = 0; }
            normalToolStripMenuItem.Checked = ((int)configurationTable["GZIPCompression"] == 0);
            advancedToolStripMenuItem.Checked = ((int)configurationTable["GZIPCompression"] == 1);
            highToolStripMenuItem.Checked = ((int)configurationTable["GZIPCompression"] == 2);
            insaneToolStripMenuItem.Checked = ((int)configurationTable["GZIPCompression"] == 3);

            if (!configurationTable.ContainsKey("HTMLCompression2")) { configurationTable["HTMLCompression2"] = 0; }
            noneToolStripMenuItem1.Checked = ((int)configurationTable["HTMLCompression2"] == 0);
            zETAToolStripMenuItem.Checked = ((int)configurationTable["HTMLCompression2"] == 1);
            zETAToolStripMenuItem1.Checked = ((int)configurationTable["HTMLCompression2"] == 2);

            inlineImagesToolStripMenuItem.Checked = configurationTable.ContainsKey("InlineImages") ? (bool)configurationTable["InlineImages"] : false;
            includeWebServerToolStripMenuItem.Checked = configurationTable.ContainsKey("EmbedWebServer")?(bool)configurationTable["EmbedWebServer"]:false;
            autogenerateOnChangeToolStripMenuItem.Checked = configurationTable.ContainsKey("AutoGen") ? (bool)configurationTable["AutoGen"] : false;
            compileMultiLanguagesToolStripMenuItem.Checked = configurationTable.ContainsKey("MultiLang") ? (bool)configurationTable["MultiLang"] : false;

            variableNameTextBox.Text = configurationTable.ContainsKey("VariableName") ? (string)configurationTable["VariableName"] : "";

            if (configurationTable["PlatformTree"] != null)
            {
                foreach (Tuple<string, List<string>> platform in (List<Tuple<string, List<string>>>)configurationTable["PlatformTree"])
                {
                    TreeNode p = new TreeNode(platform.Item1, 2, 2);
                    foreach (string f in platform.Item2) { if (features != null && features.Contains(f)) { AddTreeNodeSorted(p, new TreeNode(f, 3, 3)); } }
                    AddTreeNodeSorted(targetsTreeView, p);
                }
            }

            targetsTreeView.ExpandAll();
            targetsTreeView.Enabled = true;
            generateButton.Enabled = generateSiteToolStripMenuItem.Enabled = true;
        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            if (configOpenFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                using (Stream s = configOpenFileDialog.OpenFile())
                {
                    System.Runtime.Serialization.Formatters.Binary.BinaryFormatter bf = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    configurationTable = (Hashtable)bf.Deserialize(s);
                    configurationTable["ConfigurationFile"] = configOpenFileDialog.FileName;
                    configurationTable["WebSitePath"] = MakeAbsolutePath(new FileInfo(configOpenFileDialog.FileName).Directory.FullName, (string)configurationTable["WebSitePath"]);
                    configurationTable["Output"] = MakeAbsolutePath(new FileInfo(configOpenFileDialog.FileName).Directory.FullName, (string)configurationTable["Output"]);
                }
                outputListView.Items.Clear();
                outputContextMenuStrip_Opening(this, null);
                eventsTextBox.Clear();
                ReadUIFromTable();
                saveConfigurationToolStripMenuItem.Enabled = (configSaveFileDialog.FileName.Length > 0);
                generateSiteToolStripMenuItem.Enabled = (mUnifier != null);
                statusLabel.Text = "";
            }
        }

        private void pathButton_Click(object sender, EventArgs e)
        {
            outputSaveFileDialog.FileName = outputPathTextBox.Text;
            if (outputSaveFileDialog.ShowDialog(this) == DialogResult.OK) { outputPathTextBox.Text = outputSaveFileDialog.FileName; }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) { Close(); }

        private void addTargetButton_Click(object sender, EventArgs e)
        {
            using (AddPlatformForm w = new AddPlatformForm()) { if (w.ShowDialog(this) == DialogResult.OK) { AddTreeNodeSorted(targetsTreeView, new TreeNode(w.TargetName, 2, 2)); } }
        }

        private void saveConfigurationAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // if (mUnifier == null) return;

            if (configSaveFileDialog.ShowDialog(this) == DialogResult.OK) 
            {
                SaveUIToTable(true);
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter f = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                using (Stream fs = configSaveFileDialog.OpenFile()) 
                {
                    f.Serialize(fs, configurationTable); 
                }
            }
            if (configSaveFileDialog.FileName.Length > 0)
            {
                this.Text = title + " - " + new FileInfo(configSaveFileDialog.FileName).Name;
            }
        }

        private void fileToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            saveConfigurationToolStripMenuItem.Enabled = (configSaveFileDialog.FileName.Length > 0);
            generateSiteToolStripMenuItem.Enabled = (mUnifier != null);
        }

        private void saveConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (mUnifier == null) return;
            SaveUIToTable(true);
            System.Runtime.Serialization.Formatters.Binary.BinaryFormatter f = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
            using (Stream fs = configSaveFileDialog.OpenFile()) { f.Serialize(fs, configurationTable); }
        }

        private void targetsTreeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            removeTargetToolStripMenuItem.Visible = renameTargetToolStripMenuItem.Visible = duplicateTargetToolStripMenuItem.Visible = removeTargetButton.Enabled = (targetsTreeView.SelectedNode != null && targetsTreeView.SelectedNode.Parent == null);
            editFeaturesToolStripMenuItem.Visible = editFeaturesButton.Enabled = (targetsTreeView.SelectedNode != null);
            toolStripMenuItem3.Visible = (targetsTreeView.SelectedNode != null);
        }

        private void targetsTreeView_MouseDown(object sender, MouseEventArgs e)
        {
            TreeNode SelectedNode = targetsTreeView.GetNodeAt(e.X, e.Y);
            removeTargetToolStripMenuItem.Visible = renameTargetToolStripMenuItem.Visible = duplicateTargetToolStripMenuItem.Visible = removeTargetButton.Enabled = (SelectedNode != null && SelectedNode.Parent == null);
            editFeaturesToolStripMenuItem.Visible = editFeaturesButton.Enabled = (SelectedNode != null);
            toolStripMenuItem3.Visible = (SelectedNode != null);
            targetsTreeView.SelectedNode = SelectedNode;
        }

        private void removeTargetButton_Click(object sender, EventArgs e)
        {
            if (targetsTreeView.SelectedNode == null) return;
            targetsTreeView.SelectedNode.Remove();
        }

        private void editFeaturesButton_Click(object sender, EventArgs e)
        {
            if (targetsTreeView.SelectedNode == null) return;
            TreeNode SelectedNode = targetsTreeView.SelectedNode;
            while (SelectedNode.Parent != null) SelectedNode = SelectedNode.Parent;
            List<string> sfeatures = new List<string>();
            foreach (TreeNode n in SelectedNode.Nodes) { sfeatures.Add(n.Text); }
            using (EditFeaturesForm f = new EditFeaturesForm(features, sfeatures.ToArray()))
            {
                if (f.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
                {
                    string[] x = f.GetSelectedFeatures();
                    SelectedNode.Nodes.Clear();
                    foreach (string fx in x) { AddTreeNodeSorted(SelectedNode, new TreeNode(fx, 3, 3)); }
                    SelectedNode.Expand();
                }
            }
        }

        private void generateButton_Click(object sender, EventArgs e)
        {
            if (mUnifier == null || generateButton.Enabled == false) return;
            generateButton.Enabled = false;
            SaveUIToTable(false);
            new Thread(new ThreadStart(startGenerating)).Start();
        }

        private void startGenerating()
        {
            mUnifier.CompressWebSite(configurationTable);
            changeGeneratingStatus(true);
        }

        private void quickMinifyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (quickMinifyOpenFileDialog.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                foreach (string filename in quickMinifyOpenFileDialog.FileNames)
                {
                    FileInfo fileinf = new FileInfo(filename);
                    Yahoo.Yui.Compressor.JavaScriptCompressor jc = new Yahoo.Yui.Compressor.JavaScriptCompressor();
                    if (string.Compare(fileinf.Extension, ".html", true) == 0 || string.Compare(fileinf.Extension, ".htm", true) == 0 || string.Compare(fileinf.Extension, ".aspx", true) == 0)
                    {
                        string html = File.ReadAllText(filename);
                        HtmlAgilityPack.HtmlDocument mDoc = new HtmlAgilityPack.HtmlDocument();
                        mDoc.LoadHtml(html);

                        // Javascript Minification
                        foreach (HtmlAgilityPack.HtmlNode hn in GrandUnifier.GetScriptNodes(mDoc))
                        {
                            string js = hn.InnerText;

                            string[] jsSplitArray = null;
                            StringBuilder stringBuilder;
                            if (string.Compare(fileinf.Extension, ".aspx", true) == 0)
                            {
                                // Make sure ASP content is always at index 1 after split.
                                if (js.StartsWith("<%")) js += " ";

                                // Assume <% and %> always match
                                jsSplitArray = js.Split(new string[] { "<%", "%>" }, StringSplitOptions.None);

                                stringBuilder = new StringBuilder(jsSplitArray[0]);
                                for (int i = 1; i < jsSplitArray.Length; i++)
                                {
                                    if (i % 2 == 1)
                                    {
                                        stringBuilder.AppendFormat("ASP_BEGIN(ASP{0}+ASP_END)", i);
                                    }
                                    else
                                    {
                                        stringBuilder.Append(jsSplitArray[i]);
                                    }
                                }
                            }
                            else
                            {
                                stringBuilder = new StringBuilder(js);
                            }

                            try
                            {
                                if (js.Length != 0) { js = jc.Compress(stringBuilder.ToString()); }

                                if (string.Compare(fileinf.Extension, ".aspx", true) == 0)
                                {
                                    // Assume <% and %> always match
                                    string[] compressedJsSplitArray = js.Split(new string[] { "ASP_BEGIN(ASP", "+ASP_END)" }, StringSplitOptions.None);

                                    stringBuilder = new StringBuilder(compressedJsSplitArray[0]);
                                    for (int i = 1; i < compressedJsSplitArray.Length; i++)
                                    {
                                        if (i % 2 == 1)
                                        {
                                            stringBuilder.AppendFormat("<%{0}%>", jsSplitArray[i]);  // ASP content is not compressed
                                        }
                                        else
                                        {
                                            stringBuilder.Append(compressedJsSplitArray[i]);
                                        }
                                    }
                                    js = stringBuilder.ToString();
                                }

                                HtmlAgilityPack.HtmlNode nn = HtmlAgilityPack.HtmlNode.CreateNode("<script type=\"text/javascript\">" + js + "</script>");
                                hn.ParentNode.ReplaceChild(nn, hn); // Modify the HTML to inline the Java script
                            }
                            catch (EcmaScriptRuntimeException ex)
                            {
                                Console.WriteLine("File: " + filename);
                                Console.WriteLine("Line " + ex.LineNumber + ": " + ex.LineSource);
                                //System.Diagnostics.Debugger.Break();
                            }
                            catch (Exception)
                            {
                                System.Diagnostics.Debugger.Break();
                            }
                        }

                        // CSS Minification - Style Elements
                        HtmlAgilityPack.HtmlNodeCollection nCollection = mDoc.DocumentNode.SelectNodes("//style");
                        if (nCollection != null)
                        {
                            foreach (HtmlAgilityPack.HtmlNode n in nCollection)
                            {
                                // Write back the minified CSS to the HTML document
                                HtmlAgilityPack.HtmlNode newCSSNode = HtmlAgilityPack.HtmlNode.CreateNode("<style>" + GrandUnifier.MinifyCSS(n.InnerText) + "</style>");
                                n.ParentNode.ReplaceChild(newCSSNode, n);
                            }
                        }

                        // CSS Minification - Style Attributes
                        nCollection = mDoc.DocumentNode.SelectNodes("//@style");
                        if (nCollection != null)
                        {
                            foreach (HtmlAgilityPack.HtmlNode n in nCollection)
                            {
                                string css = n.GetAttributeValue("style", "");
                                css = GrandUnifier.MinifyCSS(css);
                                n.SetAttributeValue("style", css);
                            }
                        }

                        // HTML Minification
                        ZetaHtmlCompressor.HtmlContentCompressor HtmlCompressor = new ZetaHtmlCompressor.HtmlContentCompressor();
                        MemoryStream uncompressedStream = new MemoryStream();
                        mDoc.Save(uncompressedStream);
                        html = UTF8Encoding.UTF8.GetString(uncompressedStream.ToArray());
                        html = HtmlCompressor.Compress(html);

                        // Save the result
                        string filename2 = filename.Substring(0, filename.Length - fileinf.Extension.Length) + ".min" + fileinf.Extension;
                        File.WriteAllText(filename2, html);
	                }
                    else if (string.Compare(fileinf.Extension, ".css", true) == 0)
                    {
                        string css = File.ReadAllText(filename);
                        GrandUnifier.MinifyCSS(css);
                        string filename2 = filename.Substring(0, filename.Length - fileinf.Extension.Length) + ".min" + fileinf.Extension;
                        File.WriteAllText(filename2, css);            
	                }
                    else if (string.Compare(fileinf.Extension, ".js", true) == 0)
                    {
                        string js = File.ReadAllText(filename);
                        js = jc.Compress(js);
                        string filename2 = filename.Substring(0, filename.Length - fileinf.Extension.Length) + ".min" + fileinf.Extension;
                        File.WriteAllText(filename2, js);
                    }
                }
            }
        }

        private void minifyFolderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MinifyFolderForm minifyFolderForm = new MinifyFolderForm();
            minifyFolderForm.ShowDialog();
        }

        private void targetsTreeView_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop, false) == true)
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length == 1 && files[0].EndsWith(".wcc", StringComparison.CurrentCultureIgnoreCase))
                {
                    e.Effect = DragDropEffects.All;
                }
                else
                {
                    e.Effect = DragDropEffects.None;
                }
            }
        }

        private void targetsTreeView_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop, false) == true)
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length == 1 && files[0].EndsWith(".wcc", StringComparison.CurrentCultureIgnoreCase))
                {
                    using (FileStream s = new FileStream(files[0], FileMode.Open, FileAccess.Read))
                    {
                        System.Runtime.Serialization.Formatters.Binary.BinaryFormatter bf = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                        configurationTable = (Hashtable)bf.Deserialize(s);
                        configurationTable["ConfigurationFile"] = configOpenFileDialog.FileName;
                        configurationTable["WebSitePath"] = MakeAbsolutePath(new FileInfo(files[0]).Directory.FullName, (string)configurationTable["WebSitePath"]);
                        configurationTable["Output"] = MakeAbsolutePath(new FileInfo(files[0]).Directory.FullName, (string)configurationTable["Output"]);
                    }
                    outputListView.Items.Clear();
                    outputContextMenuStrip_Opening(this, null);
                    eventsTextBox.Clear();
                    ReadUIFromTable();
                    saveConfigurationToolStripMenuItem.Enabled = (configSaveFileDialog.FileName.Length > 0);
                    generateSiteToolStripMenuItem.Enabled = (mUnifier != null);
                    statusLabel.Text = "";
                }
            }
        }

        private void StartWatch(string path)
        {
            if (Directory.Exists(path))
            {
                AddWatcher(path, "*.html");
                AddWatcher(path, "*.htm");
                AddWatcher(path, "*.js");
                AddWatcher(path, "*.css");
            }
        }

        private void AddWatcher(string path, string filter)
        {
            FileSystemWatcher watcher = new FileSystemWatcher();
            watcher.Path = path;
            watcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.Size;
            
            // Only watch text files
            watcher.Filter = filter;

            // Add event handlers
            watcher.Changed += new FileSystemEventHandler(OnChanged);
            watcher.Created += new FileSystemEventHandler(OnChanged);
            watcher.Deleted += new FileSystemEventHandler(OnChanged);
            watcher.Renamed += new RenamedEventHandler(OnRenamed);

            // Begin watching
            watcher.EnableRaisingEvents = true;

            watchers.Add(watcher);
        }

        private void StopWatch()
        {
            foreach (FileSystemWatcher watcher in watchers) { watcher.EnableRaisingEvents = false; watcher.Dispose(); }
            watchers.Clear();
        }

        private void OnChanged(object source, FileSystemEventArgs e)
        {
            if (InvokeRequired) { Invoke(new FileSystemEventHandler(OnChanged), source, e ); return; }
            if (autogenerateOnChangeToolStripMenuItem.Checked)
            {
                generateInSeconds = 2;
                generateTimer.Enabled = true;
            }
        }

        private void OnRenamed(object source, RenamedEventArgs e)
        {
            if (InvokeRequired) { Invoke(new RenamedEventHandler(OnChanged), source, e); return; }
            if (autogenerateOnChangeToolStripMenuItem.Checked)
            {
                generateInSeconds = 2;
                generateTimer.Enabled = true;
            }
        }

        private void generateTimer_Tick(object sender, EventArgs e)
        {
            if (autogenerateOnChangeToolStripMenuItem.Checked == false) { generateTimer.Enabled = false; statusLabel.Text = ""; }

            --generateInSeconds;
            if (generateInSeconds <= 0)
            {
                generateTimer.Enabled = false;
                statusLabel.Text = "";
                generateButton_Click(this, null);
            }
            else if (generateInSeconds == 1)
            {
                statusLabel.Text = "Generating in " + generateInSeconds + " second...";
            }
            else
            {
                statusLabel.Text = "Generating in " + generateInSeconds + " seconds...";
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            eventsTextBox.Text = "";
        }

        private delegate void displayEventHandler(string str);
        public void displayEvent(string str)
        {
            if (InvokeRequired) { Invoke(new displayEventHandler(displayEvent), str); return; }
            eventsTextBox.AppendText(str);
        }

        public void displayStatus(string str)
        {
            if (InvokeRequired) { Invoke(new displayEventHandler(displayStatus), str); return; }
            statusLabel.Text = str;
        }

        private delegate void generatingEventHandler(bool generating);
        public void changeGeneratingStatus(bool generating)
        {
            if (InvokeRequired) { Invoke(new generatingEventHandler(changeGeneratingStatus), generating); return; }
            generateButton.Enabled = generating;
        }

        private delegate void displayOutputHandler(string name, long minifyed, long compressed, byte[] data);
        public void displayOutput(string name, long minifyed, long compressed, byte[] data)
        {
            if (InvokeRequired) { Invoke(new displayOutputHandler(displayOutput), name, minifyed, compressed, data); return; }
            if (name == null)
            {
                outputListView.Items.Clear();
            }
            else
            {
                string c = compressed.ToString();
                if (compressed == 0) c = "---";
                ListViewItem l = new ListViewItem(new string[] { name, minifyed.ToString(), c }, 2);
                if (data != null) { l.Tag = Convert.ToBase64String(data); }
                outputListView.Items.Add(l);
            }
            outputContextMenuStrip_Opening(this, null);
        }

        public static string MakeRelativePath(string absolutePath, string basePath)
        {
            Uri fullPath = new Uri(absolutePath, UriKind.Absolute);
            Uri relRoot = new Uri(basePath, UriKind.Absolute);
            return relRoot.MakeRelativeUri(fullPath).ToString();
        }

        public static string MakeAbsolutePath(string basePath, string relativePath)
        {
            return Path.GetFullPath(Path.Combine(basePath, relativePath));
        }

        private void noneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            noneToolStripMenuItem.Checked = true;
            yahooToolStripMenuItem.Checked = false;
            closureBasicToolStripMenuItem.Checked = false;
            closureAdvancedToolStripMenuItem.Checked = false;
            closureAdvancedToolStripMenuItem1.Checked = false;
        }

        private void yahooToolStripMenuItem_Click(object sender, EventArgs e)
        {
            noneToolStripMenuItem.Checked = false;
            yahooToolStripMenuItem.Checked = true;
            closureBasicToolStripMenuItem.Checked = false;
            closureAdvancedToolStripMenuItem.Checked = false;
            closureAdvancedToolStripMenuItem1.Checked = false;
        }

        private void closureBasicToolStripMenuItem_Click(object sender, EventArgs e)
        {
            noneToolStripMenuItem.Checked = false;
            yahooToolStripMenuItem.Checked = false;
            closureBasicToolStripMenuItem.Checked = true;
            closureAdvancedToolStripMenuItem.Checked = false;
            closureAdvancedToolStripMenuItem1.Checked = false;
        }

        private void closureAdvancedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            noneToolStripMenuItem.Checked = false;
            yahooToolStripMenuItem.Checked = false;
            closureBasicToolStripMenuItem.Checked = false;
            closureAdvancedToolStripMenuItem.Checked = true;
            closureAdvancedToolStripMenuItem1.Checked = false;
        }

        private void closureAdvancedToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            noneToolStripMenuItem.Checked = false;
            yahooToolStripMenuItem.Checked = false;
            closureBasicToolStripMenuItem.Checked = false;
            closureAdvancedToolStripMenuItem.Checked = false;
            closureAdvancedToolStripMenuItem1.Checked = true;
        }

        private void normalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            normalToolStripMenuItem.Checked = true;
            advancedToolStripMenuItem.Checked = false;
            highToolStripMenuItem.Checked = false;
            insaneToolStripMenuItem.Checked = false;
        }
        private void advancedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            normalToolStripMenuItem.Checked = false;
            advancedToolStripMenuItem.Checked = true;
            highToolStripMenuItem.Checked = false;
            insaneToolStripMenuItem.Checked = false;
        }

        private void highToolStripMenuItem_Click(object sender, EventArgs e)
        {
            normalToolStripMenuItem.Checked = false;
            advancedToolStripMenuItem.Checked = false;
            highToolStripMenuItem.Checked = true;
            insaneToolStripMenuItem.Checked = false;
        }

        private void insaneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            normalToolStripMenuItem.Checked = false;
            advancedToolStripMenuItem.Checked = false;
            highToolStripMenuItem.Checked = false;
            insaneToolStripMenuItem.Checked = true;
        }

        private void renameTargetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (targetsTreeView.SelectedNode == null) return;
            List<string> sfeatures = new List<string>();
            foreach (TreeNode n in targetsTreeView.SelectedNode.Nodes) { sfeatures.Add(n.Text); }

            using (AddPlatformForm w = new AddPlatformForm())
            {
                w.TargetName = targetsTreeView.SelectedNode.Text;
                if (w.ShowDialog(this) == DialogResult.OK)
                {
                    targetsTreeView.SelectedNode.Text = w.TargetName;
                }
            }
        }

        private void duplicateTargetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (targetsTreeView.SelectedNode == null) return;
            List<string> sfeatures = new List<string>();
            foreach (TreeNode n in targetsTreeView.SelectedNode.Nodes) { sfeatures.Add(n.Text); }

            using (AddPlatformForm w = new AddPlatformForm()) {
                w.TargetName = targetsTreeView.SelectedNode.Text;
                if (w.ShowDialog(this) == DialogResult.OK) {
                    if (string.Compare(w.TargetName, targetsTreeView.SelectedNode.Text, true) == 0) return;
                    TreeNode n = new TreeNode(w.TargetName, 2, 2);
                    foreach (string fx in sfeatures) { AddTreeNodeSorted(n, new TreeNode(fx, 3, 3)); }
                    AddTreeNodeSorted(targetsTreeView, n);
                    n.Expand();
                }
            }
        }

        public static void AddTreeNodeSorted(TreeNode root, TreeNode node)
        {
            int i = 0;
            foreach (TreeNode n in root.Nodes) { if (n.Text.CompareTo(node.Text) > 0) { root.Nodes.Insert(i, node); return; } i++; }
            root.Nodes.Add(node);
        }

        public static void AddTreeNodeSorted(TreeView root, TreeNode node)
        {
            int i = 0;
            foreach (TreeNode n in root.Nodes) { if (n.Text.CompareTo(node.Text) > 0) { root.Nodes.Insert(i, node); return; } i++; }
            root.Nodes.Add(node);
        }

        private void noneToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            noneToolStripMenuItem1.Checked = true;
            zETAToolStripMenuItem.Checked = false;
            zETAToolStripMenuItem1.Checked = false;
        }

        private void zETAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            noneToolStripMenuItem1.Checked = false;
            zETAToolStripMenuItem.Checked = true;
            zETAToolStripMenuItem1.Checked = false;
        }

        private void zETAToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            noneToolStripMenuItem1.Checked = false;
            zETAToolStripMenuItem.Checked = false;
            zETAToolStripMenuItem1.Checked = true;
        }

        private void outputListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            outputContextMenuStrip_Opening(this, null);
        }

        private void outputContextMenuStrip_Opening(object sender, CancelEventArgs e)
        {
            selectedToClipMenuItem.Visible = toolStripSeparator1.Visible = (outputListView.SelectedItems.Count > 0);
            allToClipMenuItem.Visible = (outputListView.Items.Count > 0);
        }

        private void javaScriptToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder sourceFile = new StringBuilder();
            foreach (ListViewItem l in outputListView.SelectedItems)
            {
                string datab64 = (string)l.Tag;
                string variablename = variableNameTextBox.Text;
                string platformName = l.SubItems[0].Text;

                //if (multiPlatform) { platformName = platform.Item1.Replace(" ", ""); }
                sourceFile.Append("var " + platformName + "_" + variablename + " = \"" + datab64 + "\";\r\n");
                Clipboard.SetText(sourceFile.ToString());
            }
        }

        private void javaScriptETagsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            StringBuilder sourceFile = new StringBuilder();
            foreach (ListViewItem l in outputListView.SelectedItems)
            {
                string datab64 = (string)l.Tag;
                string variablename = variableNameTextBox.Text;
                string platformName = l.SubItems[0].Text;

                //if (multiPlatform) { platformName = platform.Item1.Replace(" ", ""); }
                sourceFile.Append("var " + platformName + "_" + variablename + "_etag = \"" + GrandUnifier.CreateETag(Convert.FromBase64String(datab64)) + "\";\r\n");
                sourceFile.Append("var " + platformName + "_" + variablename + " = \"" + datab64 + "\";\r\n");
                Clipboard.SetText(sourceFile.ToString());
            }
        }

        private void javaScriptToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            StringBuilder sourceFile = new StringBuilder();
            foreach (ListViewItem l in outputListView.Items)
            {
                string datab64 = (string)l.Tag;
                string variablename = variableNameTextBox.Text;
                string platformName = l.SubItems[0].Text;

                //if (multiPlatform) { platformName = platform.Item1.Replace(" ", ""); }
                sourceFile.Append("var " + platformName + "_" + variablename + " = \"" + datab64 + "\";\r\n");
                Clipboard.SetText(sourceFile.ToString());
            }
        }

        private void javaScriptEtagsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder sourceFile = new StringBuilder();
            foreach (ListViewItem l in outputListView.Items)
            {
                string datab64 = (string)l.Tag;
                string variablename = variableNameTextBox.Text;
                string platformName = l.SubItems[0].Text;

                //if (multiPlatform) { platformName = platform.Item1.Replace(" ", ""); }
                sourceFile.Append("var " + platformName + "_" + variablename + "_etag = \"" + GrandUnifier.CreateETag(Convert.FromBase64String(datab64)) + "\";\r\n");
                sourceFile.Append("var " + platformName + "_" + variablename + " = \"" + datab64 + "\";\r\n");
                Clipboard.SetText(sourceFile.ToString());
            }
        }

        private void cToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder sourceFile = new StringBuilder();
            foreach (ListViewItem l in outputListView.SelectedItems)
            {
                string datab64 = (string)l.Tag;
                string variablename = variableNameTextBox.Text;
                string platformName = l.SubItems[0].Text;

                //if (multiPlatform) { platformName = platform.Item1.Replace(" ", ""); }
                sourceFile.Append("string " + platformName.Replace("-", "_") + "_" + variablename + " = \"" + datab64 + "\";\r\n");
                Clipboard.SetText(sourceFile.ToString());
            }
        }
        private void cEtagsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            StringBuilder sourceFile = new StringBuilder();
            foreach (ListViewItem l in outputListView.SelectedItems)
            {
                string datab64 = (string)l.Tag;
                string variablename = variableNameTextBox.Text;
                string platformName = l.SubItems[0].Text;

                //if (multiPlatform) { platformName = platform.Item1.Replace(" ", ""); }
                sourceFile.Append("string " + platformName.Replace("-", "_") + "_" + variablename + "_etag = \"" + GrandUnifier.CreateETag(Convert.FromBase64String(datab64)) + "\";\r\n");
                sourceFile.Append("string " + platformName.Replace("-", "_") + "_" + variablename + " = \"" + datab64 + "\";\r\n");
                Clipboard.SetText(sourceFile.ToString());
            }
        }

        private void cToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            StringBuilder sourceFile = new StringBuilder();
            foreach (ListViewItem l in outputListView.Items)
            {
                string datab64 = (string)l.Tag;
                string variablename = variableNameTextBox.Text;
                string platformName = l.SubItems[0].Text;

                //if (multiPlatform) { platformName = platform.Item1.Replace(" ", ""); }
                sourceFile.Append("string " + platformName.Replace("-", "_") + "_" + variablename + " = \"" + datab64 + "\";\r\n");
                Clipboard.SetText(sourceFile.ToString());
            }
        }

        private void cEtagsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder sourceFile = new StringBuilder();
            foreach (ListViewItem l in outputListView.Items)
            {
                string datab64 = (string)l.Tag;
                string variablename = variableNameTextBox.Text;
                string platformName = l.SubItems[0].Text;

                //if (multiPlatform) { platformName = platform.Item1.Replace(" ", ""); }
                sourceFile.Append("string " + platformName.Replace("-", "_") + "_" + variablename + "_etag = \"" + GrandUnifier.CreateETag(Convert.FromBase64String(datab64)) + "\";\r\n");
                sourceFile.Append("string " + platformName.Replace("-", "_") + "_" + variablename + " = \"" + datab64 + "\";\r\n");
                Clipboard.SetText(sourceFile.ToString());
            }
        }
    }
}
