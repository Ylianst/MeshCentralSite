﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Collections;
using System.Diagnostics;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Security.Cryptography;
using Microsoft.Win32;

// Ideas to minify even more:
// - Shorten the name of the CSS classes. They are all inline, we could replace with A, B, C...
// - Some function names are not shorten because only called from HTML. We could maybe inline them in the HTML, being carful that they are not being called from HTML embedded in Javascript.
// - Run a real CSS minifyer.
// - Compile to WebAssembly?

namespace WebSiteCompiler
{
    public class GrandUnifier
    {
        private Yahoo.Yui.Compressor.JavaScriptCompressor jc = new Yahoo.Yui.Compressor.JavaScriptCompressor();
        //private Dictionary<string, string> jsTable = new Dictionary<string, string>();
        public readonly DirectoryInfo websiteInfo;

        public GrandUnifier(DirectoryInfo websiteDirectoryInfo)
        {
            websiteInfo = websiteDirectoryInfo;
        }

        public GrandUnifier()
        {
        }

        public void displayEvent(string msg)
        {
            if (MainForm.Main != null) { MainForm.Main.displayEvent(msg); }
            Console.WriteLine(msg);
        }

        public string[] GetFeatures()
        {
            HashSet<string> retVal = new HashSet<string>();

            FileInfo[] files = null;
            try { files = websiteInfo.GetFiles("index.html"); } catch (Exception) { }
            if (files == null || files.Length == 0) return retVal.ToArray(); // Can't find the file index.html

            MemoryStream mem = new MemoryStream();
            using (FileStream fs = websiteInfo.GetFiles("index.html")[0].Open(FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                byte[] buffer = new byte[fs.Length];
                fs.Read(buffer, 0, buffer.Length);
                if (buffer.Length > 3 && buffer[0] == 0xEF && buffer[1] == 0xBB && buffer[2] == 0xBF)
                {
                    // Drop the first 3 characters
                    mem.Write(buffer, 3, buffer.Length - 3);
                }
                else
                {
                    // Get the entire file
                    mem.Write(buffer, 0, buffer.Length);
                }
                mem.Seek(0, SeekOrigin.Begin);
            }

            HtmlAgilityPack.HtmlDocument d = new HtmlAgilityPack.HtmlDocument();
            d.Load(mem);
            HtmlAgilityPack.HtmlNodeCollection nc;

            // Parse each comment block to see if it encoded a feature
            nc = d.DocumentNode.SelectNodes("//comment()");
            if (nc != null)
            {
                foreach (HtmlAgilityPack.HtmlNode n in nc)
                {
                    if (n.InnerText.StartsWith("<!-- ###BEGIN###{"))
                    {
                        string feature = n.InnerText.Substring(1 + n.InnerText.IndexOf("{"));
                        feature = feature.Substring(0, feature.IndexOf("}"));
                        if (feature.Length > 0 && feature[0] != '!' && feature[0] != '*') { retVal.Add(feature); }
                    }
                }
            }
            // Parse each javascript block to see if it encoded a feature
            nc = d.DocumentNode.SelectNodes("//script");
            if (nc != null)
            {
                foreach (HtmlAgilityPack.HtmlNode n in nc)
                {
                    // If we need to, load the .js file from disk
                    string keeplink = n.GetAttributeValue("keeplink", "");
                    if (keeplink.Length == 0)
                    {
                        string src = n.GetAttributeValue("src", "");
                        if (src.Length != 0)
                        {
                            FileInfo[] files2 = null;
                            try { files2 = websiteInfo.GetFiles(src); } catch (Exception) { }
                            if (files2 == null || files2.Length == 0)
                            {
                                displayEvent("  ERROR: Missing file " + src + "\r\n");
                            }
                            else
                            {
                                string js = src != "" ? LoadFileFromDisk(files2[0]) : n.InnerText;

                                string[] tokens = js.Split(new string[] { "// ###BEGIN###{" }, StringSplitOptions.None);
                                if (tokens.Length > 1)
                                {
                                    for (int i = 1; i < tokens.Length; ++i)
                                    {
                                        string feature = tokens[i].Substring(0, tokens[i].IndexOf("}"));
                                        if (feature.Length > 0 && feature[0] != '!' && feature[0] != '*') { retVal.Add(feature); }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return retVal.ToArray();
        }

        private void SaveFileToDisk(string s, FileInfo f)
        {
            byte[] buffer = UTF8Encoding.UTF8.GetBytes(s);
            using (FileStream fs = f.Open(FileMode.Create, FileAccess.ReadWrite, FileShare.None))
            {
                fs.Write(buffer, 0, buffer.Length);
                fs.Close();
            }
        }

        private string LoadFileFromDisk(FileInfo f)
        {
            string retVal = null;
            using (FileStream fs = f.Open(FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                byte[] buffer = new byte[fs.Length];
                fs.Read(buffer, 0, buffer.Length);
                if (buffer.Length > 3 && buffer[0] == 0xEF && buffer[1] == 0xBB && buffer[2] == 0xBF)
                {
                    // Drop the first 3 characters
                    retVal = UTF8Encoding.UTF8.GetString(buffer, 3, buffer.Length - 3);
                }
                else
                {
                    // Get the entire file
                    retVal = UTF8Encoding.UTF8.GetString(buffer);
                }
            }
            return retVal;
        }

        private string LoadFileFromDisk(FileInfo f, string lang)
        {
            // If there is a specific language file for this file, use that one.
            if ((lang != null) && (lang != ""))
            {
                string altFilename = f.DirectoryName + "\\" + f.Name.Substring(0, f.Name.Length - f.Extension.Length) + lang.Replace("-", "_") + f.Extension;
                if (File.Exists(altFilename)) { f = new FileInfo(altFilename); }
            }

            // Continue loading.
            string retVal = null;
            using (FileStream fs = f.Open(FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                byte[] buffer = new byte[fs.Length];
                fs.Read(buffer, 0, buffer.Length);
                if (buffer.Length > 3 && buffer[0] == 0xEF && buffer[1] == 0xBB && buffer[2] == 0xBF)
                {
                    // Drop the first 3 characters
                    retVal = UTF8Encoding.UTF8.GetString(buffer, 3, buffer.Length - 3);
                }
                else
                {
                    // Get the entire file
                    retVal = UTF8Encoding.UTF8.GetString(buffer);
                }
            }
            return retVal;
        }

        public string CompressJavaScript(string str, bool compress = true)
        {
            try
            {
                return (compress ? jc.Compress(str) : str);
            }
            catch (Exception ex)
            {
                displayEvent("  ERROR: Unable to minify javascript: " + ex.ToString() + "\r\n");
                if (ex.GetType() == typeof(EcmaScript.NET.EcmaScriptRuntimeException))
                {
                    EcmaScript.NET.EcmaScriptRuntimeException ex2 = (EcmaScript.NET.EcmaScriptRuntimeException)ex;
                    displayEvent("  Message: " + ex2.Message + "\r\n");
                    displayEvent("  LineNumber: " + ex2.LineNumber + "\r\n");
                    displayEvent("  LineSource: " + ex2.LineSource + "\r\n");
                }
                return str;
            }
        }

        public static HtmlAgilityPack.HtmlNode[] GetScriptNodes(HtmlAgilityPack.HtmlDocument d)
        {
            List<HtmlAgilityPack.HtmlNode> retVal = new List<HtmlAgilityPack.HtmlNode>();
            HtmlAgilityPack.HtmlNodeCollection nc = d.DocumentNode.SelectNodes("//script");
            if (nc != null)
            {
                foreach (HtmlAgilityPack.HtmlNode hn in nc)
                {
                    // Don't include runat="server" attributes, that is server side code.
                    if (hn.Attributes["runat"] == null || string.Compare(hn.Attributes["runat"].Value, "server", true) != 0) { retVal.Add(hn); }
                }
            }
            return (retVal.ToArray());
        }

        public static HtmlAgilityPack.HtmlNode[] GetCssNodes(HtmlAgilityPack.HtmlDocument d)
        {
            List<HtmlAgilityPack.HtmlNode> retVal = new List<HtmlAgilityPack.HtmlNode>();
            HtmlAgilityPack.HtmlNodeCollection nc = d.DocumentNode.SelectNodes("//link");
            if (nc != null)
            {
                foreach (HtmlAgilityPack.HtmlNode hn in nc)
                {
                    // Don't include runat="server" attributes, that is server side code.
                    if ((hn.GetAttributeValue("keeplink", "").Length == 0) && ((hn.Attributes["runat"] == null) || (string.Compare(hn.Attributes["runat"].Value, "server", true) != 0))) { retVal.Add(hn); }
                }
            }
            return (retVal.ToArray());
        }

        public static string TwizzleString(string inputString, string beginString, string endString)
        {
            StringBuilder retVal = new StringBuilder();
            string[] tokens = inputString.Split(new string[] { beginString }, StringSplitOptions.None);
            bool first = true;

            foreach (string tok in tokens)
            {
                if (first)
                {
                    retVal.Append(tok);
                    first = false;
                }
                else
                {
                    string[] tok2 = tok.Split(new string[] { endString }, StringSplitOptions.None);
                    retVal.Append(tok2[1]);
                }
            }

            return (retVal.ToString());
        }

        public static string MinifyCSS(string css)
        {
            css = css.Replace("\t", " ").Replace("\r", " ").Replace("\n", " ");
            while (css.IndexOf("  ") != -1)
            {
                css = css.Replace("  ", " ");
            }
            css = css.Replace("; ", ";").Replace("} ", "}").Replace(" { ", "{").Replace(": ", ":");

            //
            // Remove CSS Comments
            //
            while (css.IndexOf("/*") != -1)
            {
                string s1 = css.Substring(0, css.IndexOf("/*"));
                string s2 = css.Substring(css.IndexOf("*/") + 2);
                css = s1 + s2;
            }
            return (css);
        }

        /// <summary>
        /// Entrypoint for Web Site Builder, to generate the Website
        /// </summary>
        /// <param name="configurationTable">The configuration to use for web site generation</param>
        /// <param name="result">Optional stream to write the result to. If null, it will write it to the destination specified by the configuration</param>
        public void CompressWebSite(Hashtable configurationTable)
        {
            StringBuilder sourceFile = new StringBuilder();
            bool multiLanguage = configurationTable.ContainsKey("MultiLang") ? (bool)configurationTable["MultiLang"] : false;
            bool IncludeWebServer = configurationTable.ContainsKey("EmbedWebServer") ? (bool)configurationTable["EmbedWebServer"] : false;
            string variablename = configurationTable.ContainsKey("VariableName") ? (string)configurationTable["VariableName"] : "html";
            DirectoryInfo WebSitePath = new DirectoryInfo((string)configurationTable["WebSitePath"]);
            if (MainForm.Main != null) { MainForm.Main.displayOutput(null, 0, 0, null); } // Clear the generated output result box
            displayEvent("Generating at " + DateTime.Now.ToString() + "...\r\n");
            sourceFile.Append("//\r\n// Auto-Generated by Web Site Compiler v" + System.Windows.Forms.Application.ProductVersion + " on " + DateTime.Now.ToString() + ".\r\n//\r\n\r\n");

            FileInfo[] mainfiles = null;
            if (multiLanguage == false) { mainfiles = WebSitePath.GetFiles("index.html"); } else { mainfiles = WebSitePath.GetFiles("index*.html"); }
            if (mainfiles.Length == 0) { displayEvent("  ERROR: Missing index.html\r\n"); return; }
            bool indexHtmlPresent = false;
            foreach (FileInfo file in mainfiles) { if (file.Name.ToLower() == "index.html") { indexHtmlPresent = true; } }
            if (indexHtmlPresent == false) { displayEvent("  ERROR: Missing index.html\r\n"); return; }

            // Get the CPU count
            int processorCount = Environment.ProcessorCount;
            if (processorCount > 2) { processorCount--; } // Keep one thread free.
            int runningThreadCount = 0;

            List<Thread> Threads = new List<Thread>();
            List<object[]> PendingThreads = new List<object[]>();
            List<Tuple<string, List<string>>> platforms = (List<Tuple<string, List<string>>>)configurationTable["PlatformTree"];
            foreach (FileInfo file in mainfiles)
            {
                // Fetch the language code from the filename
                string lang = "";
                if (file.Name.StartsWith("index_")) { lang = file.Name.Split('.')[0].Substring(6); }

                // Load the file
                byte[] buffer = null;
                using (FileStream fs = file.Open(FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    buffer = new byte[fs.Length];
                    fs.Read(buffer, 0, buffer.Length);
                }

                // If the file starts with the UTF-8 header, remove it.
                if (buffer.Length > 3 && buffer[0] == 0xEF && buffer[1] == 0xBB && buffer[2] == 0xBF)
                {
                    // Drop the first 3 characters
                    byte[] buffer2 = new byte[buffer.Length - 3];
                    Array.Copy(buffer, 3, buffer2, 0, buffer.Length - 3);
                    buffer = buffer2;
                }

                // For each platform, compile the file
                foreach (Tuple<string, List<string>> platform in platforms)
                {
                    List<Tuple<string, List<string>>> platformex = new List<Tuple<string, List<string>>>();
                    platformex.Add(platform);
                    object[] args = new object[] { configurationTable, platformex, sourceFile, buffer, platforms.Count > 1, lang };

                    if (runningThreadCount < processorCount)
                    {
                        Thread t = new Thread(new ParameterizedThreadStart(CompressWebSiteEx));
                        Threads.Add(t);
                        runningThreadCount++;
                        t.Start(args);
                    }
                    else
                    {
                        PendingThreads.Add(args);
                    }
                }
            }

            // Wait for all threads to finish
            int threadcount = 1;
            while (threadcount != 0)
            {
                Thread.Sleep(100);
                threadcount = 0;
                foreach (Thread t in Threads) { if (t.IsAlive) { threadcount++; } }
                if ((threadcount < processorCount) && (PendingThreads.Count > 0))
                {
                    // Activate one of the pending threads
                    object[] args = PendingThreads[0];
                    PendingThreads.RemoveAt(0);
                    Thread t = new Thread(new ParameterizedThreadStart(CompressWebSiteEx));
                    Threads.Add(t);
                    t.Start(args);
                    threadcount++;
                }
            }

            if (configurationTable.ContainsKey("Output"))
            {
                string outputFile = (string)configurationTable["Output"];
                FileInfo outputFile2 = null;
                try { outputFile2 = new FileInfo(outputFile); } catch (Exception) { }

                if (outputFile2 != null)
                {
                    if (string.Compare(outputFile2.Extension, ".h", true) == 0 || string.Compare(outputFile2.Extension, ".js", true) == 0)
                    {
                        byte[] resultBuffer = UTF8Encoding.UTF8.GetBytes(sourceFile.ToString());
                        using (FileStream str = new FileStream(outputFile, FileMode.Create, FileAccess.ReadWrite)) { str.Write(resultBuffer, 0, resultBuffer.Length); }
                    }

                    if (IncludeWebServer)
                    {
                        FileInfo f = new FileInfo((string)configurationTable["Output"]);
                        DirectoryInfo d = new DirectoryInfo("Files");
                        foreach (FileInfo file in d.GetFiles())
                        {
                            if (file.Name != "Main.c")
                            {
                                file.CopyTo(f.Directory.FullName + "\\" + file.Name, true);
                            }
                            else
                            {
                                string main = LoadFileFromDisk(file);
                                main = main.Replace("{{{INCLUDEHFILE}}}", f.Name).Replace("{{{VARIABLE}}}", variablename).Replace("{{{VARIABLELEN}}}", variablename + "_len");
                                SaveFileToDisk(main, new FileInfo(f.Directory.FullName + "\\" + file.Name));
                            }
                        }
                    }
                }
            }

            if (MainForm.Main != null) { MainForm.Main.displayStatus("Done"); }
        }

        public void CompressWebSiteEx(object arg) {
            object[] args = (object[])arg;
            Hashtable configurationTable = (Hashtable)args[0];
            List<Tuple<string, List<string>>> platforms = (List<Tuple<string, List<string>>>)args[1];
            StringBuilder sourceFile = (StringBuilder)args[2];
            byte[] buffer = (byte[])args[3];
            bool multiPlatform = (bool)args[4];
            string language = (string)args[5];
            CompressWebSiteEx(configurationTable, platforms, sourceFile, buffer, multiPlatform, language);
        }

        public void CompressWebSiteEx(Hashtable configurationTable, List<Tuple<string, List<string>>> platforms, StringBuilder sourceFile, byte[] buffer, bool multiPlatform, string language)
        {
            byte[] sourceFileBin = null;
            int JSCompression = configurationTable.ContainsKey("JSSCompression") ? (int)configurationTable["JSSCompression"] : 0;
            int GZIPCompression = configurationTable.ContainsKey("GZIPCompression") ? (int)configurationTable["GZIPCompression"] : 0;
            int HTMLCompression = configurationTable.ContainsKey("HTMLCompression2") ? (int)configurationTable["HTMLCompression2"] : 0;
            bool ImageInlining = configurationTable.ContainsKey("InlineImages") ? (bool)configurationTable["InlineImages"] : false;
            string variablename = configurationTable.ContainsKey("VariableName") ? (string)configurationTable["VariableName"] : "html";
            DirectoryInfo WebSitePath = new DirectoryInfo((string)configurationTable["WebSitePath"]);

            string lang = "";
            if (language != "") { lang = "-" + language; }

            HashSet<string> removedFeatures = new HashSet<string>();
            HashSet<string> includedFeatures = new HashSet<string>();
            Hashtable renameReportTable = null;

            foreach (Tuple<string, List<string>> platform in platforms)
            {
                string allJavaScript = null;
                string platformname = platform.Item1.Replace(" ", "").ToLower() + lang;
                if (MainForm.Main != null) { MainForm.Main.displayStatus("Generating " + platformname + "..."); }

                #region Determine Feature-set
                removedFeatures.Clear();
                includedFeatures.Clear();

                if (JSCompression == 3 || JSCompression == 4) includedFeatures.Add("**ClosureAdvancedMode"); // If this is Closure Advanced Mode, add this feature
                else removedFeatures.Add("**ClosureAdvancedMode"); // If not in Closure Advanced Mode, remove this feature

                foreach (string feature in (List<string>)configurationTable["FeatureList"])
                {
                    removedFeatures.Add(feature);
                }

                foreach (string platformFeature in platform.Item2)
                {
                    removedFeatures.Remove(platformFeature);
                    includedFeatures.Add(platformFeature);
                }
                #endregion

                // Do a first pre-processor run on the HTML, this is needed because we will avoid including files we don't need
                string htmlString = UTF8Encoding.UTF8.GetString(buffer);
                htmlString = htmlString.Replace("} -->\r\n", "} -->"); // Line breaks after HTML pre-processor comments, this clear the output a bit.
                int htmlStringLen;
                do { htmlStringLen = htmlString.Length; htmlString = htmlString.Replace(" // ###", "// ###"); } while (htmlStringLen != htmlString.Length); // Move Javascript pro-processor comments to start of line.

                foreach (string removedFeature in removedFeatures)
                {
                    htmlString = htmlString.Replace("<!-- ###BEGIN###{!" + removedFeature + "} -->", "").Replace("<!-- ###END###{!" + removedFeature + "} -->", "");
                    try
                    { 
                        htmlString = TwizzleString(htmlString, "<!-- ###BEGIN###{" + removedFeature + "} -->", "<!-- ###END###{" + removedFeature + "} -->");
                    }
                    catch (Exception)
                    {
                        displayEvent("  ERROR(1): Pre-processor remove start/end tokens don't match: " + removedFeature + "\r\n");
                        return;
                    }
                }
                foreach (string includedFeature in includedFeatures)
                {
                    htmlString = htmlString.Replace("<!-- ###BEGIN###{" + includedFeature + "} -->", "").Replace("<!-- ###END###{" + includedFeature + "} -->", "");
                    try
                    { 
                        htmlString = TwizzleString(htmlString, "<!-- ###BEGIN###{!" + includedFeature + "} -->", "<!-- ###END###{!" + includedFeature + "} -->");
                    }
                    catch (Exception)
                    {
                        displayEvent("  ERROR(2): Pre-processor include start/end tokens don't match: " + includedFeature + "\r\n");
                        return;
                    }
                }
                HtmlAgilityPack.HtmlDocument mDoc = new HtmlAgilityPack.HtmlDocument();
                mDoc.LoadHtml(htmlString);

                // Inline CSS
                HtmlAgilityPack.HtmlNode[] csslinks = GetCssNodes(mDoc);
                foreach (HtmlAgilityPack.HtmlNode hn in csslinks)
                {
                    // If we need to, load the .js file from disk
                    string type = hn.GetAttributeValue("type", "");
                    string href = hn.GetAttributeValue("href", "");

                    if (string.Compare(type, "text/css", true) == 0)
                    {
                        FileInfo[] files = WebSitePath.GetFiles(href);
                        if (files.Length > 0)
                        {
                            string css = LoadFileFromDisk(files[0]);
                            HtmlAgilityPack.HtmlNode nn = HtmlAgilityPack.HtmlNode.CreateNode("<style type=\"text/css\">" + css + "</style>");
                            hn.ParentNode.ReplaceChild(nn, hn); // Modify the HTML to inline the Java script
                        }
                        else
                        {
                            displayEvent("  ERROR: Missing file " + href + "\r\n");
                        }
                    }
                }

                // Create a list of web compiler features
                string features = "";
                foreach (string includedFeature in includedFeatures)
                {
                    if (features.Length > 0) features += ",";
                    features += "'" + includedFeature + "'";
                }

                #region Process JavaScript
                foreach (HtmlAgilityPack.HtmlNode hn in GetScriptNodes(mDoc))
                {
                    // If we need to, load the .js file from disk
                    string keeplink = hn.GetAttributeValue("keeplink", "");
                    if (keeplink.Length == 0)
                    {
                        string src = hn.GetAttributeValue("src", "");
                        string js = hn.InnerText;
                        if (src != "")
                        {
                            FileInfo[] files = null;
                            try { files = WebSitePath.GetFiles(src); } catch (Exception) { }
                            if (files == null || files.Length == 0) { displayEvent("  ERROR: Missing file " + src + "\r\n"); continue; }
                            js = LoadFileFromDisk(files[0], lang);
                        }

                        js = js.Replace("/*###WEBCOMPILERFEATURES###*/", features);

                        foreach (string removedFeature in removedFeatures)
                        {
                            js = js.Replace("// ###BEGIN###{!" + removedFeature + "}", "").Replace("// ###END###{!" + removedFeature + "}", "");
                            try
                            {
                                js = TwizzleString(js, "// ###BEGIN###{" + removedFeature + "}", "// ###END###{" + removedFeature + "}");
                            }
                            catch (Exception) {
                                displayEvent("  ERROR(3): Pre-processor '//' remove start/end tokens don't match: " + removedFeature + "\r\n");
                                return;
                            }
                        }
                        foreach (string includedFeature in includedFeatures)
                        {
                            js = js.Replace("// ###BEGIN###{" + includedFeature + "}", "").Replace("// ###END###{" + includedFeature + "}", "");
                            try
                            {
                                js = TwizzleString(js, "// ###BEGIN###{!" + includedFeature + "}", "// ###END###{!" + includedFeature + "}");
                            }
                            catch (Exception) {
                                displayEvent("  ERROR(4): Pre-processor '//' include start/end tokens don't match: " + includedFeature + "\r\n");
                                return;
                            }
                        }

                        allJavaScript += js;
                        hn.ParentNode.RemoveChild(hn); // Remove this node completely, we are merging all javascript at the end of the HTML
                    }
                    else
                    {
                        hn.Attributes.Remove("keeplink");
                    }
                }

                if (allJavaScript != null)
                {
                    // ASP.net tokens <%= ... %> can't be minifyed. Remove them, minify and add them back later.
                    Hashtable aspnettokens = null;
                    if (((string)configurationTable["Output"]).ToLower().EndsWith(".aspx")) { aspnettokens = replaceWithTokens(ref allJavaScript, "<%=", "%>"); }

                    switch (JSCompression)
                    {
                        case 1:
                            {
                                if (MainForm.Main != null) { MainForm.Main.displayStatus("Minifying " + platformname + "..."); }
                                try
                                {
                                    // Use Yahoo Javascript compression
                                    allJavaScript = CompressJavaScript(allJavaScript, true);
                                }
                                catch (Exception) {
                                    displayEvent("  ERROR: Unable to minify Javascript\r\n");
                                }
                                break;
                            }
                        case 2:
                            {
                                if (MainForm.Main != null) { MainForm.Main.displayStatus("Minifying " + platformname + "..."); }
                                try
                                {
                                    string javapath = GetJavaInstallationPath();

                                    // Run Google closure compiler in normal mode
                                    if (javapath != null)
                                    {
                                        string t = GetTempPath(platformname);
                                        File.WriteAllText(Path.Combine(t, "closure-" + platformname + ".js"), allJavaScript);
                                        string cmdline = System.IO.Path.Combine(javapath, "bin\\Java.exe");
                                        string args = "-jar " + Path.Combine(Application.StartupPath, "compiler.jar") + " --js " + Path.Combine(t, "closure-" + platformname + ".js") + " --js_output_file " + Path.Combine(t, "closure-" + platformname + "-compiled.js");
                                        File.WriteAllText(Path.Combine(t, "run.bat"), "\"" + cmdline + "\" " + args + "\r\npause\r\n");
                                        Process p = Run(cmdline, args);
                                        while (p.HasExited == false) { System.Threading.Thread.Sleep(50); }
                                        allJavaScript = File.ReadAllText(Path.Combine(t, "closure-" + platformname + "-compiled.js"));
                                        File.Delete(Path.Combine(t, "closure-" + platformname + ".js"));
                                        File.Delete(Path.Combine(t, "closure-" + platformname + "-compiled.js"));
                                        File.Delete(Path.Combine(t, "run.bat"));
                                        try { ClearTempPath(t); } catch (Exception) { }
                                    }
                                    else
                                    {
                                        displayEvent("  ERROR: JAVA is not installed, unable to minify\r\n");
                                    }
                                }
                                catch (Exception) { displayEvent("  ERROR: Unable to minify Javascript\r\n"); }
                                break;
                            }
                        case 3:
                        case 4:
                            {
                                if (MainForm.Main != null) { MainForm.Main.displayStatus("Minifying " + platformname + "..."); }
                                try
                                {
                                    // Run Google closure compiler in advanced mode
                                    string javapath = GetJavaInstallationPath();

                                    if (javapath != null)
                                    {
                                        string t = GetTempPath(platformname);
                                        File.WriteAllText(Path.Combine(t, "closure-" + platformname + ".js"), allJavaScript);

                                        // Pull closure Advanced mode externs
                                        string externs = "";
                                        DirectoryInfo externsPath = new DirectoryInfo(Path.Combine(WebSitePath.FullName, "closure-externs"));
                                        if (Directory.Exists(externsPath.FullName)) { foreach (FileInfo f in externsPath.GetFiles("*.js")) { externs += " --externs \"" + f.FullName + "\""; } }

                                        // In super advanced mode, generate renaming report
                                        if (JSCompression == 4) externs += " --variable_renaming_report " + Path.Combine(t, "rename.txt");

                                        // Run closure in advanced mode
                                        string cmdline = System.IO.Path.Combine(javapath, "bin\\Java.exe");
                                        string args = "-jar " + Path.Combine(Application.StartupPath, "compiler.jar") + " --js " + Path.Combine(t, "closure-" + platformname + ".js") + " --compilation_level ADVANCED_OPTIMIZATIONS --js_output_file " + Path.Combine(t, "closure-" + platformname + "-compiled.js") + externs;
                                        File.WriteAllText(Path.Combine(t, "run.bat"), "\"" + cmdline + "\" " + args + "\r\npause\r\n");
                                        Process p = Run(cmdline, args);
                                        while (p.HasExited == false) { System.Threading.Thread.Sleep(50); }
                                        allJavaScript = File.ReadAllText(Path.Combine(t, "closure-" + platformname + "-compiled.js"));
                                        File.Delete(Path.Combine(t, "closure-" + platformname + ".js"));
                                        File.Delete(Path.Combine(t, "closure-" + platformname + "-compiled.js"));
                                        File.Delete(Path.Combine(t, "run.bat"));

                                        // In super advanced mode
                                        if (JSCompression == 4)
                                        {
                                            // Read the renaming report
                                            string renameReport = File.ReadAllText(Path.Combine(t, "rename.txt"));
                                            File.Delete(Path.Combine(t, "rename.txt"));
                                            Hashtable renameReportTable2 = new Hashtable();
                                            string[] renameReport2 = renameReport.Split('\n');
                                            foreach (string x in renameReport2) { string[] xx = x.Split(':'); if (xx.Length == 2 && xx[0].Length > 0 && xx[0].IndexOf(' ') == -1 && xx[1] != "id") { renameReportTable2.Add(xx[0], xx[1]); } }

                                            // Look in the Javascript code for any ";window.xxx=yy;" patterns
                                            renameReportTable = new Hashtable();
                                            foreach (string k in renameReportTable2.Keys)
                                            {
                                                string v = (string)renameReportTable2[k];
                                                string pattern = ";window." + k + "=" + v + ";";
                                                if (allJavaScript.IndexOf(pattern) >= 0)
                                                {
                                                    allJavaScript = allJavaScript.Replace(pattern, ";");
                                                    renameReportTable.Add(k, v);
                                                    allJavaScript = allJavaScript.Replace(k + "(", v + "(");
                                                }
                                                pattern = "}window." + k + "=" + v + ";";
                                                if (allJavaScript.IndexOf(pattern) >= 0)
                                                {
                                                    allJavaScript = allJavaScript.Replace(pattern, "}");
                                                    renameReportTable.Add(k, v);
                                                    allJavaScript = allJavaScript.Replace(k + "(", v + "(");
                                                }
                                            }
                                        }

                                        try { ClearTempPath(t); } catch (Exception) { }
                                    }
                                    else
                                    {
                                        displayEvent("  ERROR: JAVA is not installed\r\n");
                                    }
                                }
                                catch (Exception ex) {
                                    displayEvent("  ERROR: Unable to minify Javascript\r\n");
                                }
                                break;
                            }
                    }

                    // Put ASP.net tokens back in
                    if (aspnettokens != null) { foreach (string k in aspnettokens.Keys) { allJavaScript = allJavaScript.Replace(k, (string)aspnettokens[k]); } }

                    allJavaScript = "<script>" + allJavaScript + "</script>"; // type="text/javascript" is assumed, so no need to put that in.
                }

                #endregion
                #region Process HTML
                #region Image Inlining
                if (ImageInlining)
                {
                    // Inline images that are in the HTML code
                    HtmlAgilityPack.HtmlNodeCollection nc = mDoc.DocumentNode.SelectNodes("//img");
                    if (nc != null)
                    {
                        foreach (HtmlAgilityPack.HtmlNode n in nc)
                        {
                            string src = n.GetAttributeValue("src", "");
                            if (src != "" && !src.StartsWith("http", StringComparison.CurrentCultureIgnoreCase) && !src.StartsWith("data", StringComparison.CurrentCultureIgnoreCase))
                            {
                                FileInfo[] files = null;
                                try { files = WebSitePath.GetFiles(src); } catch (Exception) { }
                                if (files != null && files.Length > 0)
                                {
                                    byte[] iBuffer = null;
                                    using (FileStream fStr = files[0].OpenRead())
                                    {
                                        iBuffer = new byte[fStr.Length];
                                        fStr.Read(iBuffer, 0, iBuffer.Length);
                                    }
                                    string attr = "data:image/" + files[0].Extension.Substring(1) + ";base64," + System.Convert.ToBase64String(iBuffer);
                                    n.SetAttributeValue("src", attr);
                                }
                            }
                        }
                    }

                    // Inline images that are in CSS code
                    HtmlAgilityPack.HtmlNodeCollection nCollection = mDoc.DocumentNode.SelectNodes("//style");
                    if (nCollection != null)
                    {
                        foreach (HtmlAgilityPack.HtmlNode n in nCollection)
                        {
                            //
                            // Write back the minified CSS to the HTML document
                            //
                            string css = n.InnerText;

                            int i, ptr = 0;
                            while ((i = css.IndexOf("background-image: url(\"", ptr)) >= 0)
                            {
                                i += 23;
                                int j = css.IndexOf("\");", i);
                                if (j >= 0)
                                {
                                    string src = css.Substring(i, j - i);
                                    if (src.StartsWith("data:", StringComparison.CurrentCultureIgnoreCase) == false)
                                    {
                                        FileInfo[] files = null;
                                        try { files = WebSitePath.GetFiles(src); } catch (Exception) { }
                                        if (files != null && files.Length > 0)
                                        {
                                            byte[] iBuffer = null;
                                            using (FileStream fStr = files[0].OpenRead())
                                            {
                                                iBuffer = new byte[fStr.Length];
                                                fStr.Read(iBuffer, 0, iBuffer.Length);
                                            }
                                            string attr = "data:image/" + files[0].Extension.Substring(1) + ";base64," + System.Convert.ToBase64String(iBuffer);
                                            css = css.Substring(0, i) + attr + css.Substring(j);
                                        }
                                        else
                                        {
                                            displayEvent("  ERROR: Unable to find " + src + "\r\n");
                                        }
                                    }
                                }
                                ptr = i;
                            }

                            HtmlAgilityPack.HtmlNode newCSSNode = HtmlAgilityPack.HtmlNode.CreateNode("<style>" + css + "</style>");
                            n.ParentNode.ReplaceChild(newCSSNode, n);
                        }
                    }
                }
                #endregion
                #region CSS Minification

                //
                // CSS Minification
                //
                if (HTMLCompression > 0)
                {
                    if (MainForm.Main != null) { MainForm.Main.displayStatus("CSS minification " + platformname + "..."); }

                    // Style Elements
                    HtmlAgilityPack.HtmlNodeCollection nCollection = mDoc.DocumentNode.SelectNodes("//style");
                    if (nCollection != null)
                    {
                        foreach (HtmlAgilityPack.HtmlNode n in nCollection)
                        {
                            //
                            // Write back the minified CSS to the HTML document
                            //
                            HtmlAgilityPack.HtmlNode newCSSNode = HtmlAgilityPack.HtmlNode.CreateNode("<style>" + MinifyCSS(n.InnerText) + "</style>");
                            n.ParentNode.ReplaceChild(newCSSNode, n);
                        }
                    }

                    // Style Attributes
                    nCollection = mDoc.DocumentNode.SelectNodes("//@style");
                    if (nCollection != null)
                    {
                        foreach (HtmlAgilityPack.HtmlNode n in nCollection)
                        {
                            string css = n.GetAttributeValue("style", "");
                            css = MinifyCSS(css);
                            n.SetAttributeValue("style", css);
                        }
                    }
                }

                #endregion

                ZetaHtmlCompressor.HtmlContentCompressor HtmlCompressor = new ZetaHtmlCompressor.HtmlContentCompressor();
                MemoryStream uncompressedStream = new MemoryStream();
                mDoc.Save(uncompressedStream);

                htmlString = UTF8Encoding.UTF8.GetString(uncompressedStream.ToArray());
                if (HTMLCompression == 1 || HTMLCompression == 2)
                {
                    // ASP.net tokens <%= ... %> can't be minifyed. Remove them, minify and add them back later.
                    Hashtable aspnettokens1 = null;
                    Hashtable aspnettokens2 = null;
                    Hashtable aspnettokens3 = null;
                    if (((string)configurationTable["Output"]).ToLower().EndsWith(".aspx")) {
                        aspnettokens1 = replaceWithTokens(ref htmlString, "<%=", "%>");
                        aspnettokens2 = replaceWithTokens(ref htmlString, "<%@", "%>\r\n");
                        aspnettokens3 = replaceWithTokens(ref htmlString, "<script runat=\"server\">", "</script>\r\n");
                    }

                    // ZETA HTML Minification
                    htmlString = HtmlCompressor.Compress(htmlString);

                    // When ZETA+ is selected, we do extra reduction
                    if (HTMLCompression == 2)
                    {
                        // Do additional minification things here
                        // Good reference: http://blog.teamtreehouse.com/to-close-or-not-to-close-tags-in-html5

                        // Many attributes dont need quoats...
                        htmlString = removeQuotesFromAttribute(htmlString, "type");
                        htmlString = removeQuotesFromAttribute(htmlString, "name");
                        htmlString = removeQuotesFromAttribute(htmlString, "id");
                        htmlString = removeQuotesFromAttribute(htmlString, "class");
                        htmlString = removeQuotesFromAttribute(htmlString, "onclick");
                        htmlString = removeQuotesFromAttribute(htmlString, "onchange");
                        htmlString = removeQuotesFromAttribute(htmlString, "value");
                        htmlString = removeQuotesFromAttribute(htmlString, "http-equiv");
                        htmlString = removeQuotesFromAttribute(htmlString, "content");
                        htmlString = removeQuotesFromAttribute(htmlString, "cellpadding");
                        htmlString = removeQuotesFromAttribute(htmlString, "cellspacing");
                        htmlString = removeQuotesFromAttribute(htmlString, "autocorrect");
                        htmlString = removeQuotesFromAttribute(htmlString, "autocapitalize");
                        htmlString = removeQuotesFromAttribute(htmlString, "onkeyup");
                        htmlString = removeQuotesFromAttribute(htmlString, "onkeydown");
                        htmlString = removeQuotesFromAttribute(htmlString, "onkeypress");
                        htmlString = removeQuotesFromAttribute(htmlString, "style");
                        htmlString = removeQuotesFromAttribute(htmlString, "oncontextmenu");
                        htmlString = removeQuotesFromAttribute(htmlString, "onmousedown");
                        htmlString = removeQuotesFromAttribute(htmlString, "onmouseup");
                        htmlString = removeQuotesFromAttribute(htmlString, "onmousemove");
                        htmlString = removeQuotesFromAttribute(htmlString, "placeholder");
                        htmlString = removeQuotesFromAttribute(htmlString, "width");
                        htmlString = removeQuotesFromAttribute(htmlString, "height");

                        // Some tags are auto-closing and so, don't need to be closed
                        htmlString = htmlString.Replace("</html>", "");
                        htmlString = htmlString.Replace("</head>", "");
                        htmlString = htmlString.Replace("</body>", "");
                        htmlString = htmlString.Replace("</p>", "");
                        htmlString = htmlString.Replace("</dt>", "");
                        htmlString = htmlString.Replace("</dd>", "");
                        htmlString = htmlString.Replace("</li>", "");
                        htmlString = htmlString.Replace("</option>", "");
                        htmlString = htmlString.Replace("</thread>", "");
                        htmlString = htmlString.Replace("</th>", "");
                        htmlString = htmlString.Replace("</tbody>", "");
                        htmlString = htmlString.Replace("</tr>", "");
                        htmlString = htmlString.Replace("</td>", "");
                        htmlString = htmlString.Replace("</tfoot>", "");
                        htmlString = htmlString.Replace("</colgroup>", "");

                        // Get the list of HTML element ID's and compress the ID's in the HTML
                        List<string> ids = getCompressableIdList(htmlString);
                        int i = 0;
                        foreach (string id in ids)
                        {
                            string c = i.ToString();
                            htmlString = htmlString.Replace(" id=" + id + " ", " id=" + c + " ");
                            htmlString = htmlString.Replace(" id=" + id + ">", " id=" + c + ">");
                            htmlString = htmlString.Replace("'" + id + "'", c);
                            htmlString = htmlString.Replace("\"" + id + "\"", c);
                            allJavaScript = allJavaScript.Replace("'" + id + "'", c);
                            allJavaScript = allJavaScript.Replace("\"" + id + "\"", c);
                            i++;
                        }

                        // Get the list of HTML element ID's and compress the ID's in the HTML
                        ids = getCompressableIdList2(htmlString);
                        i = 0;
                        foreach (string id in ids)
                        {
                            string c = "c" + i.ToString();
                            htmlString = htmlString.Replace(" id=" + id + " ", " id=" + c + " ");
                            htmlString = htmlString.Replace(" id=" + id + ">", " id=" + c + ">");
                            allJavaScript = allJavaScript.Replace("'" + id + "'", "'" + c + "'");
                            allJavaScript = allJavaScript.Replace("\"" + id + "\"", "\"" + c + "\"");
                            allJavaScript = allJavaScript.Replace(id + ".", c + ".");
                            i++;
                        }

                        // White spaces can be removed
                        htmlString = htmlString.Replace("> ", ">");
                        htmlString = htmlString.Replace(" <", "<");
                        htmlString = htmlString.Replace("> ", ">");
                        htmlString = htmlString.Replace(" <", "<");

                        // If two styles are back-to-back, remote this.
                        htmlString = htmlString.Replace("</style><style>", "");
                    }

                    // Put ASP.net tokens back in
                    if (aspnettokens1 != null) { foreach (string k in aspnettokens1.Keys) { htmlString = htmlString.Replace(k, (string)aspnettokens1[k]); } }
                    if (aspnettokens2 != null) { foreach (string k in aspnettokens2.Keys) { htmlString = htmlString.Replace(k, (string)aspnettokens2[k]); } }
                    if (aspnettokens3 != null) { foreach (string k in aspnettokens3.Keys) { htmlString = htmlString.Replace(k, (string)aspnettokens3[k]); } }
                }
                
                // In super advanced mode
                if (JSCompression == 4)
                {
                    // Replace all the renamed functions with the short names in the HTML
                    if (renameReportTable != null)
                    {
                        foreach (string k in renameReportTable.Keys) { htmlString = htmlString.Replace(k + "(", (string)renameReportTable[k] + "("); }
                    }

                    if (allJavaScript != null)
                    {
                        // Get rid of all ".windows" (Quite dangerous... but saves space... and seems to work)
                        allJavaScript = allJavaScript.Replace("in\r", "in ");
                        allJavaScript = allJavaScript.Replace("in\n", "in ");
                        allJavaScript = allJavaScript.Replace("instanceof\r", "in ");
                        allJavaScript = allJavaScript.Replace("instanceof\n", "in ");
                        allJavaScript = allJavaScript.Replace("\n", "");
                        allJavaScript = allJavaScript.Replace("\r", "");
                        allJavaScript = allJavaScript.Replace("(window.", "(");
                        allJavaScript = allJavaScript.Replace(";window.", ";");
                        allJavaScript = allJavaScript.Replace("=window.", "=");
                        allJavaScript = allJavaScript.Replace("}window.", "}");
                        allJavaScript = allJavaScript.Replace("?window.", "?");
                        allJavaScript = allJavaScript.Replace("+window.", "+");
                        allJavaScript = allJavaScript.Replace(",window.", ",");
                    }
                }

                // Add all Javascript at the end of the HTML
                if (allJavaScript != null)
                {
                    if (htmlString.EndsWith("</body> </html>"))
                    {
                        // If possible, but the script block within the html element.
                        htmlString = htmlString.Substring(0, htmlString.Length - 15) + allJavaScript + "</body></html>";
                    }
                    else if (htmlString.EndsWith("</body></html>"))
                    {
                        // If possible, but the script block within the html element.
                        htmlString = htmlString.Substring(0, htmlString.Length - 14) + allJavaScript + "</body></html>";
                    }
                    else if (htmlString.EndsWith("</html>"))
                    {
                        // If possible, but the script block within the html element.
                        htmlString = htmlString.Substring(0, htmlString.Length - 7) + allJavaScript + "</html>";
                    }
                    else
                    {
                        htmlString += allJavaScript;
                    }
                } 

                byte[] HTMLBuffer = UTF8Encoding.UTF8.GetBytes(htmlString);
                #endregion

                // Figure out the size of the minified html
                long MinifiedSize = HTMLBuffer.Length;

                // Figure out the size of the minified html
                long CompressedSize = 0;

                sourceFileBin = HTMLBuffer;

                if (configurationTable.ContainsKey("Output"))
                {
                    string outputFile = (string)configurationTable["Output"];
                    if (lang != "")
                    {
                        FileInfo x = new FileInfo(outputFile);
                        outputFile = x.FullName.Substring(0, x.FullName.Length - x.Extension.Length) + lang + x.Extension;
                    }
                    FileInfo outputFile2 = null;
                    try { outputFile2 = new FileInfo(outputFile); } catch (Exception) { }
                    if (outputFile2 != null)
                    {
                        // For outputs that required GZIP, lets do compression now
                        if (string.Compare(outputFile2.Extension, ".gz", true) == 0 || string.Compare(outputFile2.Extension, ".h", true) == 0 || string.Compare(outputFile2.Extension, ".js", true) == 0)
                        {
                            if (MainForm.Main != null) { MainForm.Main.displayStatus("GZIP compression of " + platformname + "..."); }

                            // Write the GZ compressed stream
                            MemoryStream gzStream = new MemoryStream();
                            using (System.IO.Compression.GZipStream gz = new System.IO.Compression.GZipStream(gzStream, System.IO.Compression.CompressionLevel.Optimal)) { gz.Write(HTMLBuffer, 0, HTMLBuffer.Length); }
                            sourceFileBin = gzStream.ToArray();

                            // If we want to perform advanced GZIP compression, do it now.
                            if (GZIPCompression == 1)
                            {
                                // Advanced GZIP compression (15 iterations)
                                string t = GetTempPath(platformname);
                                File.WriteAllBytes(Path.Combine(t, "advdef-" + platformname + ".gz"), sourceFileBin);
                                Process p = Run("advdef.exe", "-z -4 " + Path.Combine(t, "advdef-" + platformname + ".gz"));
                                while (p.HasExited == false) { System.Threading.Thread.Sleep(50); }
                                sourceFileBin = File.ReadAllBytes(Path.Combine(t, "advdef-" + platformname + ".gz"));
                                File.Delete(Path.Combine(t, "advdef - " + platformname + ".gz"));
                                ClearTempPath(t);
                            }
                            else if (GZIPCompression == 2)
                            {
                                // High GZIP compression (100 iterations)
                                string t = GetTempPath(platformname);
                                File.WriteAllBytes(Path.Combine(t, "advdef-" + platformname + ".gz"), sourceFileBin);
                                Process p = Run("advdef.exe", "-z -4 -i 100 " + Path.Combine(t, "advdef-" + platformname + ".gz"));
                                while (p.HasExited == false) { System.Threading.Thread.Sleep(50); }
                                sourceFileBin = File.ReadAllBytes(Path.Combine(t, "advdef-" + platformname + ".gz"));
                                File.Delete(Path.Combine(t, "advdef-" + platformname + ".gz"));
                                ClearTempPath(t);
                            }
                            else if (GZIPCompression == 3)
                            {
                                // Insane GZIP compression (1000 iterations)
                                string t = GetTempPath(platformname);
                                File.WriteAllBytes(Path.Combine(t, "advdef-" + platformname + ".gz"), sourceFileBin);
                                Process p = Run("advdef.exe", "-z -4 -i 1000 " + Path.Combine(t, "advdef-" + platformname + ".gz"));
                                while (p.HasExited == false) { System.Threading.Thread.Sleep(50); }
                                sourceFileBin = File.ReadAllBytes(Path.Combine(t, "advdef-" + platformname + ".gz"));
                                File.Delete(Path.Combine(t, "advdef-" + platformname + ".gz"));
                                ClearTempPath(t);
                            }

                            CompressedSize = sourceFileBin.Length;
                        }

                        // For outputs that required Brotli, lets do compression now
                        if (string.Compare(outputFile2.Extension, ".br", true) == 0)
                        {
                            if (MainForm.Main != null) { MainForm.Main.displayStatus("Brotli compression of " + platformname + "..."); }

                            {
                                // Insane Brotli compression
                                string t = GetTempPath(platformname);
                                File.WriteAllBytes(Path.Combine(t, "brotli-" + platformname + ".bin"), HTMLBuffer);
                                Process p = Run("Brotli.exe", "--in " + Path.Combine(t, "brotli-" + platformname + ".bin") + " --out " + Path.Combine(t, "brotli-" + platformname + ".br"));
                                while (p.HasExited == false) { System.Threading.Thread.Sleep(50); }
                                sourceFileBin = File.ReadAllBytes(Path.Combine(t, "brotli-" + platformname + ".br"));
                                File.Delete(Path.Combine(t, "brotli-" + platformname + ".bin"));
                                File.Delete(Path.Combine(t, "brotli-" + platformname + ".br"));
                                ClearTempPath(t);
                            }

                            CompressedSize = sourceFileBin.Length;
                        }

                        if (string.Compare(outputFile2.Extension, ".gz", true) == 0)
                        {
                            if (multiPlatform) { outputFile = outputFile.Substring(0, outputFile.Length - 3) + "-" + platform.Item1.Replace(" ", "") + ".gz"; }
                            using (FileStream str = new FileStream(outputFile, FileMode.Create, FileAccess.ReadWrite)) { str.Write(sourceFileBin, 0, sourceFileBin.Length); }
                        }
                        else if (string.Compare(outputFile2.Extension, ".br", true) == 0)
                        {
                            if (multiPlatform) { outputFile = outputFile.Substring(0, outputFile.Length - 3) + "-" + platform.Item1.Replace(" ", "") + ".br"; }
                            using (FileStream str = new FileStream(outputFile, FileMode.Create, FileAccess.ReadWrite)) { str.Write(sourceFileBin, 0, sourceFileBin.Length); }
                        }
                        else if (string.Compare(outputFile2.Extension, ".aspx", true) == 0)
                        {
                            if (multiPlatform) { outputFile = outputFile.Substring(0, outputFile.Length - 5) + "-" + platform.Item1.Replace(" ", "") + ".aspx"; }
                            using (FileStream str = new FileStream(outputFile, FileMode.Create, FileAccess.ReadWrite)) { str.Write(HTMLBuffer, 0, HTMLBuffer.Length); }
                        }
                        else if (string.Compare(outputFile2.Extension, ".html", true) == 0)
                        {
                            if (multiPlatform) { outputFile = outputFile.Substring(0, outputFile.Length - 5) + "-" + platform.Item1.Replace(" ", "") + ".html"; }
                            using (FileStream str = new FileStream(outputFile, FileMode.Create, FileAccess.ReadWrite)) { str.Write(HTMLBuffer, 0, HTMLBuffer.Length); }
                        }
                        else if (string.Compare(outputFile2.Extension, ".htm", true) == 0)
                        {
                            if (multiPlatform) { outputFile = outputFile.Substring(0, outputFile.Length - 4) + "-" + platform.Item1.Replace(" ", "") + ".htm"; }
                            using (FileStream str = new FileStream(outputFile, FileMode.Create, FileAccess.ReadWrite)) { str.Write(HTMLBuffer, 0, HTMLBuffer.Length); }
                        }
                        else if (string.Compare(outputFile2.Extension, ".h", true) == 0)
                        {
                            lock (sourceFile)
                            {
                                // Add this platform to the .h file
                                if (multiPlatform) { sourceFile.Append("#if defined(" + platform.Item1.Replace(" ", "") + ")\r\n"); }
                                sourceFile.Append("size_t " + variablename + "_len = " + sourceFileBin.Length.ToString() + ";\r\n");
                                sourceFile.Append("char* " + variablename + "_etag = \"" + CreateETag(sourceFileBin) + "\";\r\n");
                                sourceFile.Append("unsigned char " + variablename + "[" + sourceFileBin.Length.ToString() + "] = \r\n");
                                sourceFile.Append("{");
                                sourceFile.Append(InjectBytes(sourceFileBin, "\r\n   ", false));
                                sourceFile.Append("\r\n};\r\n");
                                if (multiPlatform) { sourceFile.Append("#endif\r\n"); }
                            }
                        }
                        else if (string.Compare(outputFile2.Extension, ".js", true) == 0)
                        {
                            lock (sourceFile)
                            {
                                // Add this platform to the .js file
                                string platformName = "";
                                if (multiPlatform) { platformName = platform.Item1.Replace(" ", "") + lang; }
                                sourceFile.Append("var " + platformName + "_" + variablename + "_etag = \"" + CreateETag(sourceFileBin) + "\";\r\n");
                                sourceFile.Append("var " + platformName + "_" + variablename + " = \"" + Convert.ToBase64String(sourceFileBin) + "\";\r\n");
                            }
                        }
                    }
                }

                if (MainForm.Main != null) { MainForm.Main.displayOutput(platform.Item1 + lang, MinifiedSize, CompressedSize, sourceFileBin); }
                displayEvent("  " + platform.Item1 + lang + ": " + MinifiedSize + " -> " + CompressedSize + "\r\n");
            }
        }

        public Hashtable replaceWithTokens(ref string html, string start, string end)
        {
            int i, j, ptr = 0;
            Hashtable r = new Hashtable();
            while ((i = html.IndexOf(start, ptr)) >= 0)
            {
                j = html.IndexOf(end, i + start.Length);
                if (j == -1) return r;
                string t1 = html.Substring(i, (j - i) + end.Length);
                string t2 = GetRandomHex(30);
                if (html[i - 1] != '"' && html[i - 1] != '\'') { t2 = "\"" + t2 + "\""; }
                r.Add(t2, t1);
                html = html.Substring(0, i)  + t2 + html.Substring(j + end.Length);
                ptr = i + start.Length;
            }
            return r;
        }

        public static RNGCryptoServiceProvider CryptoRandom = new RNGCryptoServiceProvider();
        public static string GetRandomHex(int len) { byte[] t = new byte[len]; CryptoRandom.GetBytes(t); return BytesToHex(t); }

        public string removeQuotesFromAttribute(string html, string attributename)
        {
            return removeQuotesFromAttributeEx(removeQuotesFromAttributeEx(html, attributename, "\""), attributename, "'");
        }

        public string removeQuotesFromAttributeEx(string html, string attributename, string q) {
            string str = " " + attributename + "=" + q;
            int i, j, ptr = 0;
            while ((i = html.IndexOf(str, ptr)) >= 0)
            {
                string x1 = html.Substring(0, i + str.Length - 1);
                j = html.IndexOf(q, i + str.Length);
                string x2 = html.Substring(i + str.Length, j - (i + str.Length));
                string x3 = html.Substring(j + 1);
                if (x2.EndsWith(";")) x2 = x2.Substring(0, x2.Length - 1); // If the attribute ends with ; remove it
                if (x2.IndexOf(" ") == -1 && x2.IndexOf("=") == -1 && x2.IndexOf("'") == -1 && x2.IndexOf("\"") == -1) html = x1 + x2 + x3; // Only remove quotes is there is no spaces in the value
                ptr = j;
            }
            return html;
        }

        public List<string> getIdList(string html)
        {
            string match = " id=";
            List<string> r = new List<string>();
            int i, j, ptr = 0;
            while ((i = html.IndexOf(match, ptr)) >= 0)
            {
                j = Math.Min(html.IndexOf(" ", i + match.Length), html.IndexOf(">", i + match.Length));
                string x1 = html.Substring(i + match.Length, j - i - match.Length);
                r.Add(x1);
                ptr = j;
            }
            return r;
        }

        public List<string> getCompressableIdList(string html)
        {
            string match = " id=id_";
            List<string> r = new List<string>();
            int i, j, ptr = 0;
            while ((i = html.IndexOf(match, ptr)) >= 0)
            {
                j = Math.Min(html.IndexOf(" ", i + 4), html.IndexOf(">", i + 4));
                string x1 = html.Substring(i + 4, j - i - 4);
                r.Add(x1);
                ptr = j;
            }
            return r;
        }

        public List<string> getCompressableIdList2(string html)
        {
            string match = " id=idx_";
            List<string> r = new List<string>();
            int i, j, ptr = 0;
            while ((i = html.IndexOf(match, ptr)) >= 0)
            {
                j = Math.Min(html.IndexOf(" ", i + 4), html.IndexOf(">", i + 4));
                string x1 = html.Substring(i + 4, j - i - 4);
                r.Add(x1);
                ptr = j;
            }
            return r;
        }

        public static string InjectBytes(byte[] inVal, string newLine, bool withTypeCast)
        {
            StringBuilder cs = new StringBuilder();
            cs.Append(newLine);

            for (int i = 0; i < inVal.Length; ++i)
            {
                byte b = inVal[i];
                string hx = b.ToString("X");
                if (withTypeCast) cs.Append("(char)");
                cs.Append("0x");
                if (hx.Length == 1) { cs.Append("0"); }
                cs.Append(hx);

                if (i != (inVal.Length - 1))
                {
                    cs.Append(",");
                    if (i != 0 && ((i + 1) % (withTypeCast ? 16 : 32) == 0)) cs.Append(newLine);
                }
            }
            return cs.ToString();
        }

        private static Process Run(string fileName, string args)
        {
            ProcessStartInfo info = new ProcessStartInfo(fileName, args);
            info.CreateNoWindow = true;
            info.UseShellExecute = false;
            info.WorkingDirectory = Application.StartupPath;
            Process processChild = Process.Start(info);
            return processChild;
        }

        private string GetJavaInstallationPath()
        {
            string environmentPath = Environment.GetEnvironmentVariable("JAVA_HOME");
            if (!string.IsNullOrEmpty(environmentPath)) { return environmentPath; }

            string javaKey = "SOFTWARE\\JavaSoft\\Java Runtime Environment\\";
            using (RegistryKey rk = Registry.LocalMachine.OpenSubKey(javaKey))
            {
                if ((rk != null) && (rk.GetValue("CurrentVersion") != null))
                {
                    string currentVersion = rk.GetValue("CurrentVersion").ToString();
                    using (RegistryKey key = rk.OpenSubKey(currentVersion))
                    {
                        if ((key != null) && (key.GetValue("JavaHome") != null)) { return key.GetValue("JavaHome").ToString(); }
                    }
                }
            }

            using (RegistryKey rk = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64))
            {
                if (rk != null)
                {
                    using (RegistryKey rk2 = rk.OpenSubKey(javaKey))
                    {
                        if ((rk2 != null) && (rk2.GetValue("CurrentVersion") != null))
                        {
                            string currentVersion = rk2.GetValue("CurrentVersion").ToString();
                            using (RegistryKey key = rk2.OpenSubKey(currentVersion))
                            {
                                if ((key != null) && (key.GetValue("JavaHome") != null)) { return key.GetValue("JavaHome").ToString(); }
                            }
                        }
                    }
                }
            }

            return null;
        }

        private string GetTempPath(string name)
        {
            string TempPath = Path.Combine(Path.GetTempPath(), "WebSiteCompiler-" + name);
            if (!Directory.Exists(TempPath)) Directory.CreateDirectory(TempPath);
            return TempPath;
        }

        private void ClearTempPath(string TempPath)
        {
            if (Directory.Exists(TempPath)) { Directory.Delete(TempPath, true); }
        }

        /// <summary>
        /// Get a binary comment to a .GZ file. Comments are null terminated and the return value will not include the null termination.
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        public static byte[] GetGZipComment(string file)
        {
            if (File.Exists(file) == false) return null;
            byte[] buf = File.ReadAllBytes(file);
            if ((buf[3] & (1 << 4)) == 0) return null;
            int i = 10;
            while (buf[i] != 0) { i++; }
            byte[] comment = new byte[i - 10];
            for (int j = 0; j < i - 10; j++) { comment[j] = buf[j + 10]; }
            return comment;
        }

        /// <summary>
        /// Set the comment feild of a .GZ file. Since comments are null terminated, the comment binary must not contain any zeroes.
        /// </summary>
        /// <param name="infile"></param>
        /// <param name="outfile"></param>
        /// <param name="comment"></param>
        /// <returns></returns>
        public static bool SetGZipComment(string infile, string outfile, byte[] comment)
        {
            if (File.Exists(infile) == false) return false;
            byte[] buf = File.ReadAllBytes(infile);
            if ((buf[3] & (1 << 4)) != 0) return false;
            buf[3] = (byte)(buf[3] | (1 << 4));
            byte[] output = new byte[buf.Length + comment.Length + 1];
            for (int i = 0; i < 10; i++) { output[i] = buf[i]; } // Copy header
            for (int i = 0; i < comment.Length; i++) { output[i + 10] = comment[i]; } // Copy comment
            for (int i = 0; i < buf.Length - 10; i++) { output[i + 11 + comment.Length] = buf[i + 10]; } // Copy content
            File.WriteAllBytes(outfile, output);
            return true;
        }

        public static string CreateETag(byte[] data) { using (SHA256 hasher = SHA256Managed.Create()) { return Convert.ToBase64String(hasher.ComputeHash(data)).Substring(0, 20); } }


        private static char[] hexlookup = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
        public static string BytesToHex(byte[] data)
        {
            if (data == null) return "";
            int i = 0, p = 0, l = data.Length;
            char[] c = new char[l * 2];
            byte d;
            while (i < l)
            {
                d = data[i++];
                c[p++] = hexlookup[d / 0x10];
                c[p++] = hexlookup[d % 0x10];
            }
            return new string(c, 0, c.Length);
        }

        public static string BytesToHex(byte[] data, int off, int len)
        {
            if (data == null) return "";
            int i = off, p = 0, end = off + len;
            char[] c = new char[len * 2];
            byte d;
            while (i < end)
            {
                d = data[i++];
                c[p++] = hexlookup[d / 0x10];
                c[p++] = hexlookup[d % 0x10];
            }
            return new string(c, 0, c.Length);
        }

        public static string BytesToHex(byte[] data, int spacing)
        {
            int i = 0, p = 0, l = data.Length;
            char[] c = new char[(l * 2) + (l / spacing)];
            byte d;
            while (i < l)
            {
                d = data[i++];
                c[p++] = hexlookup[d / 0x10];
                c[p++] = hexlookup[d % 0x10];
                if ((i % spacing) == 0) c[p++] = ' ';
            }
            return new string(c, 0, c.Length);
        }

        public static byte[] HexToBytes(string hex)
        {
            if (hex == null) return null;
            hex = hex.ToUpper();
            bool firstbyte = true;
            byte v = 0;
            ArrayList output = new ArrayList();
            foreach (char c in hex)
            {
                if (c >= '0' && c <= '9') v += (byte)(c - '0');
                else if (c >= 'A' && c <= 'F') v += (byte)((c - 'A') + 10);
                else continue;

                if (firstbyte)
                {
                    v = (byte)(v * 16);
                    firstbyte = false;
                }
                else
                {
                    output.Add(v);
                    v = 0;
                    firstbyte = true;
                }
            }
            return (byte[])output.ToArray(typeof(byte));
        }
    }
}
