WebSiteCompiler
---------------

WebSiteCompiler is a tool built in C# that takes a web application composed generally of one index.htm file and other support files (.css and .js)  and packs it into a compressed blob. The tool will do the following actions in sequence:

	- Merge the main index.htm and all supporting files into one file.
	- Perform pre-processing, removing any parts of HTML and JovaScript that is not needed.
	- Optionally minify the HTML, CSS and JavaScript.
	- Optionally compress the requet into a GZip file.
	- Save the output as .html or .gzip, or if selected a .cs or .js file where the output is encoded in base64.

The main objective of WebSiteCompiler is to pack a web application into a tiny space for use by embedded devices. You can make a fairly fancy web application and compress it download to a tiny blob that can be embeded into a small web server. Starting with Intel AMT 11.6, you can upload a web application into the firmware and so, WebSiteCompiler as designed to pack the most possible feature into the small firmware size of Intel AMT, but this tool has many other uses.

WebSite Compile is licensed under Apache 2.0 open source license, however it makes use of other tools that come from other places and so, these others files are subject to other licenses. Files that are from other sources include:

	advdef.exe
	Brotli.exe
	compiler.jar
	EcmaScript.NET.dll
	HtmlAgilityPack.dll
	Microsoft.QualityTools.Testing.Fakes.dll
	Yahoo.Yui.Compressor.dll
	ZetaHtmlCompressor.dll


License
-------

WebSiteCompiler is released under the Apache 2.0 open source license. You can see it here: https://www.apache.org/licenses/LICENSE-2.0
