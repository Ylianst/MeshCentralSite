﻿using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace WebSiteCompiler
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Hashtable settingsTable = null;
            bool compileFlag = false;
            bool exit = false;

            // Compress all .js files from one folder and put the results in a different folder.
            if ((args.Length > 0) && (args[0].ToLower() == "compressalljs") && (args.Length == 3))
            {
                string sourceFolder = args[1];
                string destFolder = args[2];
                if ((Directory.Exists(sourceFolder) == false) || (Directory.Exists(destFolder) == false)) { return; }

                Yahoo.Yui.Compressor.JavaScriptCompressor jc = new Yahoo.Yui.Compressor.JavaScriptCompressor();
                var jsFileNames = Directory.EnumerateFiles(sourceFolder, "*.js", SearchOption.AllDirectories);
                foreach (string jsFileName in jsFileNames)
                {
                    string jsFile = System.IO.File.ReadAllText(jsFileName);
                    jsFile = jc.Compress(jsFile);
                    FileInfo fi = new FileInfo(jsFileName);
                    string newFilename = fi.Name.Substring(0, fi.Name.Length - 3) + ".min.js";
                    string newFilePath = Path.Combine(destFolder, newFilename);
                    System.IO.File.WriteAllText(newFilePath, jsFile);
                }
                return;
            }

            foreach (string arg in args)
            {
                if (arg.EndsWith(".wcc"))
                {
                    System.Runtime.Serialization.Formatters.Binary.BinaryFormatter bf = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    if (File.Exists(arg))
                    {
                        using (FileStream fs = new FileStream(arg, FileMode.Open, FileAccess.Read))
                        {
                            settingsTable = (Hashtable)bf.Deserialize(fs);
                            if (settingsTable.Count > 0)
                            {
                                settingsTable["ConfigurationFile"] = arg;
                                settingsTable["WebSitePath"] = MainForm.MakeAbsolutePath(new FileInfo(arg).Directory.FullName, (string)settingsTable["WebSitePath"]);
                                settingsTable["Output"] = MainForm.MakeAbsolutePath(new FileInfo(arg).Directory.FullName, (string)settingsTable["Output"]);
                            }
                        }
                    }
                }

                if (arg.EndsWith(".js"))
                {
                    Yahoo.Yui.Compressor.JavaScriptCompressor jc = new Yahoo.Yui.Compressor.JavaScriptCompressor();
                    string jsFile = System.IO.File.ReadAllText(arg);
                    try
                    {
                        jsFile = jc.Compress(jsFile);
                    } catch (Exception ex) {
                        Console.Write(ex.ToString());
                    }
                    string newFilename = arg.Substring(0, arg.Length - 3) + ".min.js";
                    System.IO.File.WriteAllText(newFilename, jsFile);
                    exit = true;
                }

                if (arg == "-c")
                {
                    compileFlag = true;
                }
            }

            if (exit) return;

            if (settingsTable != null && compileFlag)
            {
                new GrandUnifier().CompressWebSite(settingsTable);
            }
            else
            {            
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainForm(settingsTable));
            }
        }
    }
}
