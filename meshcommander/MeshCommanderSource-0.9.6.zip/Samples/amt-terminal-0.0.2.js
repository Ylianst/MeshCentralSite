/** 
* @description Remote Terminal
* @author Ylian Saint-Hilaire
* @version v0.0.2c
*/

// Construct a MeshServer object
var CreateAmtRemoteTerminal = function (divid) {
    var obj = {};
    obj.DivId = divid;
    obj.DivElement = document.getElementById(divid);
    obj.protocol = 1; // SOL

    obj.Terminal_CellHeight = 21;
    obj.Terminal_CellWidth = 13;
    obj.TermColors = ['000000', 'BB0000', '00BB00', 'BBBB00', '0000BB', 'BB00BB', '00BBBB', 'BBBBBB', '555555', 'FF5555', '55FF55', 'FFFF55', '5555FF', 'FF55FF', '55FFFF', 'FFFFFF'];
    obj.TermCurrentReverse = 0;
    obj.TermCurrentFColor = 7;
    obj.TermCurrentBColor = 0;
    obj.TermLineWrap = true;
    obj.termx = 0;
    obj.termy = 0;
    obj.termstate = 0;
    obj.escNumber = [];
    obj.escNumberPtr = 0;
    obj.scratt = [];
    obj.tscreen = [];
    obj.VTUNDERLINE = 1;
    obj.VTREVERSE = 2;

    // Private method
    obj.Debug = function (msg) { console.log(msg); }

    obj.Start = function () { }

    obj.Init = function () {
        for (var y = 0; y < 25; y++) {
            obj.tscreen[y] = [];
            obj.scratt[y] = [];
            for (var x = 0; x < 80; x++) { obj.tscreen[y][x] = ' '; obj.scratt[y][x] = (7 << 6); }
        }
        obj.TermInit();
    }

    obj.xxStateChange = function(newstate) { }

    obj.ProcessData = function (str) { if (obj.capture != null) obj.capture += str; obj.ProcessVt100EscString(str); obj.TermDraw(); }

    obj.ProcessVt100EscString = function (str) { for (var i = 0; i < str.length; i++) obj.ProcessVt100EscChar(String.fromCharCode(str.charCodeAt(i)), str.charCodeAt(i)); }

    obj.ProcessVt100EscChar = function (b, c) {
        switch (obj.termstate) {
            case 0: // Normal Term State
                switch (c) {
                    case 27: // ESC
                        obj.termstate = 1;
                        break;
                    default:
                        // Process a single char
                        obj.ProcessVt100Char(b);
                        break;
                }
                break;
            case 1:
                switch (b) {
                    case '[':
                        obj.escNumberPtr = 0;
                        obj.escNumber = [];
                        obj.termstate = 2;
                        break;
                    case '(':
                        obj.termstate = 4;
                        break;
                    case ')':
                        obj.termstate = 5;
                        break;
                    default:
                        obj.termstate = 0;
                        break;
                }
                break;
            case 2:
                if (b >= '0' && b <= '9') {
                    // This is a number
                    if (!obj.escNumber[obj.escNumberPtr]) {
                        obj.escNumber[obj.escNumberPtr] = (b - '0');
                    }
                    else {
                        obj.escNumber[obj.escNumberPtr] = ((obj.escNumber[obj.escNumberPtr] * 10) + (b - '0'));
                    }
                    break;
                }
                else if (b == ';') {
                    // New number
                    obj.escNumberPtr++;
                    break;
                }
                else {
                    // Process Escape Sequence
                    if (!obj.escNumber[0]) obj.escNumber[0] = 0;
                    obj.ProcessEscapeHandler(b, obj.escNumber, obj.escNumberPtr + 1);
                    obj.termstate = 0;
                }
                break;
            case 4: // '(' Code
                obj.termstate = 0;
                break;
            case 5: // ')' Code
                obj.termstate = 0;
                break;
        }
    }

    obj.ProcessEscapeHandler = function (code, args, argslen) {
        var i;
        switch (code) {
            case 'c': // ResetDevice
                // Reset
                obj.TermResetScreen();
                break;
            case 'A': // Move cursor up n lines
                if (argslen == 1) {
                    obj.termy -= args[0];
                    if (obj.termy < 0) obj.termy = 0;
                }
                break;
            case 'B': // Move cursor down n lines
                if (argslen == 1) {
                    obj.termy += args[0];
                    if (obj.termy > 25) obj.termy = 25;
                }
                break;
            case 'C': // Move cursor right n lines
                if (argslen == 1) {
                    obj.termx += args[0];
                    if (obj.termx > 80) obj.termx = 80;
                }
                break;
            case 'D': // Move cursor left n lines
                if (argslen == 1) {
                    obj.termx -= args[0];
                    if (obj.termx < 0) obj.termx = 0;
                }
                break;
            case 'd': // Set cursor to line n
                if (argslen == 1) {
                    obj.termy = args[0] - 1;
                    if (obj.termy > 25) obj.termy = 25;
                    if (obj.termy < 0) obj.termy = 0;
                }
                break;
            case 'G': // Set cursor to col n
                if (argslen == 1) {
                    obj.termx = args[0] - 1;
                    if (obj.termx < 0) obj.termx = 0;
                    if (obj.termx > 79) obj.termx = 79;
                }
                break;
            case 'J': // ClearScreen:
                if (argslen == 1 && args[0] == 2) {
                    obj.TermClear((obj.TermCurrentBColor << 12) + (obj.TermCurrentFColor << 6)); // Erase entire screen
                    obj.termx = 0;
                    obj.termy = 0;
                }
                else if (argslen == 0 || argslen == 1 && args[0] == 0) // Erase cursor down
                {
                    obj.EraseCursorToEol();
                    for (i = obj.termy + 1; i < 25; i++) obj.EraseLine(i);
                }
                else if (argslen == 1 && args[0] == 1) // Erase cursor up
                {
                    obj.EraseCursorToEol();
                    for (i = 0; i < obj.termy - 1; i++) obj.EraseLine(i);
                }
                break;
            case 'H': // MoveCursor:
                if (argslen == 2) {
                    if (args[0] < 1) args[0] = 1;
                    if (args[1] < 1) args[1] = 1;
                    if (args[0] > 25) args[0] = 25;
                    if (args[1] > 80) args[1] = 80;
                    obj.termy = args[0] - 1;
                    obj.termx = args[1] - 1;
                }
                else {
                    obj.termy = 0;
                    obj.termx = 0;
                }
                break;
            case 'm': // ScreenAttribs:
                // Change attributes
                for (i = 0; i < argslen; i++) {
                    if (!args[i] || args[i] == 0) {
                        // Reset Attributes
                        obj.TermCurrentBColor = 0;
                        obj.TermCurrentFColor = 7;
                        obj.TermCurrentReverse = 0;
                    }
                    else if (args[i] == 1) {
                        // Bright
                        if (obj.TermCurrentFColor < 8) obj.TermCurrentFColor += 8;
                    }
                    else if (args[i] == 2 || args[i] == 22) {
                        // Dim
                        if (obj.TermCurrentFColor >= 8) obj.TermCurrentFColor -= 8;
                    }
                    else if (args[i] == 7) {
                        // Set Reverse attribute true
                        obj.TermCurrentReverse = 2;
                    }
                    else if (args[i] == 27) {
                        // Set Reverse attribute false
                        obj.TermCurrentReverse = 0;
                    }
                    else if (args[i] >= 30 && args[i] <= 37) {
                        // Set Foreground Color
                        var bright = (obj.TermCurrentFColor >= 8);
                        obj.TermCurrentFColor = (args[i] - 30);
                        if (bright && obj.TermCurrentFColor <= 8) obj.TermCurrentFColor += 8;
                    }
                    else if (args[i] >= 40 && args[i] <= 47) {
                        // Set Background Color
                        obj.TermCurrentBColor = (args[i] - 40);
                    }
                    else if (args[i] >= 90 && args[i] <= 99) {
                        // Set Bright Foreground Color
                        obj.TermCurrentFColor = (args[i] - 82);
                    }
                    else if (args[i] >= 100 && args[i] <= 109) {
                        // Set Bright Background Color
                        obj.TermCurrentBColor = (args[i] - 92);
                    }
                }
                break;
            case 'K': // EraseLine:
                if (argslen == 0 || (argslen == 1 && (!args[0] || args[0] == 0))) {
                    obj.EraseCursorToEol(); // Erase from the cursor to the end of the line
                }
                else if (argslen == 1) {
                    if (args[0] == 1) // Erase from the beginning of the line to the cursor
                    {
                        obj.EraseBolToCursor();
                    }
                    else if (args[0] == 2) // Erase the line with the cursor
                    {
                        obj.EraseLine(obj.termy);
                    }
                }
                break;
            case 'h': // EnableLineWrap:
                obj.TermLineWrap = true;
                break;
            case 'l': // DisableLineWrap:
                obj.TermLineWrap = false;
                break;
            default:
                //if (code != '@') alert(code);
                break;
        }
    }

    obj.ProcessVt100String = function (str) {
        for (var i = 0; i < str.length; i++) obj.ProcessVt100Char(String.fromCharCode(str.charCodeAt(i)));
    }

    obj.ProcessVt100Char = function (c) {
        // ANSI - Extended ASCII emulation.
        //if ((c & 0x80) != 0) c = AsciiToUnicode[c & 0x7F];

        if (c == '\0' || c.charCodeAt() == 7) return; // Ignore null & bell

        var ch = c.charCodeAt();
        //if (ch < 32 && ch != 10 && ch != 13) alert(ch);
        switch (ch) {
            case 24: { c = '↑'; break; }
            case 25: { c = '↓'; break; }
        }

        if (obj.termx > 80) obj.termx = 80;
        if (obj.termy > 24) obj.termy = 24;

        switch (c) {
            case '\b': // Backspace
                if (obj.termx > 0) {
                    obj.termx = obj.termx - 1;
                    obj.TermDrawChar(' ');
                }
                break;
            case '\t': // tab
                var tab = 8 - (obj.termx % 8)
                for (var x = 0; x < tab; x++) obj.ProcessVt100Char(" ");
                break;
            case '\n': // Linefeed
                obj.termy++;
                if (obj.termy > 24) {
                    // Move everything up one line
                    obj.TermMoveUp(1);
                    obj.termy = 24;
                }
                break;
            case '\r': // Carriage Return
                obj.termx = 0;
                break;
            default:
                if (obj.termx >= 80) {
                    obj.termx = 0;
                    if (obj.TermLineWrap) { obj.termy++; }
                    if (obj.termy >= 24) { obj.TermMoveUp(1); obj.termy = 24; }
                }
                obj.TermDrawChar(c);
                obj.termx++;
                break;
        }

    }

    obj.TermDrawChar = function(c) {
        obj.tscreen[obj.termy][obj.termx] = c;
        obj.scratt[obj.termy][obj.termx] = (obj.TermCurrentFColor << 6) + (obj.TermCurrentBColor << 12) + obj.TermCurrentReverse;
    }

    obj.TermClear = function(TermColor) {
        for (var y = 0; y < 25; y++) {
            for (var x = 0; x < 80; x++) {
                obj.tscreen[y][x] = ' ';
                obj.scratt[y][x] = TermColor;
            }
        }
    }

    obj.TermResetScreen = function () {
        obj.TermCurrentReverse = 0;
        obj.TermCurrentFColor = 7;
        obj.TermCurrentBColor = 0;
        obj.TermLineWrap = true;
        obj.termx = 0;
        obj.termy = 0;
        obj.TermClear(7 << 6);
    }

    obj.EraseCursorToEol = function () {
        var t = (obj.TermCurrentBColor << 12);
        for (var x = obj.termx; x < 80; x++) {
            obj.tscreen[obj.termy][x] = ' ';
            obj.scratt[obj.termy][x] = t;
        }
    }

    obj.EraseBolToCursor = function() {
        var t = (obj.TermCurrentBColor << 12);
        for (var x = 0; x < obj.termx; x++) {
            obj.tscreen[obj.termy][x] = ' ';
            obj.scratt[obj.termy][x] = t;
        }
    }

    obj.EraseLine = function (line) {
        var t = (obj.TermCurrentBColor << 12);
        for (var x = 0; x < 80; x++) {
            obj.tscreen[line][x] = ' ';
            obj.scratt[line][x] = t;
        }
    }

    obj.TermSendKeys = function(keys) { obj.parent.Send(keys); }
    obj.TermSendKey = function(key) { obj.parent.Send(String.fromCharCode(key)); }

    obj.TermMoveUp = function(linecount) {
        var x, y;
        for (y = 0; y < 25 - linecount; y++) {
            obj.tscreen[y] = obj.tscreen[y + linecount];
            obj.scratt[y] = obj.scratt[y + linecount];
        }
        for (y = 25 - linecount; y < 25; y++) {
            obj.tscreen[y] = [];
            obj.scratt[y] = [];
            for (x = 0; x < 80; x++) {
                obj.tscreen[y][x] = ' ';
                obj.scratt[y][x] = (7 << 6);
            }
        }
    }

    obj.TermHandleKeys = function(e) {
        if (!e.ctrlKey) {
            if (e.which == 127) obj.TermSendKey(8);
            else if (e.which == 13) obj.TermSendKeys("\r\n");
            else if (e.which != 0) obj.TermSendKey(e.which);
            return false;
        }
        if (e.preventDefault) e.preventDefault();
        if (e.stopPropagation) e.stopPropagation();
    }

    obj.TermHandleKeyUp = function(e) {
        if (e.which != 8 && e.which != 32) return true;
        if (e.preventDefault) e.preventDefault();
        if (e.stopPropagation) e.stopPropagation();
        return false;
    }

    obj.TermHandleKeyDown = function (e) {
        if (e.which >= 65 && e.ctrlKey <= 90 && e.ctrlKey) {
            obj.TermSendKey(e.which - 64);
            if (e.preventDefault) e.preventDefault();
            if (e.stopPropagation) e.stopPropagation();
            return;
        }
        if (e.which == 27) { obj.TermSendKeys(String.fromCharCode(27)); return true }; // ESC
        if (e.which == 37) { obj.TermSendKeys(String.fromCharCode(27, 91, 68)); return true }; // Left
        if (e.which == 38) { obj.TermSendKeys(String.fromCharCode(27, 91, 65)); return true }; // Up
        if (e.which == 39) { obj.TermSendKeys(String.fromCharCode(27, 91, 67)); return true }; // Right
        if (e.which == 40) { obj.TermSendKeys(String.fromCharCode(27, 91, 66)); return true }; // Down

        if (e.which != 8 && e.which != 32) return true;
        obj.TermSendKey(e.which);
        if (e.preventDefault) e.preventDefault();
        if (e.stopPropagation) e.stopPropagation();
        return false;
    }

    obj.TermDraw = function() {
        var c, buf = '', closetag = '', newat, oldat = 1, x1, x2;
        for (var y = 0; y < 25; ++y) {
            for (var x = 0; x < 80; ++x) {
                newat = obj.scratt[y][x];
                if (obj.termx == x && obj.termy == y) { newat |= obj.VTREVERSE; } // If this is the cursor location, reverse the color.
                if (newat != oldat) {
                    buf += closetag;
                    closetag = '';
                    x1 = 6; x2 = 12;
                    if (newat & obj.VTREVERSE) { x1 = 12; x2 = 6;}
                    buf += '<span style="color:#' + obj.TermColors[(newat >> x1) & 0x3F] + ';background-color:#' + obj.TermColors[(newat >> x2) & 0x3F];
                    if (newat & obj.VTUNDERLINE) buf += ';text-decoration:underline';
                    buf += ';">';
                    closetag = "</span>" + closetag;
                    oldat = newat;
                }

                c = obj.tscreen[y][x];
                switch (c) {
                    case '&':
                        buf += '&amp;'; break;
                    case '<':
                        buf += '&lt;'; break;
                    case '>':
                        buf += '&gt;'; break;
                    case ' ':
                        buf += '&nbsp;'; break;
                    default:
                        buf += c;
                        break;
                }
            }
            if (y != 24) buf += '<br>';
        }
        obj.DivElement.innerHTML = "<font size='4'><b>" + buf + closetag + "</b></font>";
    }

    obj.TermInit = function () { obj.TermResetScreen(); }
    
    obj.Init();
    obj.TermDraw();
    return obj;
}