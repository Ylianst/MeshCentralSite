These samples are intended to run in NW.js, but the source code can be adapted to run in a browser or in node.js. To get the samples working, download NW.js at http://nwjs.io/. Then, run nw.exe and drag & drop a sample into the frame.

To make these samples work on IIS:
   - Replace "amt-wsman-node-0.2.0.js" with "amt-wsman-ws-0.2.0.js" at the start of each sample.
   - Replace "amt-redir-node-0.2.0.js" with "amt-redir-ws-0.2.0.js" at the start of some samples.
   - Add "web.config" and "webrelays.ashx" from the Commander IIS folder.
   - Put everything in an IIS8 folder with .NET 4.5 installed.

