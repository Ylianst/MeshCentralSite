﻿using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Security.Principal;
using System.Security.Cryptography;
using NSspi;
using NSspi.Contexts;
using NSspi.Credentials;

namespace ManageabilityCommander
{
    public class IntelAmtDevice
    {
        public string host;
        public string user;
        public string pass;
        public int tls;
    }

    public enum EventSeverity
    {
        Information,
        Warning,
        Error
    }

    public delegate void onDebugHandler(EventSeverity severity, string msg);

    public interface WebSocketInterceptor
    {
        // Debug event
        event onDebugHandler onDebug;

        byte[] processAmtData(byte[] data, int off, int len, out bool error);
        byte[] processBrowserData(byte[] data, int off, int len, out bool error);
    }

    public class WebSocketInterceptorNULL : WebSocketInterceptor
    {
        public event onDebugHandler onDebug;
        public WebSocketInterceptorNULL(Hashtable args) { }

        public byte[] processAmtData(byte[] data, int off, int len, out bool error)
        {
            error = false;
            if (off == 0 && data.Length == len) return data;
            byte[] r = new byte[len];
            Array.Copy(data, off, r, 0, len);
            return r;
        }

        public byte[] processBrowserData(byte[] data, int off, int len, out bool error)
        {
            error = false;
            if (off == 0 && data.Length == len) return data;
            byte[] r = new byte[len];
            Array.Copy(data, off, r, 0, len);
            return r;
        }
    }

    public class WebSocketInterceptorWSMAN : WebSocketInterceptor
    {
        private enum AccMode
        {
            ProcessingHttpHeader = 0,
            ProcessingHttpLengthBody = 1,
            ProcessingHttpChunkedBody = 2,
            ProcessingHttpUntilClose = 3
        }

        public event onDebugHandler onDebug;
        private string host = null;
        private int port = 0;
        private int serverauth = 0;
        string digestUsername = null;
        string digestPassword = null;
        private static Hashtable wwwauthentications = new Hashtable();

        public WebSocketInterceptorWSMAN(string host, int port, Hashtable args, string digestUsername, string digestPassword)
        {
            this.host = host;
            this.port = port;
            this.digestUsername = digestUsername;
            this.digestPassword = digestPassword;
            if (args.ContainsKey("serverauth")) int.TryParse((string)args["serverauth"], out serverauth);
        }

        private byte[] accAmt = new byte[65535];
        private AccMode accAmtMode = AccMode.ProcessingHttpHeader;
        private int accAmtCount = 0;
        private int accAmtPtr = 0;
        private int accAmtLen = 0;
        private MemoryStream sendAmtBuffer = new MemoryStream();

        private string amtDirective = null;
        private string amtPath = null;
        private string amtHttpProtocol = null;
        private Hashtable amtHttpHeaders = new Hashtable();

        public byte[] processAmtData(byte[] data, int off, int len, out bool error)
        {
            error = false;

            // Add new data to accumulator
            Array.Copy(data, off, accAmt, accAmtPtr + accAmtLen, len);
            accAmtLen += len;

            // Process as much data as possible
            int r = 0;
            do { r = processAmtDataEx(accAmt, accAmtPtr, accAmtLen); accAmtPtr += r; accAmtLen -= r; } while (r != 0);
            if (r < 0) { error = true; return null; }

            // Move the rest to the front of the accumulator
            if (accAmtPtr != 0) { if (accAmtLen != 0) { Array.Copy(accAmt, accAmtPtr, accAmt, 0, accAmtLen); } accAmtPtr = 0; }

            // Send any outgoing data
            byte[] output = sendAmtBuffer.ToArray();
            sendAmtBuffer.SetLength(0);
            return output;
        }

        public int processAmtDataEx(byte[] data, int off, int len)
        {
            if (len == 0) return 0;
            if (accAmtMode == AccMode.ProcessingHttpHeader)
            {
                // See if we have a complete HTTP header & start decoding it.
                string request = ASCIIEncoding.ASCII.GetString(data, off, len);

                // This is a HTTP request
                int headerend = request.IndexOf("\r\n\r\n");
                if (headerend < 0) return 0;
                request = request.Substring(0, headerend);
                string[] headerlines = request.Split(new string[] { "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
                if (headerlines.Length < 2) return -1;

                // Process the directive
                string[] directive = headerlines[0].Split(' ');
                if (directive.Length != 3) return -1;
                amtDirective = directive[0];
                amtPath = directive[1];
                amtHttpProtocol = directive[2];

                // Process the rest of the header
                amtHttpHeaders.Clear();
                foreach (string line in headerlines)
                {
                    int i = line.IndexOf(':');
                    if (i > 0) {
                        if (!amtHttpHeaders.ContainsKey(line.Substring(0, i).ToLower())) amtHttpHeaders[line.Substring(0, i).ToLower()] = line.Substring(i + 1).Trim(); 
                    }
                }

                // If "www-authenticate" header is present, keep it. We may need it later.
                if (amtHttpHeaders.ContainsKey("www-authenticate")) { wwwauthentications[host + ":" + port] = (string)amtHttpHeaders["www-authenticate"]; }

                // Check what body encoding is present
                if (amtHttpHeaders.ContainsKey("content-length"))
                {
                    int.TryParse((string)amtHttpHeaders["content-length"], out accAmtCount);
                    if (accAmtCount > 0) accAmtMode = AccMode.ProcessingHttpLengthBody; else accAmtMode = AccMode.ProcessingHttpHeader;
                }
                else if (amtHttpHeaders.ContainsKey("transfer-encoding") && (string)amtHttpHeaders["transfer-encoding"] == "chunked")
                {
                    accAmtMode = AccMode.ProcessingHttpChunkedBody;
                }
                else
                {
                    accAmtMode = AccMode.ProcessingHttpUntilClose;
                }

                // Reform the new outgoing HTTP header
                StringBuilder sb = new StringBuilder();
                sb.Append(headerlines[0]);
                sb.Append("\r\n");
                foreach (string key in amtHttpHeaders.Keys) { sb.Append(key); sb.Append(": "); sb.Append(amtHttpHeaders[key]); sb.Append("\r\n"); }
                sb.Append("\r\n");

                // Send the new outgoing HTTP header
                string x = sb.ToString();
                byte[] buf = ASCIIEncoding.ASCII.GetBytes(x);
                sendAmtBuffer.Write(buf, 0, buf.Length);

                return headerend + 4;
            }
            else if (accAmtMode == AccMode.ProcessingHttpLengthBody)
            {
                int rl = len;
                if (rl > accAmtCount) rl = accAmtCount;
                accAmtCount -= rl;
                sendAmtBuffer.Write(data, off, rl);
                if (accAmtCount == 0) { accAmtMode = AccMode.ProcessingHttpHeader; }
                return rl;
            }
            else if (accAmtMode == AccMode.ProcessingHttpChunkedBody)
            {
                string request = ASCIIEncoding.ASCII.GetString(data, off, len);
                int i = request.IndexOf("\r\n");
                if (i < 0) return 0;
                int chunksize = Convert.ToInt32(request.Substring(0, i), 16);
                if (chunksize == 0 && len >= i + 4)
                {
                    // Send the ending chunk (NOTE: We do not support trailing headers)
                    sendAmtBuffer.Write(data, off, i + 4);
                    accAmtMode = AccMode.ProcessingHttpHeader;
                    return i + 4;
                }
                else if (chunksize > 0 && len >= i + chunksize + 4)
                {
                    // Send a chunk
                    sendAmtBuffer.Write(data, off, i + chunksize + 4);
                    return i + chunksize + 4;
                }
                return 0;
            }

            sendAmtBuffer.Write(data, off, len);
            return len;
        }

        private byte[] accWs = new byte[65535];
        private AccMode accWsMode = AccMode.ProcessingHttpHeader;
        private int accWsCount = 0;
        private int accWsPtr = 0;
        private int accWsLen = 0;
        private MemoryStream sendWsBuffer = new MemoryStream();

        private string wsDirective = null;
        private string wsPath = null;
        private string wsHttpProtocol = null;
        private Hashtable wsHttpHeaders = new Hashtable();
        private static string wsAuthCNonce = Utils.GetRandomAlphaNumeric(12);
        private static int wsAuthNonceCount = 1;

        private bool hasKerberosTicket = false;

        public byte[] processBrowserData(byte[] data, int off, int len, out bool error)
        {
            error = false;
            // Add new data to accumulator
            Array.Copy(data, off, accWs, accWsPtr + accWsLen, len);
            accWsLen += len;

            // Process as much data as possible
            int r = 0;
            do { r = processWsDataEx(accWs, accWsPtr, accWsLen); accWsPtr += r; accWsLen -= r; } while (r != 0);
            if (r == -1) { error = true; return null; }

            // Move the rest to the front of the accumulator
            if (accWsPtr != 0) { if (accWsLen != 0) { Array.Copy(accWs, accWsPtr, accWs, 0, accWsLen); } accWsPtr = 0; }

            // Send any outgoing data
            byte[] output = sendWsBuffer.ToArray();
            sendWsBuffer.SetLength(0);

            return output;
        }

        public int processWsDataEx(byte[] data, int off, int len)
        {
            if (len == 0) return 0;
            if (accWsMode == AccMode.ProcessingHttpHeader)
            {
                // See if we have a complete HTTP header & start decoding it.
                string request = ASCIIEncoding.ASCII.GetString(data, off, len);

                // This is a HTTP request
                int headerend = request.IndexOf("\r\n\r\n");
                if (headerend < 0) return 0;
                request = request.Substring(0, headerend);
                string[] headerlines = request.Split(new string[] { "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
                if (headerlines.Length < 2) return -1;

                // Process the directive
                string[] directive = headerlines[0].Split(' ');
                if (directive.Length != 3) return -1;
                wsDirective = directive[0];
                wsPath = directive[1];
                wsHttpProtocol = directive[2];

                // Process the rest of the header
                wsHttpHeaders.Clear();
                foreach (string line in headerlines)
                {
                    int i = line.IndexOf(':');
                    if (i > 0) { wsHttpHeaders.Add(line.Substring(0, i).ToLower(), line.Substring(i + 1).Trim()); }
                }

                // Check what body encoding is present
                if (wsHttpHeaders.ContainsKey("Content-Length"))
                {
                    int.TryParse((string)wsHttpHeaders["content-length"], out accWsCount);
                    if (accWsCount > 0) accWsMode = AccMode.ProcessingHttpLengthBody; else accWsMode = AccMode.ProcessingHttpHeader;
                }
                else if (wsHttpHeaders.ContainsKey("transfer-encoding") && (string)wsHttpHeaders["transfer-encoding"] == "chunked")
                {
                    accWsMode = AccMode.ProcessingHttpChunkedBody;
                }
                else
                {
                    accWsMode = AccMode.ProcessingHttpUntilClose;
                }

                // Fix the header to add Kerberos if needed
                if (serverauth != 0)
                {
                    if (digestUsername != null && digestPassword != null)
                    {
                        // Attempt server-side digest authentication
                        if (wwwauthentications.ContainsKey(host + ":" + port))
                        {
                            // We have authentication data, lets use it.
                            Hashtable AuthArgs = GetAuthArgs((string)wwwauthentications[host + ":" + port]);
                            string hash = ComputeDigesthash(digestUsername, digestPassword, (string)AuthArgs["realm"], wsDirective, wsPath, (string)AuthArgs["qop"], (string)AuthArgs["nonce"], wsAuthNonceCount.ToString(), wsAuthCNonce);
                            string authstr = string.Format("Digest username=\"{0}\",realm=\"{1}\",nonce=\"{2}\",uri=\"{3}\",qop={4},nc={5},cnonce=\"{6}\",response=\"{7}\"", digestUsername, (string)AuthArgs["realm"], (string)AuthArgs["nonce"], wsPath, (string)AuthArgs["qop"], wsAuthNonceCount.ToString(), wsAuthCNonce, hash);
                            if (AuthArgs.ContainsKey("opaque")) { authstr += string.Format(",opaque=\"{0}\"", AuthArgs["opaque"]); }
                            wsHttpHeaders["authorization"] = authstr;
                            wsAuthNonceCount++;
                        }
                    }
                    else if(!hasKerberosTicket)
                    {
                        // Attempt server-side kerberos authentication
                        bool worked = false;
                        try
                        {
                            // Try getting a ticket with both host and port
                            string principal = "HTTP/" + host + ":" + port;
                            byte[] clientToken = null;
                            ClientCredential clientCred = new ClientCredential(PackageNames.Kerberos);
                            ClientContext client = new ClientContext(clientCred, principal, ContextAttrib.Confidentiality | ContextAttrib.ReplayDetect | ContextAttrib.SequenceDetect | ContextAttrib.Delegate);
                            SecurityStatus clientStatus = client.Init(null, out clientToken);
                            wsHttpHeaders["authorization"] = "Kerberos " + Convert.ToBase64String(clientToken);
                            worked = true;
                        }
                        catch (Exception ex) { if (onDebug != null) onDebug(EventSeverity.Warning, ex.ToString()); }
                        if (worked == false)
                        {
                            try
                            {
                                // Try to get a ticket with just the host
                                string principal = "HTTP/" + host;
                                byte[] clientToken = null;
                                ClientCredential clientCred = new ClientCredential(PackageNames.Kerberos);
                                ClientContext client = new ClientContext(clientCred, principal, ContextAttrib.Confidentiality | ContextAttrib.ReplayDetect | ContextAttrib.SequenceDetect | ContextAttrib.Delegate);
                                wsHttpHeaders["authorization"] = "Kerberos " + Convert.ToBase64String(clientToken);
                                worked = true;
                            }
                            catch (Exception ex) { if (onDebug != null) onDebug(EventSeverity.Error, ex.ToString()); }
                        }

                        if (worked == false)
                        {
                            // Unable to get a kerberos ticket
                            return -1;
                        }
                        else
                        {
                            hasKerberosTicket = true;
                        }
                    }
                    else
                    {
                        // Remove the authorization header as we don't want this header from browser to reach AMT
                        wsHttpHeaders.Remove("authorization");
                    }
                }

                // Reform the new outgoing HTTP header
                StringBuilder sb = new StringBuilder();
                sb.Append(headerlines[0]);
                sb.Append("\r\n");
                foreach (string key in wsHttpHeaders.Keys) { sb.Append(key); sb.Append(": "); sb.Append(wsHttpHeaders[key]); sb.Append("\r\n"); }
                sb.Append("\r\n");

                // Send the new outgoing HTTP header
                string x = sb.ToString();
                byte[] buf = ASCIIEncoding.ASCII.GetBytes(x);
                sendWsBuffer.Write(buf, 0, buf.Length);

                return headerend + 4;
            }
            else if (accWsMode == AccMode.ProcessingHttpLengthBody)
            {
                int rl = len;
                if (rl > accWsCount) rl = accWsCount;
                accWsCount -= rl;
                sendWsBuffer.Write(data, off, rl);
                if (accWsCount == 0) accWsMode = AccMode.ProcessingHttpHeader;
                return rl;
            }
            else if (accWsMode == AccMode.ProcessingHttpChunkedBody)
            {
                string request = ASCIIEncoding.ASCII.GetString(data, off, len);
                int i = request.IndexOf("\r\n");
                if (i < 0) return 0;
                int chunksize = Convert.ToInt32(request.Substring(0, i), 16);
                if (chunksize == 0 && len >= i + 4)
                {
                    // Send the ending chunk (NOTE: We do not support trailing headers)
                    sendWsBuffer.Write(data, off, i + 4);
                    accWsMode = AccMode.ProcessingHttpHeader;
                    return i + 4;
                }
                else if (chunksize > 0 && len >= i + chunksize + 4)
                {
                    // Send a chunk
                    sendWsBuffer.Write(data, off, i + chunksize + 4);
                    return i + chunksize + 4;
                }
                return 0;
            }

            sendWsBuffer.Write(data, off, len);

            return len;
        }

        // Process the autorization arguments
        private Hashtable GetAuthArgs(string authheader)
        {
            try
            {
                string[] authargsstr = authheader.Substring(7).Split(',');
                Hashtable authargs = new Hashtable();
                foreach (string argstr in authargsstr)
                {
                    int i = argstr.IndexOf('=');
                    string k = argstr.Substring(0, i).Trim().ToLower();
                    string v = argstr.Substring(i + 1).Trim();
                    if (v.StartsWith("\"")) { v = v.Substring(1, v.Length - 2); }
                    if (i > 0) { authargs.Add(k, v); }
                }
                return authargs;
            }
            catch (Exception) { return null; }
        }

        private string ComputeDigesthash(string username, string password, string realm, string method, string path, string qop, string nonce, string nc, string cnonce)
        {
            using (MD5 md5Hash = MD5.Create())
            {
                string ha1 = Utils.BytesToHex(md5Hash.ComputeHash(Encoding.ASCII.GetBytes(username + ":" + realm + ":" + password))).ToLower();
                string ha2 = Utils.BytesToHex(md5Hash.ComputeHash(Encoding.ASCII.GetBytes(method + ":" + path))).ToLower();
                return Utils.BytesToHex(md5Hash.ComputeHash(Encoding.ASCII.GetBytes(ha1 + ":" + nonce + ":" + nc + ":" + cnonce + ":" + qop + ":" + ha2))).ToLower();
            }
        }
    }

    public class WebSocketInterceptorREDIR : WebSocketInterceptor
    {
        private enum RedirectCommands
        {
            StartRedirectionSession = 0x10,
            StartRedirectionSessionReply = 0x11,
            EndRedirectionSession = 0x12,
            AuthenticateSession = 0x13,
            AuthenticateSessionReply = 0x14,
        }

        private enum StartRedirectionSessionReplyStatus
        {
            SUCCESS = 0,
            TYPE_UNKNOWN = 1,
            BUSY = 2,
            UNSUPPORTED = 3,
            ERROR = 0xFF,
        }

        private enum AuthenticationStatus
        {
            SUCCESS = 0,
            FALIURE = 1,
            NOTSUPPORTED = 2,
        }

        private enum AuthenticationType
        {
            QUERY = 0,
            USERPASS = 1,
            KERBEROS = 2,
            BADDIGEST = 3,
            DIGEST = 4
        }

        public event onDebugHandler onDebug;
        private string host = null;
        private int port = 0;
        private int serverauth = 0;
        private string digestUsername = null;
        private string digestPassword = null;
        private Hashtable wwwauthentication = new Hashtable();

        public WebSocketInterceptorREDIR(string host, int port, Hashtable args, string digestUsername, string digestPassword)
        {
            this.host = host;
            this.port = port;
            this.digestUsername = digestUsername;
            this.digestPassword = digestPassword;
            if (args.ContainsKey("serverauth")) int.TryParse((string)args["serverauth"], out serverauth);
        }

        private byte[] accAmt = new byte[65535];
        private int accAmtPtr = 0;
        private int accAmtLen = 0;
        private bool accAmtDirect = false;
        private MemoryStream sendAmtBuffer = new MemoryStream();
        private string digestRealm = null;
        private string digestNonce = null;
        private string digestQOP = null;

        private bool hasKerberosTicket = false;
        public byte[] processAmtData(byte[] data, int off, int len, out bool error)
        {
            error = false;

            // Add new data to accumulator
            Array.Copy(data, off, accAmt, accAmtPtr + accAmtLen, len);
            accAmtLen += len;

            // Process as much data as possible
            int r = 0;
            do { r = processAmtDataEx(accAmt, accAmtPtr, accAmtLen); accAmtPtr += r; accAmtLen -= r; } while (r != 0);
            if (r < 0) { error = true; return null; }

            // Move the rest to the front of the accumulator
            if (accAmtPtr != 0) { if (accAmtLen != 0) { Array.Copy(accAmt, accAmtPtr, accAmt, 0, accAmtLen); } accAmtPtr = 0; }

            // Send any outgoing data
            byte[] output = sendAmtBuffer.ToArray();
            sendAmtBuffer.SetLength(0);

            //System.Diagnostics.Debug.WriteLine("-----------  From AMT");
            //System.Diagnostics.Debug.WriteLine(BitConverter.ToString(output));
            return output;
        }

        public int processAmtDataEx(byte[] data, int off, int len)
        {
            if (len == 0) return 0;
            int relay = 0;
            if (accAmtDirect)
            {
                // Relay everything directly
                relay = len;
            }
            else
            {
                // Process the commands
                switch ((RedirectCommands)data[off])
                {
                    case RedirectCommands.StartRedirectionSessionReply:
                        {
                            if (len < 4) return 0;
                            StartRedirectionSessionReplyStatus rstate = (StartRedirectionSessionReplyStatus)data[off + 1];
                            if (rstate == StartRedirectionSessionReplyStatus.SUCCESS) {
                                if (len < 13) return 0;
                                int oemlen = data[off + 12];
                                if (len < 13 + oemlen) return 0;
                                relay = 13 + oemlen;
                            }
                            break;
                        }
                    case RedirectCommands.AuthenticateSessionReply:
                        {
                            if (len < 9) return 0;
                            int l = BitConverter.ToInt32(data, off + 5);
                            if (len < 9 + l) return 0;
                            relay = 9 + l;

                            AuthenticationStatus authstatus = (AuthenticationStatus)data[off + 1];
                            AuthenticationType authType = (AuthenticationType)data[off + 4];

                            if (authType == AuthenticationType.DIGEST && authstatus == AuthenticationStatus.FALIURE)
                            {
                                // Grab and keep all authentication parameters
                                int realmlen = (int)data[off + 9];
                                digestRealm = UTF8Encoding.UTF8.GetString(data, off + 10, realmlen);
                                int noncelen = (int)data[off + 10 + realmlen];
                                digestNonce = UTF8Encoding.UTF8.GetString(data, off + 11 + realmlen, noncelen);
                                int qoplen = (int)data[off + 11 + realmlen + noncelen];
                                digestQOP = UTF8Encoding.UTF8.GetString(data, off + 12 + realmlen + noncelen, qoplen);
                            }
                            else if (authType != AuthenticationType.QUERY && authstatus == AuthenticationStatus.SUCCESS)
                            {
                                // Intel AMT relayed that authentication was succesful, go to direct relay mode in both directions.
                                accWsDirect = true;
                                accAmtDirect = true;
                            }
                            break;
                        }
                    default:
                        {
                            // Unknown command, close the connection
                            return -1;
                        }
                }
            }
            if (relay > 0) { sendAmtBuffer.Write(data, off, relay); }
            return relay;
        }

        private byte[] accWs = new byte[65535];
        private int accWsPtr = 0;
        private int accWsLen = 0;
        private bool accWsDirect = false;
        private MemoryStream sendWsBuffer = new MemoryStream();
        private static string wsAuthCNonce = Utils.GetRandomAlphaNumeric(12);
        private static int wsAuthNonceCount = 1;
        private static string authuri = "/RedirectionService";

        public byte[] processBrowserData(byte[] data, int off, int len, out bool error)
        {
            error = false;
            // Add new data to accumulator
            Array.Copy(data, off, accWs, accWsPtr + accWsLen, len);
            accWsLen += len;

            // Process as much data as possible
            int r = 0;
            do { r = processWsDataEx(accWs, accWsPtr, accWsLen); accWsPtr += r; accWsLen -= r; } while (r != 0);
            if (r == -1) { error = true; return null; }

            // Move the rest to the front of the accumulator
            if (accWsPtr != 0) { if (accWsLen != 0) { Array.Copy(accWs, accWsPtr, accWs, 0, accWsLen); } accWsPtr = 0; }

            // Send any outgoing data
            byte[] output = sendWsBuffer.ToArray();
            sendWsBuffer.SetLength(0);
            //System.Diagnostics.Debug.WriteLine("-----------  From Browser");
            //System.Diagnostics.Debug.WriteLine(BitConverter.ToString(output));
            return output;
        }

        public int processWsDataEx(byte[] data, int off, int len)
        {
            if (len == 0) return 0;
            int relay = 0;
            if (accWsDirect)
            {
                // Relay everything directly
                relay = len;
            }
            else
            {
                // Process the commands
                switch ((RedirectCommands)data[off])
                {
                    case RedirectCommands.StartRedirectionSession:
                        {
                            if (len >= 8) relay = 8;
                            break;
                        }
                    case RedirectCommands.EndRedirectionSession:
                        {
                            if (len >= 4) relay = 4;
                            break;
                        }
                    case RedirectCommands.AuthenticateSession:
                        {
                            if (len < 9) return 0;
                            int l = BitConverter.ToInt32(data, off + 5);
                            if (len < 9 + l) return 0;
                            relay = 9 + l;

                            AuthenticationType authType = (AuthenticationType)data[off + 4];
                            if (serverauth != 0)
                            {
                                // Server authentication requested

                                if (digestUsername != null && digestPassword != null)
                                {
                                    // Attempt server-side Digest authentication

                                    // obj.xxSend(String.fromCharCode(0x13, 0x00, 0x00, 0x00, 0x04) + IntToStrX(obj.user.length + obj.authuri.length + 8) + String.fromCharCode(obj.user.length) + obj.user + String.fromCharCode(0x00, 0x00) + String.fromCharCode(obj.authuri.length) + obj.authuri + String.fromCharCode(0x00, 0x00, 0x00, 0x00));
                                    if (authType == AuthenticationType.DIGEST)
                                    {
                                        if (digestRealm == null)
                                        {
                                            // Replace this authentication digest with a server created one
                                            // Since we don't have authentication parameters, fill them in with blanks to get an error back what that info.
                                            MemoryStream mem = new MemoryStream();
                                            BinaryWriter bw = new BinaryWriter(mem);
                                            bw.Write((byte)0x13); // AuthenticateSession
                                            bw.Write((byte)0x00); // Reserved
                                            bw.Write((byte)0x00); // Reserved
                                            bw.Write((byte)0x00); // Reserved
                                            bw.Write((byte)0x04); // Digest authentication
                                            bw.Write(BitConverter.GetBytes(UTF8Encoding.UTF8.GetByteCount(digestUsername) + UTF8Encoding.UTF8.GetByteCount(authuri) + 8)); // AuthenticationDataLength
                                            bw.Write((byte)UTF8Encoding.UTF8.GetByteCount(digestUsername)); // Username Length
                                            bw.Write(UTF8Encoding.UTF8.GetBytes(digestUsername)); // Username
                                            bw.Write((byte)0x00); // Realm length
                                            bw.Write((byte)0x00); // Nonce length
                                            bw.Write((byte)UTF8Encoding.UTF8.GetByteCount(authuri)); // Authentication URL Length
                                            bw.Write(UTF8Encoding.UTF8.GetBytes(authuri)); // Authentication URL "/RedirectionService"
                                            bw.Write((byte)0x00); // CNonce length
                                            bw.Write((byte)0x00); // Nonce count length
                                            bw.Write((byte)0x00); // Response length
                                            bw.Write((byte)0x00); // QOP length

                                            // Send the message to AMT
                                            byte[] output = mem.ToArray();
                                            sendWsBuffer.Write(output, 0, output.Length); // This is the new Digest authentication message.

                                            return 9 + l; // Don't relay the original message
                                        }
                                        else
                                        {
                                            // Replace this authentication digest with a server created one
                                            // We have everything we need to authenticate
                                            int nc = wsAuthNonceCount;
                                            wsAuthNonceCount++;
                                            string digest = ComputeDigesthash(digestUsername, digestPassword, digestRealm, "POST", authuri, digestQOP, digestNonce, nc.ToString(), wsAuthCNonce);

                                            // Replace this authentication digest with a server created one
                                            // Since we don't have authentication parameters, fill them in with blanks to get an error back what that info.
                                            MemoryStream mem = new MemoryStream();
                                            BinaryWriter bw = new BinaryWriter(mem);
                                            bw.Write((byte)0x13); // AuthenticateSession
                                            bw.Write((byte)0x00); // Reserved
                                            bw.Write((byte)0x00); // Reserved
                                            bw.Write((byte)0x00); // Reserved
                                            bw.Write((byte)0x04); // Digest authentication
                                            bw.Write(BitConverter.GetBytes(UTF8Encoding.UTF8.GetByteCount(digestUsername) + UTF8Encoding.UTF8.GetByteCount(digestRealm) + UTF8Encoding.UTF8.GetByteCount(digestNonce) + UTF8Encoding.UTF8.GetByteCount(authuri) + UTF8Encoding.UTF8.GetByteCount(wsAuthCNonce) + UTF8Encoding.UTF8.GetByteCount(nc.ToString()) + UTF8Encoding.UTF8.GetByteCount(digest) + UTF8Encoding.UTF8.GetByteCount(digestQOP) + 8)); // AuthenticationDataLength
                                            bw.Write((byte)UTF8Encoding.UTF8.GetByteCount(digestUsername)); // Username Length
                                            bw.Write(UTF8Encoding.UTF8.GetBytes(digestUsername)); // Username
                                            bw.Write((byte)UTF8Encoding.UTF8.GetByteCount(digestRealm)); // Realm Length
                                            bw.Write(UTF8Encoding.UTF8.GetBytes(digestRealm)); // Realm
                                            bw.Write((byte)UTF8Encoding.UTF8.GetByteCount(digestNonce)); // Nonce Length
                                            bw.Write(UTF8Encoding.UTF8.GetBytes(digestNonce)); // Nonce
                                            bw.Write((byte)UTF8Encoding.UTF8.GetByteCount(authuri)); // Authentication URL Length
                                            bw.Write(UTF8Encoding.UTF8.GetBytes(authuri)); // Authentication URL "/RedirectionService"
                                            bw.Write((byte)UTF8Encoding.UTF8.GetByteCount(wsAuthCNonce)); // CNonce Length
                                            bw.Write(UTF8Encoding.UTF8.GetBytes(wsAuthCNonce)); // CNonce
                                            bw.Write((byte)UTF8Encoding.UTF8.GetByteCount(nc.ToString())); // NonceCount Length
                                            bw.Write(UTF8Encoding.UTF8.GetBytes(nc.ToString())); // NonceCount
                                            bw.Write((byte)UTF8Encoding.UTF8.GetByteCount(digest)); // Response Length
                                            bw.Write(UTF8Encoding.UTF8.GetBytes(digest)); // Response
                                            bw.Write((byte)UTF8Encoding.UTF8.GetByteCount(digestQOP)); // QOP Length
                                            bw.Write(UTF8Encoding.UTF8.GetBytes(digestQOP)); // QOP

                                            // Send the message to AMT
                                            byte[] output = mem.ToArray();
                                            sendWsBuffer.Write(output, 0, output.Length); // This is the new Digest authentication message.

                                            return 9 + l; // Don't relay the original message
                                        }
                                    }
                                }
                                else if (!hasKerberosTicket)
                                {
                                        // Attempt server-side Kerberos authentication

                                        // First, get a ticket
                                        byte[] clientToken = null;
                                        try
                                        {
                                            System.Diagnostics.Debug.WriteLine("Thread Context: {0}", WindowsIdentity.GetCurrent().Name);

                                            // Try to get a ticket with the host and port
                                            string principal = "HTTP/" + host + ":" + port;
                                            ClientCredential clientCred = new ClientCredential(PackageNames.Negotiate);
                                            ClientContext client = new ClientContext(clientCred, principal, ContextAttrib.Confidentiality | ContextAttrib.ReplayDetect | ContextAttrib.SequenceDetect | ContextAttrib.Delegate);
                                            SecurityStatus clientStatus = client.Init(null, out clientToken);
                                        }
                                        catch (Exception ex) { if (onDebug != null) onDebug(EventSeverity.Error, ex.ToString()); }

                                        if (clientToken == null)
                                        {
                                            try
                                            {
                                                // Try to get a ticket with just the host
                                                string principal = "HTTP/" + host;
                                                ClientCredential clientCred = new ClientCredential(PackageNames.Kerberos);
                                                ClientContext client = new ClientContext(clientCred, principal, ContextAttrib.Confidentiality | ContextAttrib.ReplayDetect | ContextAttrib.SequenceDetect | ContextAttrib.Delegate);
                                                SecurityStatus clientStatus = client.Init(null, out clientToken);
                                            }
                                            catch (Exception ex) { if (onDebug != null) onDebug(EventSeverity.Error, ex.ToString()); }
                                        }

                                        if (clientToken != null)
                                        {
                                            // Build the new message
                                            MemoryStream mem = new MemoryStream();
                                            BinaryWriter bw = new BinaryWriter(mem);
                                            bw.Write((byte)0x13); // AuthenticateSession
                                            bw.Write((byte)0x00); // Reserved
                                            bw.Write((byte)0x00); // Reserved
                                            bw.Write((byte)0x00); // Reserved
                                            bw.Write((byte)0x02); // Kerberos authentication
                                            String tk = Convert.ToBase64String(clientToken);
                                            bw.Write(BitConverter.GetBytes(tk.Length)); // AuthenticationDataLength
                                            bw.Write(System.Text.Encoding.UTF8.GetBytes(tk)); // Kerberos token
                                            //bw.Write(BitConverter.GetBytes(clientToken.Length)); // AuthenticationDataLength
                                            //bw.Write(clientToken); // Kerberos token

                                            // Send the message to AMT
                                            byte[] output = mem.ToArray();
                                            sendWsBuffer.Write(output, 0, output.Length); // This is the new Kerberos authentication message.

                                            hasKerberosTicket = true;
                                            return 9 + l; // Don't relay the original message.
                                        }
                                        else
                                        {
                                            // Unable to get a Kerberos ticket, close the connection
                                            return -1;
                                        }
                                }
                            }
                            break;
                        }
                    default:
                        {
                            // Unknown command, close the connection
                            return -1;
                        }
                }
            }
            if (relay > 0) { sendWsBuffer.Write(data, off, relay); }

            //System.Diagnostics.Debug.WriteLine("-----------  From WebSocket");
            //System.Diagnostics.Debug.WriteLine(BitConverter.ToString(data));
            return relay;
        }
        private string ComputeDigesthash(string username, string password, string realm, string method, string path, string qop, string nonce, string nc, string cnonce)
        {
            using (MD5 md5Hash = MD5.Create())
            {
                string ha1 = Utils.BytesToHex(md5Hash.ComputeHash(Encoding.ASCII.GetBytes(username + ":" + realm + ":" + password))).ToLower();
                string ha2 = Utils.BytesToHex(md5Hash.ComputeHash(Encoding.ASCII.GetBytes(method + ":" + path))).ToLower();
                return Utils.BytesToHex(md5Hash.ComputeHash(Encoding.ASCII.GetBytes(ha1 + ":" + nonce + ":" + nc + ":" + cnonce + ":" + qop + ":" + ha2))).ToLower();
            }
        }

    }

}