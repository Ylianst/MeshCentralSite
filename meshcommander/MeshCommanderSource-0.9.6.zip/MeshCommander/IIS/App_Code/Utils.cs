﻿using System;
using System.Text;
using System.Security.Cryptography;

namespace ManageabilityCommander
{

    /// <summary>
    /// Summary description for Utils
    /// </summary>
    public class Utils
    {
        public static string BytesToHex(byte[] buf)
        {
            if (buf == null) return "";
            StringBuilder s = new StringBuilder(buf.Length * 3);
            foreach (byte b in buf) s.Append(b.ToString("X02"));
            return s.ToString();
        }

        public static string BytesToHex(byte[] buf, int spacing)
        {
            if (spacing == 0) return BytesToHex(buf);
            if (buf == null) return "";
            StringBuilder s = new StringBuilder(buf.Length * 3);
            int i = 0;
            foreach (byte b in buf)
            {
                s.Append(b.ToString("X02"));
                i++;
                if ((i % spacing) == 0) s.Append(" ");
            }
            return s.ToString();
        }

        public static string getETag(string input)
        {
            using (MD5 md5Hash = MD5.Create()) { return Convert.ToBase64String(md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input))); }
        }

        private static RNGCryptoServiceProvider CryptoRandom = new RNGCryptoServiceProvider();

        // Return a crypto random alpha-numeric string
        public static string GetRandomAlphaNumeric(int len)
        {
            StringBuilder sb = new StringBuilder();
            byte[] buf = new byte[len];
            CryptoRandom.GetBytes(buf);

            for (int i = 0; i < len; i++)
            {
                int c = buf[i] % 62;
                if (c < 10) sb.Append((char)(48 + c)); else if (c < 36) sb.Append((char)(55 + c)); else sb.Append((char)(61 + c));
            }
            return sb.ToString();
        }


    }
}
