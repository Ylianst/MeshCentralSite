/**
* @description Meshcentral web server
* @author Ylian Saint-Hilaire
* @version v0.0.1
*/

// ExpressJS login sample
// https://github.com/expressjs/express/blob/master/examples/auth/index.js

// Construct a HTTP redirection web server object
module.exports.CreateRedirServer = function (parent, db, args, certificates) {
    var obj = {};
    obj.parent = parent;
    obj.db = db;
    obj.certificates = certificates;
    obj.express = require('express');
    obj.app = obj.express();
    
    obj.app.get('/', function (req, res) {
        if (args.notls) { res.redirect('http://' + certificates.CommonName + ':' + args.port); } else { res.redirect('https://' + certificates.CommonName + ':' + args.port); }
    });

    // Renter the terms of service.
    obj.app.get('/MeshServerRootCert.cer', function (req, res) {
        res.set({ 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache', 'Expires': '0', 'Content-Type': 'application/octet-stream', 'Content-Disposition': 'attachment; filename=' + certificates.RootName + '.cer' });
        var rootcert = obj.certificates.root.cert;
        var i = rootcert.indexOf("-----BEGIN CERTIFICATE-----\r\n");
        if (i >= 0) { rootcert = rootcert.substring(i + 29); }
        i = rootcert.indexOf("-----END CERTIFICATE-----");
        if (i >= 0) { rootcert = rootcert.substring(i, 0); }
        res.send(new Buffer(rootcert, 'base64'));
    });
    
    // Start the ExpressJS web server, if the port is busy try the next one.
    function StartRedirServer(port) {
        obj.app.listen(port, function () { console.log('MeshCentral HTTP redirection web server running on port ' + port + '.'); }).on('error', function (err) { if ((err.code == 'EACCES') && (port < 65535)) { StartRedirServer(port + 1); } else { console.log(err); } });
    }
    
    StartRedirServer(args.redirport);

    return obj;
}
