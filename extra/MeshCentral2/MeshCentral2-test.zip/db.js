/** 
* @description Meshcentral database
* @author Ylian Saint-Hilaire
* @version v0.0.1
*/

// Construct Meshcentral database object
// https://github.com/louischatriot/nedb
module.exports.CreateDB = function (args) {
    var obj = {};    
    var Datastore = require('nedb');
    obj.ram = new Datastore();
    obj.ram.persistence.setAutocompactionInterval(3600);
    obj.file = new Datastore({ filename: './data/meshcentral.db', autoload: true });
    obj.file.persistence.setAutocompactionInterval(3600);
    
    obj.SetupDatabase = function () {
        /*
        obj.Set({ type: 'node', _id: 'node-E7C2496BE5120A02FDBCDF154E0A6B3E5E59791217FA719A2A018B014C6BAF19', meshid: 'mesh-7B4B43CDAD850135F36AB31124B52E47C167FBA055CE800267A4DC89FE0E581C', name: 'Computer1', host: 'zax' });
        obj.Set({ type: 'node', _id: 'node-E7C2496BE5120A02FDBCDF154E0A6B3E5E59791217FA719A2A018B014C6BAF29', meshid: 'mesh-7B4B43CDAD850135F36AB31124B52E47C167FBA055CE800267A4DC89FE0E581C', name: 'Computer2' });
        obj.Set({ type: 'node', _id: 'node-E7C2496BE5120A02FDBCDF154E0A6B3E5E59791217FA719A2A018B014C6BAF39', meshid: 'mesh-7B4B43CDAD850135F36AB31124B52E47C167FBA055CE800267A4DC89FE0E581C', name: 'Computer3' });
        obj.Set({ type: 'node', _id: 'node-E7C2496BE5120A02FDBCDF154E0A6B3E5E59791217FA719A2A018B014C6BAF49', meshid: 'mesh-7B4B43CDAD850135F36AB31124B52E47C167FBA055CE800267A4DC89FE0E581D', name: 'Computer4b' });
        obj.Set({ type: 'mesh', _id: 'mesh-7B4B43CDAD850135F36AB31124B52E47C167FBA055CE800267A4DC89FE0E581C', name: 'Mesh1', mtype: 1, desc: 'desc1', links: { 'user-a' : 0xFFFFFFFF} });
		obj.Set({ type: 'mesh', _id: 'mesh-7B4B43CDAD850135F36AB31124B52E47C167FBA055CE800267A4DC89FE0E581D', name: 'Mesh2', mtype: 1, desc: 'desc2', links: { 'user-a' : 0xFFFFFFFF } });
        */
        // obj.file.find({ type: 'node' }, function (err, docs) { console.log(err, docs); });
        //obj.RemoveAllEvents();
        //obj.MakeSiteAdmin('a');
    }
    
    obj.Set = function (data) { obj.file.update({ _id: data._id }, data, { upsert: true }); }
    obj.Get = function (id, func) { obj.file.find({ _id: id }, func); }
    obj.GetAllTypeNoTypeFeild = function (type, func) { obj.file.find({ type: type }, { type : 0 }, func); }
    obj.GetAllTypeNoTypeFeildMeshFiltered = function (meshes, type, func) { obj.file.find({ type: type, meshid: { $in: meshes } }, { type : 0 }, func); }
    obj.GetAllType = function (type, func) { obj.file.find({ type: type }, func); }
    obj.GetAllIdsOfType = function (ids, type, func) { obj.file.find({ type: type, _id: { $in: ids } }, func); }
    obj.Remove = function (id) { obj.file.remove({ _id: id }); }
    obj.StoreEvent = function (ids, source, event) { obj.file.insert(event); }
    obj.GetEvents = function (ids, func) { obj.file.find({ type: 'event', ids: { $in: ids } }, { type : 0, _id : 0 }).sort({ time: -1 }).exec(func); }
    obj.RemoveMesh = function (id) { obj.file.remove({ mesh: id }, { multi: true }); obj.file.remove({ _id: id }); }
    obj.AddMesh = function (id, mtype, name, desc, links) { obj.Set({ type: 'mesh', _id: id, name: name, mtype: mtype, desc: desc, links: links }); }
    obj.RemoveAllEvents = function () { obj.file.remove({ type: 'event' }, { multi: true }); }
    obj.MakeSiteAdmin = function (username) { obj.Get('user-' + username, function (err, docs) { if (docs.length == 1) { docs[0].siteadmin = 0xFFFFFFFF; obj.Set(docs[0]); } }); }

    obj.SetupDatabase();
    return obj;
}