/**
* @description Meshcentral MeshAgent
* @author Ylian Saint-Hilaire & Bryan Roe
* @version v0.0.1
*/

// Construct a MeshAgent object, called upon connection
module.exports.CreateMeshAgent = function (parent, db, ws, args) {
    var obj = {};
    obj.parent = parent;
    obj.db = db;
    obj.ws = ws;
    obj.args = args;
    
    console.log('MeshAgent connected');

    // When data is received from the mesh agent web socket
    ws.on('message', function (msg) {
        console.log('MeshAgent message, len = ' + msg.length);
    });
        
    // If the mesh agent web socket is closed
    ws.on('close', function (req) {
        console.log('MeshAgent disconnect');
    });

    // TODO: Start authenticate the mesh agent
    
    // Send a message to the mesh agent
    obj.send = function (data) {
        obj.ws.send(data);
    }

    return obj;
}
