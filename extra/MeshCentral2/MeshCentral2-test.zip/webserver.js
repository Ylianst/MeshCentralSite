/**
* @description Meshcentral web server
* @author Ylian Saint-Hilaire
* @version v0.0.1
*/

// ExpressJS login sample
// https://github.com/expressjs/express/blob/master/examples/auth/index.js

// Construct a HTTP web server object
module.exports.CreateWebServer = function (parent, db, args, secret, certificates) {
    var obj = {};
    obj.parent = parent;
    obj.db = db;
    obj.express = require('express');
    obj.app = obj.express();
    obj.tlsServer = null;
    obj.app.use(require('compression')());
    obj.bodyParser = require('body-parser');
    obj.session = require('express-session');
    obj.hash = require('./pass').hash;
    obj.exphbs = require('express-handlebars');
    obj.common = require('./common.js');
    obj.net = require('net');
    obj.tls = require('tls');
    obj.interceptor = require('./interceptor');
    obj.certificates = certificates;
    obj.args = args;
    
    if (obj.args.notls) {
        // Setup the HTTP server without TLS
        obj.expressWs = require('express-ws')(obj.app);
    } else {
        // Setup the HTTP server with TLS
        //var certOperations = require('./certoperations.js').CertificateOperations();
        //var webServerCert = certOperations.GetWebServerCertificate('./data', 'SampleServer.org', 'US', 'SampleOrg');
        obj.tlsServer = require('https').createServer(obj.certificates.web, obj.app);
        obj.tlsServer.listenXX = obj.tlsServer.listen;
        obj.expressWs = require('express-ws')(obj.app, obj.tlsServer);
    }

    // Setup middleware
    obj.app.engine('handlebars', obj.exphbs({})); // defaultLayout: 'main'
    obj.app.set('view engine', 'handlebars');
    obj.app.use(obj.bodyParser.urlencoded({ extended: false }));
    obj.app.use(obj.session({
        resave: false, // don't save session if unmodified
        saveUninitialized: false, // don't create session until something stored
        secret: secret // If multiple instances of this server are behind a load-balancer, this secret must be the same for all instances
    }));
    
    // Session-persisted message middleware
    obj.app.use(function (req, res, next) {
        var err = req.session.error;
        var msg = req.session.success;
        delete req.session.error;
        delete req.session.success;
        res.locals.message = '';
        if (err) res.locals.message = '<p class="msg error">' + err + '</p>';
        if (msg) res.locals.message = '<p class="msg success">' + msg + '</p>';
        next();
    });

	// Fetch all users from the database
    obj.users = {};
    obj.db.GetAllType('user', function (err, docs) {
        var usercount = 0;
        for (var i in docs) { obj.users[docs[i]._id] = docs[i]; usercount++; }
        if (usercount == 0) console.log('Server has no users, next new account will be site administrator.');
	});

    // Authenticate the user
    obj.authenticate = function(name, pass, fn) {
        if (!module.parent) console.log('authenticating %s:%s', name, pass);
        var user = obj.users['user-' + name.toLowerCase()];
        // query the db for the given username
        if (!user) return fn(new Error('cannot find user'));
        // apply the same algorithm to the POSTed password, applying the hash against the pass / salt, if there is a match we found the user
        obj.hash(pass, user.salt, function (err, hash) {
            if (err) return fn(err);
            if (hash == user.hash) return fn(null, user._id);
            fn(new Error('invalid password'));
        });
    }

    obj.restrict = function(req, res, next) {
        if (req.session.userid) {
            next();
        } else {
            req.session.error = 'Access denied!';
            res.redirect('/login');
        }
    }

    obj.app.get('/logout', function (req, res) {
        // destroy the user's session to log them out will be re-created next request
        if (req.session.userid) {
            var user = obj.users[req.session.userid]
            obj.parent.DispatchEvent(['*'], obj, { etype: 'user', username: user.name, action: 'logout', msg: 'Account logout' })
        }
        req.session.destroy(function () { res.redirect('/'); });
    });

    obj.app.post('/login', function (req, res) {
        obj.authenticate(req.body.username, req.body.password, function (err, userid) {
            if (userid) {
                var user = obj.users[userid];

                // Save login time
                user.login = Date.now();
                obj.db.Set(user);

                // Regenerate session when signing in to prevent fixation
                req.session.regenerate(function () {
					// Store the user's primary key in the session store to be retrieved, or in this case the entire user object
					// req.session.success = 'Authenticated as ' + user.name + 'click to <a href="/logout">logout</a>. You may now access <a href="/restricted">/restricted</a>.';
					delete req.session.loginmode;
                    req.session.userid = userid;
                    req.session.currentNode = '';
                    if (req.body.viewmode) {
                        req.session.viewmode = req.body.viewmode;
                    }
                    if (req.body.host) {
                        obj.db.GetAllType('node', function (err, docs) {
                            for (var i = 0; i < docs.length; i++) {
                                if (docs[i].name == req.body.host) {
                                    req.session.currentNode = docs[i]._id;
                                    break;
                                }
                            }
                            console.log("CurrentNode: " + req.session.currentNode);
                            // this redirect happens after finding node is completed
                            res.redirect('/');
                        });
                    } else {
                        res.redirect('/');
                    }
                });

                obj.parent.DispatchEvent(['*'], obj, { etype: 'user', username: user.name, action: 'login', msg: 'Account login' })
			} else {
				delete req.session.loginmode;
				req.session.error = '<b style=color:#8C001A>Login failed, check username and password.</b>';
                res.redirect('/');
            }
        });
    });
   

	obj.app.post('/createaccount', function (req, res) {
		if (!req.body.username || !req.body.email || !req.body.password1 || !req.body.password2 || req.body.password1 != req.body.password2) {
			req.session.loginmode = 2;
			req.session.error = '<b style=color:#8C001A>Unable to create account.</b>';;
			res.redirect('/');
		} else {
			// Check if user exists
			if (obj.users['user-' + req.body.username.toLowerCase()]) {
				req.session.loginmode = 2;
				req.session.error = '<b style=color:#8C001A>Username already exists.</b>';
			} else {
                var user = { type: 'user', _id: 'user-' + req.body.username.toLowerCase(), name: req.body.username, email: req.body.email, creation: Date.now(), login: Date.now() };
                var usercount = 0;
                for (var i in obj.users) { usercount++; }
                if (usercount == 0) user.siteadmin = 0xFFFFFFFF; // If this is the first user, give the account site admin.
                obj.users[user._id] = user;
                req.session.userid = user._id;
				// Create a user, generate a salt and hash the password
				obj.hash(req.body.password1, function (err, salt, hash) {
					if (err) throw err;
					user.salt = salt;
					user.hash = hash;
					obj.db.Set(user);
                });
                obj.parent.DispatchEvent(['*', 'server-users'], obj, { etype: 'user', username: user.name, account: user, action: 'accountcreate', msg: 'Account created, email is ' + req.body.email })
			}
			res.redirect('/');
		}
	});

	obj.app.post('/deleteaccount', function (req, res) {
		// Check if the user is logged and we have all required parameters
        if (!req.session || !req.session.userid || !req.body.apassword1 || req.body.apassword1 != req.body.apassword2) { res.redirect('/'); return; }
        var user = obj.users[req.session.userid];
        if (!user) return;

        // Check if the password is correct
        obj.authenticate(user.name, req.body.apassword1, function (err, userid) {
            var user = obj.users[userid];
            if (user) {
                obj.db.Remove(user._id);
                delete obj.users[user._id];
                req.session.destroy(function () { res.redirect('/'); });
                obj.parent.DispatchEvent(['*', 'server-users'], obj, { etype: 'user', username: user.name, action: 'accountremove', msg: 'Account removed' })
			} else {
				res.redirect('/');
			}
		});
	});

	obj.app.post('/changepassword', function (req, res) {
		// Check if the user is logged and we have all required parameters
		if (!req.session || !req.session.userid || !req.body.apassword1 || req.body.apassword1 != req.body.apassword2) { res.redirect('/'); return; }

		// Update the password
		obj.hash(req.body.apassword1, function (err, salt, hash) {
            if (err) throw err;
            var user = obj.users[req.session.userid];
			user.salt = salt;
            user.hash = hash;
            user.passchange = Date.now();
            obj.db.Set(user);
			req.session.viewmode = 2;
            res.redirect('/');
            obj.parent.DispatchEvent(['*', 'server-users'], obj, { etype: 'user', username: user.name, action:'passchange', msg: 'Account password changed: ' + user.name })
		});
	});

    // Indicates to ExpressJS that the public folder should be used to serve static files.
    obj.app.use(obj.express.static('public'));

    // Indicates that any request to "/" should render "default" or "login" depending on login state
    obj.app.get('/', function (req, res) {
        res.set({ 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache', 'Expires': '0' });
        // If a default user is active, setup the session here.
        if (obj.args.user && (!req.session || !req.session.userid) && obj.users['user-' + obj.args.user.toLowerCase()]) {
            if (req.session && req.session.loginmode) { delete req.session.loginmode; }
            req.session.userid = 'user-' + obj.args.user.toLowerCase();
            req.session.currentNode = '';
        }
        // If a user is logged in, serve the default app, otherwise server the login app.
        if (req.session && req.session.userid) {
            var viewmode = 1;
            if (req.session.viewmode) {
                viewmode = req.session.viewmode;
                delete req.session.viewmode;
            }
            var currentNode = '';
            if (req.session.currentNode) {
                currentNode = req.session.currentNode;
                delete req.session.currentNode;
            }
            var user = obj.users[req.session.userid];
            var logoutcontrol = 'Welcome ' + user.name + '.';
            if (!obj.args.user) { logoutcontrol += '<a href=/logout style=color:white>Logout</a>'; } // If a default user is in user, don't display the logout button
            res.render('default', { viewmode: viewmode, currentNode: currentNode, logoutControl: logoutcontrol });
        } else {
            // Send back the login application
            rootcertlink = '';
            // TODO: This is not quite right, we need to check if the HTTPS certificate is issued from MeshCentralRoot, if so, add this download link.
            if (obj.args.notls == undefined && obj.certificates.RootName.substring(0, 16) == 'MeshCentralRoot-') { rootcertlink = '<a href=/MeshServerRootCert.cer title="Download the root certificate for this server">Root Certificate</a>'; }
            res.render('login', { loginmode: req.session.loginmode, rootCertLink: rootcertlink });
        }
    });

    // Renter the terms of service.
    obj.app.get('/terms', function (req, res) {
        res.set({ 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache', 'Expires': '0' });
        if (req.session && req.session.userid) {
            var user = obj.users[req.session.userid];
            res.render('terms', { logoutControl: 'Welcome ' + user.name + '. <a href=/logout style=color:white>Logout</a>' });
        } else {
            res.render('terms');
        }
    });

    // Renter the terms of service.
    obj.app.get('/MeshServerRootCert.cer', function (req, res) {
        res.set({ 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache', 'Expires': '0', 'Content-Type':'application/octet-stream', 'Content-Disposition': 'attachment; filename=' + certificates.RootName + '.cer' });
        var rootcert = obj.certificates.root.cert;
        var i = rootcert.indexOf("-----BEGIN CERTIFICATE-----\r\n");
        if (i >= 0) { rootcert = rootcert.substring(i + 29); }
        i = rootcert.indexOf("-----END CERTIFICATE-----");
        if (i >= 0) { rootcert = rootcert.substring(i, 0); }
        res.send(new Buffer(rootcert, 'base64'));
    });

    // Subscribe to all events we are allowed to receive
    obj.subscribe = function (userid, target) {
        var user = obj.users[userid];
        var subscriptions = [userid, 'server-global'];
        if (user.siteadmin != undefined) {
            if (user.siteadmin == 0xFFFFFFFF) subscriptions.push('*');
            if ((user.siteadmin & 2) != 0) subscriptions.push('server-users');
        }
        if (user.links != undefined) {
            for (var i in user.links) { subscriptions.push(i); }
        }
        obj.parent.RemoveAllEventDispatch(target);
        obj.parent.AddEventDispatch(subscriptions, target);
        return subscriptions;
    }

    obj.HandleRelayWebSocket = function(ws, req) {
        // Check if this is a logged in user
        if (!req.session || !req.session.userid) { console.log('ERR: Not logged in'); return; }
        var user = obj.users[req.session.userid];
        if (!user) { console.log('ERR: Not a user'); return; }
        Debug(1, 'Websocket relay connected from ' + user.name + ' for ' + req.query.host + '.');

        // Fetch information about the target
        obj.db.Get(req.query.host, function (err, docs) {
            if (docs.length == 0) { console.log('ERR: Node not found'); return; }
            var node = docs[0];
            if (!node.intelamt) { console.log('ERR: Not AMT node'); return; }

            // Check if this user has permission to manage this computer
            var meshlinks = user.links[node.meshid];
            if (!meshlinks || !meshlinks.rights) { console.log('ERR: Access denied (1)'); return; }
            if ((meshlinks.rights & 8) == 0) { console.log('ERR: Access denied (2)'); return; }
            
            // Check what connectivity is available for this node
            var conn = parent.connectivityByNode[req.query.host];
            if (!conn || conn == 0) {
                conn = 4; // DEBUG: Allow local connections for now... change this later when we can monitor Intel AMT machines and confirm routing before connections.
                //Debug(1, 'ERR: No routing possible (1)');
                //try { ws.close(); } catch (e) { }
                //return;
            }
            
            // If Intel AMT CIRA connection is available, use it
            if (((conn & 2) != 0) && (parent.mpsserver.ciraConnections[req.query.host] != undefined)) {
                var ciraconn = parent.mpsserver.ciraConnections[req.query.host];
                
                // Compute target port, look at the CIRA port mappings, if non-TLS is allowed, use that, if not use TLS
                var port = 16993;
                if (ciraconn.tag.boundPorts.indexOf(16992) >= 0) port = 16992;
                if (req.query.p == 2) port += 2;
                
                // Setup a new CIRA channel
                ws.forwardclient = parent.mpsserver.SetupCiraChannel(ciraconn, port);
                                                
                // When data is received from the web socket, forward the data into the associated CIRA cahnnel.
                // If the CIRA connection is pending, the CIRA channel has built-in buffering, so we are ok sending anyway.
                ws.on('message', function (msg) {
                    // Convert a buffer into a string, "msg = msg.toString('ascii');" does not work
                    var msg2 = "";
                    for (var i = 0; i < msg.length; i++) { msg2 += String.fromCharCode(msg[i]); }
                    msg = msg2;
                    if (ws.interceptor) { msg = ws.interceptor.processBrowserData(msg); } // Run data thru interceptor
                    ws.forwardclient.write(msg); // TODO: Add TLS support
                });
                
                // If the web socket is closed, close the associated TCP connection.
                ws.on('close', function (req) {
                    Debug(1, 'Websocket relay closed.');
                    if (ws.forwardclient) { ws.forwardclient.close(); }
                });

                ws.forwardclient.onStateChange = function (ciraconn, state) {
                    Debug(2, 'Relay CIRA state change', state);
                    if (state == 0) { try { ws.close(); } catch (e) { } }
                }

                ws.forwardclient.onData = function (ciraconn, data) {
                    Debug(3, 'Relay CIRA data', data.length);
                    if (ws.interceptor) { data = ws.interceptor.processAmtData(data); } // Run data thru interceptor
                    if (data.length > 0) { try { ws.send(data); } catch (e) { } } // TODO: Add TLS support
                }
                
                ws.forwardclient.onSendOk = function (ciraconn) {
                    // TODO: Flow control? (Dont' really need it with AMT, but would be nice)
                    //console.log('onSendOk');
                }

                // Fetch Intel AMT credentials & Setup interceptor
                if (req.query.p == 1) { ws.interceptor = obj.interceptor.CreateHttpInterceptor({ host: node.host, port: port, user: node.intelamt.user, pass: node.intelamt.pass }); }
                else if (req.query.p == 2) { ws.interceptor = obj.interceptor.CreateRedirInterceptor({ user: node.intelamt.user, pass: node.intelamt.pass }); }

                return;
            }
            
            // If Intel AMT direct connection is possible, option a direct socket
            if ((conn & 4) != 0)
            {   // We got a new web socket connection, initiate a TCP connection to the target Intel AMT host/port.
                Debug(2, 'Opening relay TCP socket connection to ' + req.query.host + '.');
                
                // Compute target port
                var port = 16992;
                if (node.intelamt.tls > 0) port = 16993; // This is a direct connection, use TLS when possible
                if (req.query.p == 2) port += 2;

                if (node.intelamt.tls == 0) {
                    // If this is TCP (without TLS) set a normal TCP socket
                    ws.forwardclient = new obj.net.Socket();
                    ws.forwardclient.setEncoding('binary');
                    ws.forwardclient.xstate = 0;
                    ws.forwardclient.forwardwsocket = ws;
                } else {
                    // If TLS is going to be used, setup a TLS socket
                    ws.forwardclient = obj.tls.connect(port, node.host, { secureProtocol: 'TLSv1_method', rejectUnauthorized: false }, function () {
                        // The TLS connection method is the same as TCP, but located a bit differently.
                        Debug(2, 'TLS connected to ' + node.host + ':' + port + '.');
                        if (ws.xpendingdata && ws.xpendingdata.length > 0) {
                            //console.log('TLS sending pending data: ' + ws.xpendingdata.length);
                            ws.forwardclient.write(ws.xpendingdata);
                            delete ws.xpendingdata;
                        }
                        ws.forwardclient.xstate = 1;
                    });
                    ws.forwardclient.setEncoding('binary');
                    ws.forwardclient.xstate = 0;
                    ws.forwardclient.forwardwsocket = ws;
                    ws.xpendingdata = '';
                }
                
                // When data is received from the web socket, forward the data into the associated TCP connection.
                // If the TCP connection is pending, buffer up the data until it connects.
                ws.on('message', function (msg) {
                    // Convert a buffer into a string, "msg = msg.toString('ascii');" does not work
                    var msg2 = "";
                    for (var i = 0; i < msg.length; i++) { msg2 += String.fromCharCode(msg[i]); }
                    msg = msg2;
                    if (ws.interceptor) { msg = ws.interceptor.processBrowserData(msg); } // Run data thru interceptor
                    if (ws.forwardclient == undefined || ws.forwardclient.xstate == 0) {
                        // TCP connection is pending, buffer up the data.
                        if (ws.xpendingdata) { ws.xpendingdata += msg; } else { ws.xpendingdata = msg; }
                    } else {
                        // Forward data to the associated TCP connection.
                        ws.forwardclient.write(new Buffer(msg, "ascii"));
                    }
                });
                
                // If the web socket is closed, close the associated TCP connection.
                ws.on('close', function (req) {
                    Debug(1, 'Closing relay web socket connection to ' + ws.upgradeReq.query.host + '.');
                    if (ws.forwardclient) { try { ws.forwardclient.destroy(); } catch (e) { } }
                });
                
                // When we receive data on the TCP connection, forward it back into the web socket connection.
                ws.forwardclient.on('data', function (data) {
                    if (ws.interceptor) { data = ws.interceptor.processAmtData(data); } // Run data thru interceptor
                    try { ws.send(data); } catch (e) { }
                });
                
                // If the TCP connection closes, disconnect the associated web socket.
                ws.forwardclient.on('close', function () {
                    Debug(1, 'TCP relay disconnected from ' + node.host + '.');
                    try { ws.close(); } catch (e) { }
                });
                
                // If the TCP connection causes an error, disconnect the associated web socket.
                ws.forwardclient.on('error', function (err) {
                    Debug(1, 'TCP relay error from ' + node.host + ': ' + err.errno);
                    try { ws.close(); } catch (e) { }
                });

                // Fetch Intel AMT credentials & Setup interceptor
                if (req.query.p == 1) { ws.interceptor = obj.interceptor.CreateHttpInterceptor({ host: node.host, port: port, user: node.intelamt.user, pass: node.intelamt.pass }); }
                else if (req.query.p == 2) { ws.interceptor = obj.interceptor.CreateRedirInterceptor({ user: node.intelamt.user, pass: node.intelamt.pass }); }
                
                if (node.intelamt.tls == 0) {
                    // A TCP connection to Intel AMT just connected, send any pending data and start forwarding.
                    ws.forwardclient.connect(port, node.host, function () {
                        Debug(1, 'TCP relay connected to ' + node.host + ':' + port + '.');
                        if (ws.xpendingdata && ws.xpendingdata.length > 0) {
                            //console.log('TCP sending pending data: ' + ws.xpendingdata.length);
                            ws.forwardclient.write(new Buffer(ws.xpendingdata, "ascii"));
                            delete ws.xpendingdata;
                        }
                        ws.forwardclient.xstate = 1;
                    });
                }
                return;
            }

        });
    }
    
    /*
    // Test
    obj.app.get('/test.json', function (req, res) {
        res.set({ 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache', 'Expires': '0', 'Content-Type': 'text/plain' });
        res.send('{ "glossary": { "title": "example glossary", "bob" : 5 } }');
    });
    */

    // Indicates we want to handle websocket requests on "/webrelay.ashx". This is the same URL as IIS making things simple, we can use the same web application for both IIS and Node.
    obj.app.get('/webrelay.ashx', function (req, res) { res.send('Websocket connection expected'); });
    obj.app.ws('/webrelay.ashx', obj.HandleRelayWebSocket);

    // Indicates we want to handle websocket requests on "/control.ashx".
    obj.wssessions = {};
	obj.app.ws('/control.ashx', function (ws, req) {
        try {
		    // Check if the user is logged in
		    if (!req.session || !req.session.userid) { try { ws.close(); } catch (e) { } return; }
            req.session.ws = ws; // Associate this websocket session with the web session
            req.session.ws.userid = req.session.userid;
            var user = obj.users[req.session.userid];

            // Add this web socket session to session list
            if (!obj.wssessions[user._id]) { obj.wssessions[user._id] = [ws]; } else { obj.wssessions[user._id].push(ws); }
            obj.parent.DispatchEvent(['*'], obj, { action: 'wssessioncount', username: user.name, count: obj.wssessions[user._id].length, nolog: 1 })

            // Handle events
            ws.HandleEventId = 'ws-' + user.name + '-' + ('' + Math.random()).substring(2);
            ws.HandleEvent = function (source, event) {
                try {
                    if (event == 'close') { req.session.destroy(); ws.close(); }
                    else if (event == 'resubscribe') { user.subscriptions = obj.subscribe(user._id, ws); }
                    else { ws.send(JSON.stringify({ action: 'event', event: event })); }
                } catch (e) { }
            }

            // Subscribe to events
            user.subscriptions = obj.subscribe(user._id, ws);

            // When data is received from the web socket
            ws.on('message', function (msg) {
                var user = obj.users[req.session.userid];
                var command = JSON.parse(msg.toString('utf8'))
                switch (command.action) {
                    case 'meshes':
                        {
                            // Request a list of all meshes this user as rights to
                            var links = [];
                            for (var i in user.links) { links.push(i); }
                            obj.db.GetAllIdsOfType(links, 'mesh', function (err, docs) { ws.send(JSON.stringify({ action: 'meshes', meshes: docs })); });

                            // Following line returns all nodes
                            //obj.db.GetAllType('mesh', function (err, docs) { ws.send(JSON.stringify({ action: 'meshes', meshes: docs })); });
                            break;
                        }
                    case 'nodes':
                        {
                            // Request a list of all meshes this user as rights to
                            var links = [];
                            for (var i in user.links) { links.push(i); }

                            // Request a list of all nodes
                            obj.db.GetAllTypeNoTypeFeildMeshFiltered(links, 'node', function (err, docs) {
                                var r = {};
                                for (var i in docs) {
                                    // Add the connection state
                                    var connectivity = parent.connectivityByNode[docs[i]._id];
                                    if (connectivity) docs[i].conn = connectivity;
                                    // Compress the meshid's
                                    var meshid = docs[i].meshid;
                                    if (!r[meshid]) { r[meshid] = []; }
                                    delete docs[i].meshid;
                                    r[meshid].push(docs[i]);
                                }
                                ws.send(JSON.stringify({ action: 'nodes', nodes: r }));
                            });
                            break;
                        }
                    case 'events':
                        {
                            // Send the list of events for this session
                            obj.db.GetEvents(user.subscriptions, function (err, docs) { if (err != null) return; ws.send(JSON.stringify({ action: 'events', events: docs })); });
                            break;
                        }
                    case 'clearevents':
                        {
                            // Delete all events
                            if (user.siteadmin != 0xFFFFFFFF) break;
                            obj.db.RemoveAllEvents();
                            obj.parent.DispatchEvent(['*', 'server-global'], obj, { action: 'clearevents', nolog: 1 })
                            break;
                        }
                    case 'users':
                        {
                            // Request a list of all users
                            if ((user.siteadmin & 2) == 0) break;
                            obj.db.GetAllTypeNoTypeFeild('user', function (err, docs) {
                                ws.send(JSON.stringify({ action: 'users', users: docs }));
                            });
                            break;
                        }
                    case 'wssessioncount':
                        {
                            // Request a list of all web socket session count
                            if ((user.siteadmin & 2) == 0) break;
                            var wssessions = {};
                            for (var i in obj.wssessions) { wssessions[i] = obj.wssessions[i].length; }
                            ws.send(JSON.stringify({ action: 'wssessioncount', wssessions: wssessions }));
                            break;
                        }
                    case 'deleteuser':
                        {
                            // Delete a user account
                            if ((user.siteadmin & 2) == 0) break;
                            var delusername = command.username, deluserid = command.userid, deluser = obj.users[deluserid];
                            if (deluser.siteadmin != undefined && deluser.siteadmin > 0 && user.siteadmin != 0xFFFFFFFF) break; // Need full admin to remote another administrator
                            obj.db.Remove(deluserid);
                            delete obj.users[deluserid];
                            obj.parent.DispatchEvent(['*', 'server-users'], obj, { etype: 'user', userid: deluserid, username: delusername, action: 'accountremove', msg: 'Account removed' })
                            obj.parent.DispatchEvent([userid], obj, 'close')
                            break;
                        }
                    case 'adduser':
                        {
                            // Add a new user account
                            if ((user.siteadmin & 2) == 0) break;
                            var newusername = command.username, newuserid = 'user-' + command.username.toLowerCase();
                            if (!obj.users[newuserid]) {
                                var newuser = { type: 'user', _id: newuserid, name: newusername, email: command.email, creation: Date.now() };
                                obj.users[newuserid] = newuser;
                                // Create a user, generate a salt and hash the password
                                obj.hash(command.pass, function (err, salt, hash) {
                                    if (err) throw err;
                                    newuser.salt = salt;
                                    newuser.hash = hash;
                                    obj.db.Set(newuser);
                                    var newuser2 = obj.common.Clone(newuser);
                                    delete newuser2.salt;
                                    delete newuser2.hash;
                                    obj.parent.DispatchEvent(['*', 'server-users'], obj, { etype: 'user', username: newusername, account: newuser2, action: 'accountcreate', msg: 'Account created, email is ' + command.email })
                                });
                            }
                            break;
                        }
                    case 'edituser':
                        {
                            // Edit a user account, may involve changing email or administrator permissions
                            if (((user.siteadmin & 2) != 0) || (user.name == command.name)) {
                                var chguserid = 'user-' + command.name.toLowerCase(), chguser = obj.users[chguserid], change = 0;
                                if (chguser) {
                                    if (command.email && chguser.email != command.email) { chguser.email = command.email; change = 1; }
                                    if ((user.siteadmin == 0xFFFFFFFF) && (command.siteadmin != undefined) && (chguser.siteadmin != command.siteadmin)) { chguser.siteadmin = command.siteadmin; change = 1 }
                                    if (change == 1) {
                                        obj.db.Set(chguser);
                                        obj.parent.DispatchEvent([chguser._id], obj, 'resubscribe');
                                        var chguser2 = obj.common.Clone(chguser);
                                        delete chguser2.salt;
                                        delete chguser2.hash;
                                        obj.parent.DispatchEvent(['*', 'server-users', user._id, chguser._id], obj, { etype: 'user', username: user.name, account: chguser2, action: 'accountchange', msg: 'Account changed: ' + command.name })
                                    }
                                }
                            }
                            break;
                        }
                    case 'createmesh':
                        {
                            // Create mesh
                            // TODO: Right now, we only create type 1 Agent-less Intel AMT mesh, or type 2 Agent mesh
                            if ((command.meshtype == 1) || (command.meshtype == 2)) {
                                // Create a type 1 agent-less Intel AMT mesh.
                                require('crypto').randomBytes(32, function (err, buf) {
                                    var meshid = 'mesh-' + buf.toString('hex').toUpperCase();
                                    var links = {}
                                    links[user._id] = { name: user.name, rights: 0xFFFFFFFF };
                                    obj.db.AddMesh(meshid, command.meshtype, command.meshname, command.desc, links);
                                    obj.parent.AddEventDispatch([meshid], ws);
                                    if (user.links == undefined) user.links = {};
                                    user.links[meshid] = { rights: 0xFFFFFFFF };
                                    user.subscriptions = obj.subscribe(user._id, ws);
                                    obj.db.Set(user);
                                    obj.parent.DispatchEvent(['*', meshid, user._id], obj, { etype: 'mesh', username: user.name, meshid: meshid, name: command.meshname, mtype: command.meshtype, desc: command.desc, action: 'createmesh', links: links, msg: 'Mesh created: ' + command.meshname })
                                });
                            }
                            break;
                        }
                    case 'deletemesh':
                        {
                            // Delete a mesh and all computers within it
                            obj.db.Get(command.meshid, function (err, meshes) {
                                if (meshes.length != 1) return;
                                var mesh = meshes[0];

                                // Check if this user has rights to do this
                                if (mesh.links[user._id] == undefined || mesh.links[user._id].rights != 0xFFFFFFFF) return;

                                // Remove all user links to this mesh
                                for (var i in meshes) {
                                    var links = meshes[i].links;
                                    for (var j in links) {
                                        var xuser = obj.users[j];
                                        delete xuser.links[meshes[i]._id];
                                        obj.db.Set(xuser);
                                        obj.parent.DispatchEvent([xuser._id], obj, 'resubscribe');
                                    }
                                }

                                obj.parent.RemoveEventDispatchId(command.meshid); // Remove all subscriptions to this mesh
                                obj.db.RemoveMesh(command.meshid); // Remove mesh from database
                                obj.parent.DispatchEvent(['*', command.meshid], obj, { etype: 'mesh', username: user.name, meshid: command.meshid, name: command.meshname, action: 'deletemesh', msg: 'Mesh deleted: ' + command.meshname })
                            });
                            break;
                        }
                    case 'editmesh':
                        {
                            // Change the name or description of a mesh
                            obj.db.Get(command.meshid, function (err, meshes) {
                                if (meshes.length != 1) return;
                                var mesh = meshes[0], change = '';

                                // Check if this user has rights to do this
                                if (mesh.links[user._id] == undefined || ((mesh.links[user._id].rights & 1) == 0)) return;

                                if (command.meshname && command.meshname != '' && command.meshname != mesh.name) { change = 'Mesh name changed from "' + mesh.name + '" to "' + command.meshname + '"'; mesh.name = command.meshname; }
                                if (command.desc != undefined && command.desc != mesh.desc) { if (change != '') change += ' and description changed'; else change += 'Mesh "' + mesh.name + '" description changed'; mesh.desc = command.desc; }
                                if (change != '') { obj.db.Set(mesh); obj.parent.DispatchEvent(['*', mesh._id, user._id], obj, { etype: 'mesh', username: user.name, meshid: mesh._id, name: mesh.name, mtype: mesh.mtype, desc: mesh.desc, action: 'meshchange', links: mesh.links, msg: change }) }
                            });
                            break;
                        }
                    case 'addmeshuser':
                        {
                            // Check if the user exists
                            var newuserid = 'user-' + command.username.toLowerCase(), newuser = obj.users[newuserid];
                            if (newuser == undefined) {
                                // TODO: Send error back, user not found.
                                break;
                            }

                            // Get mesh from database
                            obj.db.Get(command.meshid, function (err, meshes) {
                                if (meshes.length != 1) return;
                                var mesh = meshes[0];

                                // Check if this user has rights to do this
                                if (mesh.links[user._id] == undefined || ((mesh.links[user._id].rights & 2) == 0)) return;

                                // Add mesh to user
                                if (newuser.links == undefined) newuser.links = {};
                                newuser.links[command.meshid] = { rights: command.meshadmin };
                                obj.db.Set(newuser);
                                obj.parent.DispatchEvent([newuser._id], obj, 'resubscribe');

                                // Add a user to the mesh
                                mesh.links[newuserid] = { name: command.username, rights: command.meshadmin };
                                obj.db.Set(mesh);

                                // Notify mesh change
                                var change = 'Added user ' + command.username + ' to mesh ' + mesh.name;
                                obj.parent.DispatchEvent(['*', mesh._id, user._id, newuserid], obj, { etype: 'mesh', username: user.name, userid: command.userid, meshid: mesh._id, name: mesh.name, mtype: mesh.mtype, desc: mesh.desc, action: 'meshchange', links: mesh.links, msg: change })
                            });
                            break;
                        }
                    case 'removemeshuser':
                        {
                            // Check if the user exists
                            var deluserid = command.userid, deluser = obj.users[deluserid];
                            if (deluser == undefined) {
                                // TODO: Send error back, user not found.
                                break;
                            }

                            // Get mesh from database
                            obj.db.Get(command.meshid, function (err, meshes) {
                                if (meshes.length != 1) return;
                                var mesh = meshes[0];

                                // Check if this user has rights to do this
                                if (mesh.links[user._id] == undefined || ((mesh.links[user._id].rights & 2) == 0)) return;

                                // Remove mesh from user
                                if (deluser.links != undefined && deluser.links[command.meshid] != undefined) {
                                    var delmeshrights = deluser.links[command.meshid].rights;
                                    if ((delmeshrights == 0xFFFFFFFF) && (mesh.links[user._id].rights != 0xFFFFFFFF)) return; // A non-admin can't kick out an admin
                                    delete deluser.links[command.meshid];
                                    obj.db.Set(deluser);
                                    obj.parent.DispatchEvent([deluser._id], obj, 'resubscribe');
                                }

                                // Remove user from the mesh
                                if (mesh.links[command.userid] != undefined) {
                                    delete mesh.links[command.userid];
                                    obj.db.Set(mesh);
                                }

                                // Notify mesh change
                                var change = 'Removed user ' + deluser.name + ' from mesh ' + mesh.name;
                                obj.parent.DispatchEvent(['*', mesh._id, user._id, command.userid], obj, { etype: 'mesh', username: user.name, userid: command.userid, meshid: mesh._id, name: mesh.name, mtype: mesh.mtype, desc: mesh.desc, action: 'meshchange', links: mesh.links, msg: change })
                            });
                            break;
                        }
                    case 'addamtdevice':
                        {
                            // Get the mesh
                            obj.db.Get(command.meshid, function (err, meshes) {
                                if (meshes.length != 1) return;
                                var mesh = meshes[0];

                                // Check if this user has rights to do this
                                if (mesh.links[user._id] == undefined || ((mesh.links[user._id].rights & 4) == 0)) return;

                                // Create a new nodeid
                                require('crypto').randomBytes(32, function (err, buf) {
                                    // create the new node
                                    var nodeid = 'node-' + buf.toString('hex').toUpperCase();
                                    var device = { type: 'node', mtype: 1, _id: nodeid, meshid: command.meshid, name: command.devicename, host: command.hostname, intelamt: { user: command.amtusername, pass: command.amtpassword, tls: parseInt(command.amttls) } };
                                    obj.db.Set(device);

                                    // Event the new node
                                    var device2 = obj.common.Clone(device);
                                    delete device2.intelamt.pass; // Remove the Intel AMT password before eventing this.
                                    var change = 'Added device ' + command.devicename + ' to mesh ' + mesh.name;
                                    obj.parent.DispatchEvent(['*', command.meshid], obj, { etype: 'node', username: user.name, action: 'addnode', node: device2, msg: change })
                                });
                            });
                            break;
                        }
                    case 'removedevice':
                        {
                            // Get the device
                            obj.db.Get(command.nodeid, function (err, nodes) {
                                if (nodes.length != 1) return;
                                var node = nodes[0];

                                // Get the mesh for this device
                                obj.db.Get(node.meshid, function (err, meshes) {
                                    if (meshes.length != 1) return;
                                    var mesh = meshes[0];

                                    // Check if this user has rights to do this
                                    if (mesh.links[user._id] == undefined || ((mesh.links[user._id].rights & 4) == 0)) return;

                                    // Delete this node
                                    obj.db.Remove(node._id);

                                    // Event node deletion
                                    var change = 'Removed device ' + node.name + ' from mesh ' + mesh.name;
                                    obj.parent.DispatchEvent(['*', node.meshid], obj, { etype: 'node', username: user.name, action: 'removenode', nodeid: node._id, msg: change })
                                });
                            });
                            break;
                        }
                    case 'changedevice':
                        {
                            // Change the device
                            obj.db.Get(command.nodeid, function (err, nodes) {
                                if (nodes.length != 1) return;
                                var node = nodes[0];

                                // Get the mesh for this device
                                obj.db.Get(node.meshid, function (err, meshes) {
                                    if (meshes.length != 1) return;
                                    var mesh = meshes[0];

                                    // Check if this user has rights to do this
                                    if (mesh.links[user._id] == undefined || ((mesh.links[user._id].rights & 4) == 0)) return;

                                    // Ready the node change event
                                    var changes = [], change = 0, event = { etype: 'node', username: user.name, action: 'changenode', nodeid: node._id };
                                    event.msg =  + ": ";

                                    // Look for a change
                                    if (command.icon && (command.icon != node.icon)) { change = 1; node.icon = command.icon; changes.push('icon'); }
                                    if (command.name && (command.name != node.name)) { change = 1; node.name = command.name; changes.push('name'); }
                                    if (command.host && (command.host != node.host)) { change = 1; node.host = command.host; changes.push('host'); }
                                    if (command.desc != undefined && (command.desc != node.desc)) { change = 1; node.desc = command.desc; changes.push('description'); }
                                    if ((command.intelamt != undefined) && (node.intelamt != undefined)) {
                                        if ((command.intelamt.user != undefined) && (command.intelamt.pass != undefined) && ((command.intelamt.user != node.intelamt.user) || (command.intelamt.pass != node.intelamt.pass))) { change = 1; node.intelamt.user = command.intelamt.user; node.intelamt.pass = command.intelamt.pass; changes.push('Intel AMT credentials'); }
                                        if (command.intelamt.tls && (command.intelamt.tls != node.intelamt.tls)) { change = 1; node.intelamt.tls = command.intelamt.tls; changes.push('Intel AMT TLS'); }
                                    }

                                    if (change == 1) {
                                        // Save the node
                                        obj.db.Set(node);

                                        // Event the node change
                                        event.msg = 'Changed device ' + node.name + ' from mesh ' + mesh.name + ': ' + changes.join(', ');
                                        var node2 = obj.common.Clone(node);
                                        if (node2.intelamt && node2.intelamt.pass) delete node2.intelamt.pass; // Remove the Intel AMT password before eventing this.
                                        event.node = node2;
                                        obj.parent.DispatchEvent(['*', node.meshid], obj, event);
                                    }
                                });
                            });
                            break;
                        }
                    case 'close':
                        {
                            // Close the web socket session
					        if (req.session && req.session.ws && req.session.ws == ws) delete req.session.ws;
                            try { ws.close(); } catch (e) { }
                            break;
                        }
                }
            });

            // If the web socket is closed
            ws.on('close', function (req) {
                obj.parent.RemoveAllEventDispatch(ws);
                if (req.session && req.session.ws && req.session.ws == ws) delete req.session.ws;
                if (obj.wssessions[ws.userid]) {
                    var i = obj.wssessions[ws.userid].indexOf(ws);
                    if (i >= 0) {
                        obj.wssessions[ws.userid].splice(i, 1);
                        var user = obj.users[ws.userid];
                        obj.parent.DispatchEvent(['*'], obj, { action: 'wssessioncount', username: user.name, count: obj.wssessions[ws.userid].length, nolog:1 })
                        if (obj.wssessions[ws.userid].length == 0) { delete obj.wssessions[ws.userid]; }
                    }
                }
            });

		    // Send user information to web socket, this is the first thing we send
		    var userinfo = obj.common.Clone(obj.users[req.session.userid]);
		    delete userinfo.salt;
		    delete userinfo.hash;
            ws.send(JSON.stringify({ action: 'userinfo', userinfo: userinfo }));

            // Next, send server information
            ws.send(JSON.stringify({ action: 'serverinfo', serverinfo: { name: certificates.CommonName, mpsport: obj.args.mpsport } }));
        } catch (e) { console.log(e); }
    });
    
    // Receive mesh agent connections
    obj.app.ws('/agent.ashx', function (ws, req) {
        try { CreateMeshAgent(obj, obj.db, ws, obj.args); } catch (e) { console.log(e); }
    });

    // Find a free port starting with the specified one and going up.
    function CheckListenPort(port, func) {
        var s = obj.net.createServer(function (socket) { });
        s.listen(port, function () { s.close(function () { if (func) { func(port); } }); }).on('error', function (err) { if (port < 65535) { CheckListenPort(port + 1, func); } else { if (func) { func(0); } } });
    }

    // Start the ExpressJS web server
    function StartWebServer(port) {
        if (port == 0) return;
        if (obj.tlsServer != null) {
            obj.tlsServer.listen(port, function () { console.log('MeshCentral HTTPS web server running on ' + certificates.CommonName + ':' + port + '.'); });
        } else {
            obj.app.listen(port, function () { console.log('MeshCentral HTTP redirection web server running on port ' + port + '.'); });
        }
    }
    
    // Debug
    function Debug(lvl) {
        if (lvl > obj.parent.debugLevel) return;
        if (arguments.length == 2) { console.log(arguments[1]); }
        else if (arguments.length == 3) { console.log(arguments[1], arguments[2]); }
        else if (arguments.length == 4) { console.log(arguments[1], arguments[2], arguments[3]); }
        else if (arguments.length == 5) { console.log(arguments[1], arguments[2], arguments[3], arguments[4]); }
        else if (arguments.length == 6) { console.log(arguments[1], arguments[2], arguments[3], arguments[4], arguments[5]); }
        else if (arguments.length == 7) { console.log(arguments[1], arguments[2], arguments[3], arguments[4], arguments[5], arguments[6]); }
    }

    // Start server on a free port
    CheckListenPort(obj.args.port, StartWebServer);

    return obj;
}
