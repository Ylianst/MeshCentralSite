/**
* @description Certificate generator
* @author Joko Sastriawan / Ylian Saint-Hilaire
* @version v0.0.1
*/
module.exports.CertificateOperations = function () {
    var obj = {};

    obj.fs = require('fs');
    obj.forge = require('node-forge');
    obj.pki = obj.forge.pki;
    obj.dirExists = function (filePath) { try { return obj.fs.statSync(filePath).isDirectory(); } catch (err) { return false; } }
    obj.getFilesizeInBytes = function(filename) { try { return obj.fs.statSync(filename)["size"]; } catch (err) { return -1; } }
    obj.fileExists = function(filePath) { try { return obj.fs.statSync(filePath).isFile(); } catch (err) { return false; } }
    
    // Create a demonstration self-signed certificate
    obj.GenerateRootCertificate = function (commonName, country, organization) {
        var keys = obj.pki.rsa.generateKeyPair(2048);
        var cert = obj.pki.createCertificate();
        cert.publicKey = keys.publicKey;
        cert.serialNumber = '' + Math.floor((Math.random() * 100000) + 1); ;
        cert.validity.notBefore = new Date();
        cert.validity.notBefore.setFullYear(cert.validity.notBefore.getFullYear() - 1); // Create a certificate that is valid one year before, to make sure out-of-sync clocks don't reject this cert.
        cert.validity.notAfter = new Date();
        cert.validity.notAfter.setFullYear(cert.validity.notAfter.getFullYear() + 30);
        var thumbprint = obj.pki.getPublicKeyFingerprint(cert.publicKey, { encoding: 'hex' });

        var attrs = [
            { name: 'commonName', value: commonName + '-' + thumbprint.substring(0, 6) },
            { name: 'countryName', value: country },
            { name: 'organizationName', value: organization }
        ];
        cert.setSubject(attrs);
        cert.setIssuer(attrs);
        cert.setExtensions([
            { name: 'basicConstraints', cA: true },
            {
                name: 'nsCertType',
                client: false,
                server: false,
                email: false,
                objsign: false,
                sslCA: true,
                emailCA: false,
                objCA: true
            }
        ]);
        cert.sign(keys.privateKey, obj.forge.md.sha256.create());

        return { cert: cert, key: keys.privateKey };
    }
    
    // Create a demonstration self-signed certificate
    obj.IssueWebServerCertificate = function (rootcert, commonName, country, organization) {
        var keys = obj.pki.rsa.generateKeyPair(2048);
        var cert = obj.pki.createCertificate();
        cert.publicKey = keys.publicKey;
        cert.serialNumber = '' + Math.floor((Math.random() * 100000) + 1); ;
        cert.validity.notBefore = new Date();
        cert.validity.notBefore.setFullYear(cert.validity.notAfter.getFullYear() - 1); // Create a certificate that is valid one year before, to make sure out-of-sync clocks don't reject this cert.
        cert.validity.notAfter = new Date();
        cert.validity.notAfter.setFullYear(cert.validity.notAfter.getFullYear() + 30);
        var attrs = [
            { name: 'commonName', value: commonName },
            { name: 'countryName', value: country },
            { name: 'organizationName', value: organization }
        ];
        cert.setSubject(attrs);
        cert.setIssuer(rootcert.cert.subject.attributes);
        
        cert.setExtensions([{
                name: 'basicConstraints',
                cA: false
            }, {
                name: 'keyUsage',
                keyCertSign: true,
                digitalSignature: true,
                nonRepudiation: true,
                keyEncipherment: true,
                dataEncipherment: true
            }, {
                name: 'extKeyUsage',
                serverAuth: true,
                clientAuth: false,
                codeSigning: false,
                emailProtection: false,
                timeStamping: false
            }, {
                name: 'nsCertType',
                client: false,
                server: true,
                email: false,
                objsign: false,
                sslCA: false,
                emailCA: false,
                objCA: false
            }, {
                name: 'subjectAltName',
                altNames: [{
                        type: 6, // URI
                        value: 'http://' + commonName + '/'
                    }, {
                        type: 6, // URL
                        value: 'http://localhost/'
                    }]
            }, {
                name: 'subjectKeyIdentifier'
            }]);
        
        cert.sign(rootcert.key, obj.forge.md.sha256.create());
        
        return { cert: cert, key: keys.privateKey };
    }

    // Returns the web server TLS certificate and private key, if not present, create demonstration ones.
    obj.GetMeshServerCertificate = function (directory, certargs) {
        // commonName, country, organization
        
        // If the certificates directory does not exist, create it.
        if (!obj.dirExists(directory)) { obj.fs.mkdirSync(directory); }
        
        var r = {}, rcount = 0;
        
        // If the root certificate already exist, load it
        if (obj.fileExists(directory + '/root-cert-public.crt') && obj.fileExists(directory + '/root-cert-private.key')) {
            var rootCertificate = obj.fs.readFileSync(directory + '/root-cert-public.crt', 'utf8');
            var rootPrivateKey = obj.fs.readFileSync(directory + '/root-cert-private.key', 'utf8');
            r.root = { cert: rootCertificate, key: rootPrivateKey };
            rcount++;
        }
        
        // If the web certificate already exist, load it
        if (obj.fileExists(directory + '/webserver-cert-public.crt') && obj.fileExists(directory + '/webserver-cert-private.key')) {
            var webCertificate = obj.fs.readFileSync(directory + '/webserver-cert-public.crt', 'utf8');
            var webPrivateKey = obj.fs.readFileSync(directory + '/webserver-cert-private.key', 'utf8');
            r.web = { cert: webCertificate, key: webPrivateKey };
            rcount++;
        }
        
        // If the bin certificate already exist, load it
        if (obj.fileExists(directory + '/mpsserver-cert-public.crt') && obj.fileExists(directory + '/mpsserver-cert-private.key')) {
            var mpsCertificate = obj.fs.readFileSync(directory + '/mpsserver-cert-public.crt', 'utf8');
            var mpsPrivateKey = obj.fs.readFileSync(directory + '/mpsserver-cert-private.key', 'utf8');
            r.mps = { cert: mpsCertificate, key: mpsPrivateKey };
            rcount++;
        }
        
        // Decode certificate arguments
        var commonName = 'sample.org', country = 'us', organization = 'unknown';
        if (certargs != undefined) {
            var args = certargs.split(',');
            if (args.length > 0) commonName = args[0];
            if (args.length > 1) country = args[1];
            if (args.length > 2) organization = args[2];
        }
        
        if (rcount == 3) {
            // Fetch the name of the server
            var webCertificate = obj.pki.certificateFromPem(r.web.cert);
            r.CommonName = webCertificate.subject.getField('CN').value;
            var rootCertificate = obj.pki.certificateFromPem(r.root.cert);
            r.RootName = rootCertificate.subject.getField('CN').value;
            if (certargs == undefined) return r; // If no certificate arguments are given, keep the certificate
            var xcountry = webCertificate.subject.getField('C').value;
            var xorganization = webCertificate.subject.getField('O').value;
            if ((r.CommonName == commonName) && (xcountry == country) && (xorganization == organization)) return r; // If the certificate matches what we want, keep it.
        }
        console.log('Generating certificates...');
        
        var rootCertAndKey, rootCertificate, rootPrivateKey, rootName;
        if (r.root == undefined) {
            // If the root certificate does not exist, create one
            rootCertAndKey = obj.GenerateRootCertificate('MeshCentralRoot', country, organization);
            rootCertificate = obj.pki.certificateToPem(rootCertAndKey.cert);
            rootPrivateKey = obj.pki.privateKeyToPem(rootCertAndKey.key);
            obj.fs.writeFileSync(directory + '/root-cert-public.crt', rootCertificate);
            obj.fs.writeFileSync(directory + '/root-cert-private.key', rootPrivateKey);
        } else {
            // Keep the root certificate we have
            rootCertAndKey = { cert: obj.pki.certificateFromPem(r.root.cert), key: obj.pki.privateKeyFromPem(r.root.key) };
            rootCertificate = r.root.cert
            rootPrivateKey = r.root.key
        }
        var rootName = rootCertAndKey.cert.subject.getField('CN').value;

        // If the web certificate does not exist, create a demonstration one
        var webCertAndKey = obj.IssueWebServerCertificate(rootCertAndKey, commonName, country, organization);
        var webCertificate = obj.pki.certificateToPem(webCertAndKey.cert);
        var webPrivateKey = obj.pki.privateKeyToPem(webCertAndKey.key);
        obj.fs.writeFileSync(directory + '/webserver-cert-public.crt', webCertificate);
        obj.fs.writeFileSync(directory + '/webserver-cert-private.key', webPrivateKey);
        
        // If the binary certificate does not exist, create a demonstration one
        var mpsCertAndKey = obj.IssueWebServerCertificate(rootCertAndKey, commonName, country, organization);
        var mpsCertificate = obj.pki.certificateToPem(mpsCertAndKey.cert);
        var mpsPrivateKey = obj.pki.privateKeyToPem(mpsCertAndKey.key);
        obj.fs.writeFileSync(directory + '/mpsserver-cert-public.crt', mpsCertificate);
        obj.fs.writeFileSync(directory + '/mpsserver-cert-private.key', mpsPrivateKey);
        
        return { root: { cert: rootCertificate, key: rootPrivateKey }, web: { cert: webCertificate, key: webPrivateKey }, mps: { cert: mpsCertificate, key: mpsPrivateKey }, CommonName: commonName, RootName : rootName };
    }

    return obj;
};
