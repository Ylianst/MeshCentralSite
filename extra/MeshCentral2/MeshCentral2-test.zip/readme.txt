Meshcentral 2.0 Alpha 2
-----------------------

This software is licensed under Apache 2.0 license. This is a version of MeshCentral that is completely built using NodeJS. It's simpler, runs on anything that node runs on and includes many other design improvements over the original MeshCentral C# code base. This is early software, preview quality at best.

To getting started, type:

	node meshcentral

Command line arguments:

	--notls				Use HTTP instead of HTTPS for the main web server
	--port [number]			Web server port number
	--mpsport [number]		Intel AMT server port number
	--redirport [number]		Creates an additional HTTP server to redirect users to the HTTPS server.
	--cert [name],(country),(org)	Create a web server certificate with [name] server name. Country and organization can optionaly be set.

