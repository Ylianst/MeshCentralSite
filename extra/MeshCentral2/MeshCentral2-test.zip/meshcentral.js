/**
* @description Meshcentral
* @author Ylian Saint-Hilaire
* @version v0.0.1
*/

function CreateMeshCentralServer(args) {
    var obj = {};
    obj.db;
    obj.webserver;
    obj.redirserver;
    obj.mpsserver;
    obj.eventsDispatch = {};
    obj.args = require('minimist')(process.argv.slice(2));
    obj.certificates = null;
    obj.connectivityByMesh = {}; // This object keeps a list of all connected CIRA and agents, by meshid->nodeid->value (value: 1 = Agent, 2 = CIRA, 4 = AmtDirect)
    obj.connectivityByNode = {}; // This object keeps a list of all connected CIRA and agents, by nodeid->value (value: 1 = Agent, 2 = CIRA, 4 = AmtDirect)
    obj.debugLevel = 0;
    
    // Start the Meshcentral server
    obj.Start = function () {
        try { require('./pass').hash('test', function () { }); } catch (e) { console.log('Old version of node, must upgrade.'); return; } // TODO: Note sure if this test works or not.
        if ((obj.args.help == true) || (obj.args['?'] == true)) {
            console.log('MeshCentral2 Alpha 2, a web-based remote computer management web portal.\r\n');
            console.log('   --notls                           Use HTTP instead of HTTPS for the main web server');
            console.log('   --user [username]                 Always login as [username] if account exists');
            console.log('   --port [number]                   Web server port number');
            console.log('   --mpsport [number]                Intel AMT server port number');
            console.log('   --redirport [number]              Creates an additional HTTP server to redirect users to the HTTPS server.');
            console.log('   --cert [name], (country), (org)   Create a web server certificate with [name]server name,');
            console.log('                                     country and organization can optionaly be set.');
            return;
        }

        if (obj.args.port == undefined || typeof obj.args.port != 'number') { if (obj.args.notls == undefined) { obj.args.port = 443; } else { obj.args.port = 80; } }
        if (obj.args.mpsport == undefined || typeof obj.args.mpsport != 'number') obj.args.mpsport = 4433;
        if (obj.args.notls == undefined && obj.args.redirport == undefined) obj.args.redirport = 80;
        if (typeof obj.args.debug == 'number') obj.debugLevel = obj.args.debug;
        if (obj.args.debug == true) obj.debugLevel = 1;
        obj.db = require('./db.js').CreateDB(obj.args);
        
        // Load server certificates
        var certOperations = require('./certoperations.js').CertificateOperations();
        obj.certificates = certOperations.GetMeshServerCertificate('./data', obj.args.cert);
        
        // Setup and start the web server
        if (obj.args.secret) {
            // This secret is used to encrypt HTTP session information, if specified, user it.
            obj.webserver = require('./webserver.js').CreateWebServer(obj, obj.db, obj.args, obj.args.secret, obj.certificates);
        } else {
            // If the secret is not specified, generate a random number.
            require('crypto').randomBytes(32, function (err, buf) { obj.webserver = require('./webserver.js').CreateWebServer(obj, obj.db, obj.args, buf.toString('hex').toUpperCase(), obj.certificates); });
        }
        
        // Setup and start the redirection server if needed
        if (obj.args.redirport != undefined && typeof obj.args.redirport == 'number') {
            obj.webserver = require('./redirserver.js').CreateRedirServer(obj, obj.db, obj.args, obj.certificates);
        }

        // Setup and start the MPS server
        obj.mpsserver = require('./mpsserver.js').CreateMpsServer(obj, obj.db, obj.args, obj.certificates);
        
        // Dispatch an event that the server is now running
        obj.DispatchEvent(['*'], obj, { etype: 'server', action: 'started', msg: 'Server started' })

        Debug(1, 'Server started');
    }

    // Stop the Meshcentral server
    obj.Stop = function () {
        // Dispatch an event saying the server is now stopping
        obj.DispatchEvent(['*'], obj, { etype: 'server', action: 'stopped', msg: 'Server stopped' })
        if (obj.webserver) { delete obj.webserver; }
        if (obj.mpsserver) { delete obj.mpsserver; }

        Debug(1, 'Server stopped');
    }

    // Event Dispatch
    obj.AddEventDispatch = function (ids, target) {
        Debug(3, 'AddEventDispatch', ids);
        for (var i in ids) { var id = ids[i]; if (!obj.eventsDispatch[id]) { obj.eventsDispatch[id] = [target]; } else { obj.eventsDispatch[id].push(target); } }
    }
    obj.RemoveEventDispatch = function (ids, target) {
        Debug(3, 'RemoveEventDispatch', id);
        for (var i in ids) { var id = ids[i]; if (obj.eventsDispatch[id]) { var j = obj.eventsDispatch[id].indexOf(target); if (j >= 0) { array.splice(j, 1); } } }
    }
    obj.RemoveEventDispatchId = function (id) {
        Debug(3, 'RemoveEventDispatchId', id);
        if (obj.eventsDispatch[id] != undefined) { delete obj.eventsDispatch[id]; }
    }
    obj.RemoveAllEventDispatch = function (target) {
        Debug(3, 'RemoveAllEventDispatch');
        for (var i in obj.eventsDispatch) { var j = obj.eventsDispatch[i].indexOf(target); if (j >= 0) { obj.eventsDispatch[i].splice(j, 1); } }
    }
    obj.DispatchEvent = function (ids, source, event) {
        Debug(3, 'DispatchEvent', ids);
        event.type = 'event';
        event.time = Date.now();
        event.ids = ids;
        if (!event.nolog) { obj.db.StoreEvent(ids, source, event); }
        var targets = {}; // List of targets we dispatched the event to, we don't want to dispatch to the same target twice.
        for (var j in ids) {
            var id = ids[j];
            if (obj.eventsDispatch[id]) {
                for (var i in obj.eventsDispatch[id]) {
                    if (targets[obj.eventsDispatch[id][i].HandleEventId] == undefined) { // Check if we already displatched to this target
                        //console.log('Dispatching to', obj.eventsDispatch[id][i].HandleEventId);
                        targets[obj.eventsDispatch[id][i].HandleEventId] = 1;
                        obj.eventsDispatch[id][i].HandleEvent(source, event);
                    }
                }
            }
        }
        delete targets;
    }
    
    // Debug
    function Debug(lvl) {
        if (lvl > obj.debugLevel) return;
        if (arguments.length == 2) { console.log(arguments[1]); }
        else if (arguments.length == 3) { console.log(arguments[1], arguments[2]); }
        else if (arguments.length == 4) { console.log(arguments[1], arguments[2], arguments[3]); }
        else if (arguments.length == 5) { console.log(arguments[1], arguments[2], arguments[3], arguments[4]); }
    }

    return obj;
}

function InstallModules(modules, func) {
    if (modules.length == 0) { func(); return; }
    InstallModule(modules.shift(), InstallModules, modules, func)
}

function InstallModule(modulename, func, tag1, tag2) {
    try {
        var module = require(modulename);
        delete module;
    } catch (e) {
        console.log('Installing ' + modulename + '...');
        var child_process = require('child_process');
        child_process.exec('npm install ' + modulename + ' --save', function (error, stdout, stderr) { func(tag1, tag2); return; });
        return;
    }
    func(tag1, tag2);
}

InstallModules(['nedb', 'https', 'express', 'minimist', 'node-forge', 'express-ws', 'compression', 'body-parser', 'connect-redis', 'express-session', 'express-handlebars'], function () { CreateMeshCentralServer().Start(); });
