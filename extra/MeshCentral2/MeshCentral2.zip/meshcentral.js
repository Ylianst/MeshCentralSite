/**
* @description Meshcentral
* @author Ylian Saint-Hilaire
* @version v0.0.1
*/

function CreateMeshCentralServer() {
    var obj = {};
    obj.db;
    obj.webserver;
    obj.redirserver;
    obj.mpsserver;
    obj.amtEventHandler;
    obj.eventsDispatch = {};
    obj.platform = require('os').platform();
    obj.args = require('minimist')(process.argv.slice(2));
    obj.common = require('./common.js');
    obj.certificates = null;
    obj.connectivityByMesh = {};    // This object keeps a list of all connected CIRA and agents, by meshid->nodeid->value (value: 1 = Agent, 2 = CIRA, 4 = AmtDirect)
    obj.connectivityByNode = {};    // This object keeps a list of all connected CIRA and agents, by nodeid->value (value: 1 = Agent, 2 = CIRA, 4 = AmtDirect)
    obj.debugLevel = 0;
    obj.config = {};                // Configuration file
    obj.dbconfig = {};              // Persistance values, loaded from database
    
    // Windows Specific Code, setup service and event log
    obj.service = null;
    obj.servicelog = null;
    if (obj.platform == 'win32') {
        var nodewindows = require('node-windows');
        obj.service = nodewindows.Service;
        var eventlogger = nodewindows.EventLogger;
        obj.servicelog = new eventlogger('MeshCentral');
    }
    
    // Start the Meshcentral server
    obj.Start = function () {
        try { require('./pass').hash('test', function () { }); } catch (e) { console.log('Old version of node, must upgrade.'); return; } // TODO: Note sure if this test works or not.
        
        // Check for invalid arguments
        var validArguments = ['_', 'notls', 'user', 'port', 'mpsport', 'redirport', 'cert', 'deletedomain', 'deletedefaultdomain', 'showusers', 'shownodes', 'showmeshes', 'showevents', 'help', 'exactports', 'install', 'uninstall', 'servicerun', 'start', 'stop', 'restart', 'debug'];
        for (var arg in obj.args) { if (validArguments.indexOf(arg.toLocaleLowerCase()) == -1) { console.log('Invalid argument "' + arg + '", use --help.'); return; } }
        
        if ((obj.args.help == true) || (obj.args['?'] == true)) {
            console.log('MeshCentral2 Alpha 3, a web-based remote computer management web portal.\r\n');
            if (obj.platform == 'win32') {
                console.log('Run as a Windows Service');
                console.log('   --install/uninstall               Install Meshcentral as a background service.');
                console.log('   --start/stop/restart              Control Meshcentral background service.');
                console.log('Run standalone, console application');
            }
            console.log('   --notls                           Use HTTP instead of HTTPS for the main web server.');
            console.log('   --user [username]                 Always login as [username] if account exists.');
            console.log('   --port [number]                   Web server port number.');
            console.log('   --mpsport [number]                Intel AMT server port number.');
            console.log('   --redirport [number]              Creates an additional HTTP server to redirect users to the HTTPS server.');
            console.log('   --exactports                      Server must run with correct ports or exit.');
            console.log('   --cert [name], (country), (org)   Create a web server certificate with [name]server name,');
            console.log('                                     country and organization can optionaly be set.');
            return;
        }
        
        // Check if we need to install, start, stop, remove ourself as a background service
        if ((obj.service != null) && ((obj.args.install == true) || (obj.args.uninstall == true) || (obj.args.start == true) || (obj.args.stop == true) || (obj.args.restart == true))) {
            var env = [], xenv = ['user', 'port', 'mpsport', 'redirport', 'exactport', 'debug'];
            for (var i in xenv) { if (obj.args[xenv[i]] != undefined) { env.push({ name: 'mesh' + xenv[i], value: obj.args[xenv[i]] }); } } // Set some args as service environement variables.
            var svc = new obj.service({ name: 'MeshCentral', description: 'MeshCentral Remote Management Server', script: process.argv[1] + '.js', env: env, wait: 2, grow: .5 });
            svc.on('install', function () { console.log('MeshCentral service installed.'); svc.start(); });
            svc.on('uninstall', function () { console.log('MeshCentral service uninstalled.'); process.exit(); });
            svc.on('start', function () { console.log('MeshCentral service started.'); process.exit(); });
            svc.on('stop', function () { console.log('MeshCentral service stopped.'); if (obj.args.stop) { process.exit(); } if (obj.args.restart) { console.log('Holding 5 seconds...'); setTimeout(function () { svc.start(); }, 5000); } });
            svc.on('alreadyinstalled', function () { console.log('MeshCentral service already installed.'); process.exit(); });
            svc.on('invalidinstallation', function () { console.log('Invalid MeshCentral service installation.'); process.exit(); });
            try {
                if (obj.args.install == true) { svc.install(); return; }
                else if (obj.args.uninstall == true) { svc.uninstall(); return; }
                else if (obj.args.start == true) { svc.start(); return; }
                else if (obj.args.stop == true || obj.args.restart == true) { svc.stop(); return; }
            } catch (e) { logException(e); }
        }
        
        obj.StartEx();
    }
    
    obj.StartEx = function () {
        // Read configuration file if present and change arguments.
        if (require('fs').existsSync('./data/config.json')) {
            // Load and validate the configuration file
            try { obj.config = require('./data/config.json'); } catch (e) { console.log('ERROR: Unable to parse ./data/config.json.'); return; }
            if (obj.config.domains == undefined) { obj.config.domains = {}; }
            for (var i in obj.config.domains) { if ((i.split('/').length > 1) || (i.split(' ').length > 1)) { console.log("ERROR: Error in config.json, domain names can't have spaces or /."); return; } }
            
            // Set the command line arguments to the config file if they are not present
            if (obj.config.settings) { for (var i in obj.config.settings) { if (obj.args[i] == undefined) obj.args[i] = obj.config.settings[i]; } }
        }
        
        // Read environment variables. For a subset of arguments, we allow them to be read from environment variables.
        var xenv = ['user', 'port', 'mpsport', 'redirport', 'exactport', 'debug'];
        for (var i in xenv) { if ((obj.args[xenv[i]] == undefined) && (process.env['mesh' + xenv[i]])) { obj.args[xenv[i]] = obj.common.toNumber(process.env['mesh' + xenv[i]]); } }
        
        // Validate the domains, this is used for multi-hosting
        if (obj.config.domains == undefined) { obj.config.domains = {}; }
        if (obj.config.domains[''] == undefined) { obj.config.domains[''] = { }; }
        var xdomains = {}; for (var i in obj.config.domains) { if (!obj.config.domains[i].title) { obj.config.domains[i].title = 'MeshCentral'; } if (!obj.config.domains[i].title2) { obj.config.domains[i].title2 = '2.0 Alpha 3'; } xdomains[i.toLowerCase()] = obj.config.domains[i]; } obj.config.domains = xdomains;
        var bannedDomains = ['public', 'private', 'images', 'scripts', 'styles', 'views']; // List of banned domains
        for (var i in obj.config.domains) { for (var j in bannedDomains) { if (i == bannedDomains[j]) { console.log("ERROR: Domain '" + i + "' is not allowed domain name in ./data/config.json."); return; } } }
        for (var i in obj.config.domains) { obj.config.domains[i].url = (i == '')?'/':('/' + i + '/'); obj.config.domains[i].id = i; }
        
        // Log passed arguments into Windows Service Log
        //if (obj.servicelog != null) { var s = ''; for (var i in obj.args) { if (i != '_') { if (s.length > 0) { s += ', '; } s += i + "=" + obj.args[i]; } } logInfoEvent('MeshServer started with arguments: ' + s); }

        // Look at passed in arguments
        if (obj.args.port == undefined || typeof obj.args.port != 'number') { if (obj.args.notls == undefined) { obj.args.port = 443; } else { obj.args.port = 80; } }
        if (obj.args.mpsport == undefined || typeof obj.args.mpsport != 'number') obj.args.mpsport = 4433;
        if (obj.args.notls == undefined && obj.args.redirport == undefined) obj.args.redirport = 80;
        if (typeof obj.args.debug == 'number') obj.debugLevel = obj.args.debug;
        if (obj.args.debug == true) obj.debugLevel = 1;
        obj.db = require('./db.js').CreateDB(obj.args);
        obj.db.SetupDatabase(function (dbversion) {
            // See if any database operations need to be completed
            if (obj.args.deletedomain) { obj.db.DeleteDomain(obj.args.deletedomain, function () { console.log('Deleted domain ' + obj.args.deletedomain + '.'); process.exit(); }); return; }
            if (obj.args.deletedefaultdomain) { obj.db.DeleteDomain('', function () { console.log('Deleted default domain.'); process.exit(); }); return; }
            if (obj.args.showusers) { obj.db.GetAllType('user', function (err, docs) { console.log(docs); process.exit(); }); return; }
            if (obj.args.shownodes) { obj.db.GetAllType('node', function (err, docs) { console.log(docs); process.exit(); }); return; }
            if (obj.args.showmeshes) { obj.db.GetAllType('mesh', function (err, docs) { console.log(docs); process.exit(); }); return; }
            if (obj.args.showevents) { obj.db.GetAllType('event', function (err, docs) { console.log(docs); process.exit(); }); return; }
            
            // Read or setup database configuration values
            obj.db.Get('dbconfig', function (err, dbconfig) {
                if (dbconfig.length == 1) { obj.dbconfig = dbconfig[0]; } else { obj.dbconfig = { _id: 'dbconfig', version: 1 }; }
                if (obj.dbconfig.amtWsEventSecret == undefined) { require('crypto').randomBytes(32, function (err, buf) { obj.dbconfig.amtWsEventSecret = buf.toString('hex'); obj.db.Set(obj.dbconfig); }); }
                
                // This is used by the user to create a username/password for a Intel AMT WSMAN event subscription
                if (obj.args.getwspass) {
                    if (obj.args.getwspass.length == 64) {
                        require('crypto').randomBytes(6, function (err, buf) {
                            while (obj.dbconfig.amtWsEventSecret == undefined) { process.nextTick(); }
                            var username = buf.toString('hex');
                            var nodeid = obj.args.getwspass;
                            var pass = require('crypto').createHash('sha256').update(username.toLowerCase() + ":" + nodeid.toUpperCase() + ":" + obj.dbconfig.amtWsEventSecret).digest("base64").substring(0, 12).split("/").join("x").split("\\").join("x");
                            console.log('--- Intel(r) AMT WSMAN eventing credentials ---');
                            console.log('Username: ' + username);
                            console.log('Password: ' + pass);
                            console.log('Argument: ' + nodeid.toLowerCase());
                            process.exit();
                        });
                    } else {
                        console.log('Invalid NodeID.');
                        process.exit();
                    }
                    return;
                }
                
                // Load server certificates
                var certOperations = require('./certoperations.js').CertificateOperations();
                obj.certificates = certOperations.GetMeshServerCertificate('./data', obj.args.cert);
                
                // Setup and start the web server
                require('crypto').randomBytes(32, function (err, buf) {
                    if (obj.args.secret) {
                        // This secret is used to encrypt HTTP session information, if specified, user it.
                        obj.webserver = require('./webserver.js').CreateWebServer(obj, obj.db, obj.args, obj.args.secret, obj.certificates);
                    } else {
                        // If the secret is not specified, generate a random number.
                        obj.webserver = require('./webserver.js').CreateWebServer(obj, obj.db, obj.args, buf.toString('hex').toUpperCase(), obj.certificates);
                    }
                    
                    // Setup and start the redirection server if needed
                    if (obj.args.redirport != undefined && typeof obj.args.redirport == 'number') {
                        obj.redirserver = require('./redirserver.js').CreateRedirServer(obj, obj.db, obj.args, obj.certificates);
                    }
                    
                    // Setup the Intel AMT event handler
                    obj.amtEventHandler = require('./amtevents.js').CreateAmtEventsHandler(obj);
                    
                    // Setup and start the MPS server
                    obj.mpsserver = require('./mpsserver.js').CreateMpsServer(obj, obj.db, obj.args, obj.certificates);
                    
                    // Dispatch an event that the server is now running
                    obj.DispatchEvent(['*'], obj, { etype: 'server', action: 'started', msg: 'Server started' })
                    
                    Debug(1, 'Server started');
                });
            });
        });
    }
    
    // Stop the Meshcentral server
    obj.Stop = function (restoreFile) {
        // Dispatch an event saying the server is now stopping
        obj.DispatchEvent(['*'], obj, { etype: 'server', action: 'stopped', msg: 'Server stopped' })
        
        if (restoreFile) {
            Debug(1, 'Server stopped, updating settings...');
            var fs = require('fs');
            var unzip = require('unzip');
            fs.createReadStream(restoreFile).pipe(unzip.Extract({ path: './data' }));
            setTimeout(function () { fs.unlinkSync(restoreFile); process.exit(); }, 2000)
        } else {
            Debug(1, 'Server stopped');
            process.exit();
        }
    }
    
    // Event Dispatch
    obj.AddEventDispatch = function (ids, target) {
        Debug(3, 'AddEventDispatch', ids);
        for (var i in ids) { var id = ids[i]; if (!obj.eventsDispatch[id]) { obj.eventsDispatch[id] = [target]; } else { obj.eventsDispatch[id].push(target); } }
    }
    obj.RemoveEventDispatch = function (ids, target) {
        Debug(3, 'RemoveEventDispatch', id);
        for (var i in ids) { var id = ids[i]; if (obj.eventsDispatch[id]) { var j = obj.eventsDispatch[id].indexOf(target); if (j >= 0) { array.splice(j, 1); } } }
    }
    obj.RemoveEventDispatchId = function (id) {
        Debug(3, 'RemoveEventDispatchId', id);
        if (obj.eventsDispatch[id] != undefined) { delete obj.eventsDispatch[id]; }
    }
    obj.RemoveAllEventDispatch = function (target) {
        Debug(3, 'RemoveAllEventDispatch');
        for (var i in obj.eventsDispatch) { var j = obj.eventsDispatch[i].indexOf(target); if (j >= 0) { obj.eventsDispatch[i].splice(j, 1); } }
    }
    obj.DispatchEvent = function (ids, source, event) {
        Debug(3, 'DispatchEvent', ids);
        event.type = 'event';
        event.time = Date.now();
        event.ids = ids;
        if (!event.nolog) { obj.db.StoreEvent(ids, source, event); }
        var targets = []; // List of targets we dispatched the event to, we don't want to dispatch to the same target twice.
        for (var j in ids) {
            var id = ids[j];
            if (obj.eventsDispatch[id]) {
                for (var i in obj.eventsDispatch[id]) {
                    if (targets.indexOf(obj.eventsDispatch[id][i]) == -1) { // Check if we already displatched to this target
                        targets.push(obj.eventsDispatch[id][i]);
                        obj.eventsDispatch[id][i].HandleEvent(source, event);
                    }
                }
            }
        }
        delete targets;
    }
    
    // Debug
    function Debug(lvl) {
        if (lvl > obj.debugLevel) return;
        if (arguments.length == 2) { console.log(arguments[1]); }
        else if (arguments.length == 3) { console.log(arguments[1], arguments[2]); }
        else if (arguments.length == 4) { console.log(arguments[1], arguments[2], arguments[3]); }
        else if (arguments.length == 5) { console.log(arguments[1], arguments[2], arguments[3], arguments[4]); }
    }
    
    // Logging funtions
    function logException(e) { e += ''; logErrorEvent(e); }
    function logInfoEvent(msg) { if (obj.servicelog != null) { obj.servicelog.info(msg); } console.log(msg); }
    function logWarnEvent(msg) { if (obj.servicelog != null) { obj.servicelog.warn(msg); } console.log(msg); }
    function logErrorEvent(msg) { if (obj.servicelog != null) { obj.servicelog.error(msg); } console.error(msg); }
    
    return obj;
}

function InstallModules(modules, func) {
    if (modules.length > 0) { InstallModule(modules.shift(), InstallModules, modules, func); } else { func(); }
}

function InstallModule(modulename, func, tag1, tag2) {
    try {
        var module = require(modulename);
        delete module;
    } catch (e) {
        console.log('Installing ' + modulename + '...');
        var child_process = require('child_process');
        child_process.exec('npm install ' + modulename + ' --save', function (error, stdout, stderr) {
            if (error != null) { console.log('ERROR: Unable to install missing package \'' + modulename + '\', make sure npm is installed.'); process.exit(); return; }
            func(tag1, tag2);
            return;
        });
        return;
    }
    func(tag1, tag2);
}

// Build the list of required modules
var modules = ['nedb', 'https', 'unzip', 'xmldom', 'express', 'archiver', 'minimist', 'multiparty', 'node-forge', 'express-ws', 'compression', 'body-parser', 'connect-redis', 'express-session', 'express-handlebars'];
if (require('os').platform() == 'win32') { modules.push("node-windows"); }

// Run as a command line, if we are not using service arguments, don't need to install the service package.
InstallModules(modules, function () { CreateMeshCentralServer().Start(); });