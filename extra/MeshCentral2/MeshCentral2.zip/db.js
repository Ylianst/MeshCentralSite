/** 
* @description Meshcentral database
* @author Ylian Saint-Hilaire
* @version v0.0.1
*/

// Construct Meshcentral database object
// https://github.com/louischatriot/nedb
module.exports.CreateDB = function (args, func) {
    var obj = {};    
    var Datastore = require('nedb');
    obj.ram = new Datastore();
    obj.ram.persistence.setAutocompactionInterval(3600);
    obj.file = new Datastore({ filename: './data/meshcentral.db', autoload: true });
    obj.file.persistence.setAutocompactionInterval(3600);
    
    obj.SetupDatabase = function (func) {
        // Load database schema version and check if we need to update
        obj.Get('SchemaVersion', function (err, docs) {
            var ver = 0;
            if (docs && docs.length == 1) { ver = docs[0].value; }

            // Upgrade schema 0 to schema 1
            if (ver == 0) {
                // Add the default domain to all users
                obj.GetAllType('user', function (err, docs) {
                    for (var id in docs) {
                        var oldid, changed = false;
                        if (docs[id].subscriptions) { delete docs[id].subscriptions; changed = true; }
                        if (docs[id].domain == undefined) {
                            docs[id].domain = '';
                            oldid = docs[id]._id;
                            docs[id]._id = 'user//' + docs[id]._id.substring(5);
                            changed = true;
                        }
                        if (docs[id].links) {
                            for (var linkid in docs[id].links) {
                                var linkid2 = 'mesh//' + linkid.substring(5);
                                docs[id].links[linkid2] = docs[id].links[linkid];
                                delete docs[id].links[linkid];
                            }
                        }
                        if (changed == true) {
                            if (oldid) obj.Remove(oldid);
                            obj.Set(docs[id]);
                        }
                    }
                    
                    // Add the default domain to all nodes
                    obj.GetAllType('node', function (err, docs) {
                        for (var id in docs) {
                            var oldid, changed = false;
                            if (docs[id].domain == undefined) {
                                docs[id].domain = '';
                                oldid = docs[id]._id;
                                docs[id]._id = 'node//' + docs[id]._id.substring(5);
                                docs[id].meshid = 'mesh//' + docs[id].meshid.substring(5);
                                changed = true;
                            }
                            if (changed == true) {
                                if (oldid) obj.Remove(oldid);
                                obj.Set(docs[id]);
                            }
                        }
                    });
                    
                    // Add the default domain to all meshes
                    obj.GetAllType('mesh', function (err, docs) {
                        for (var id in docs) {
                            var oldid, changed = false;
                            if (docs[id].domain == undefined) {
                                docs[id].domain = '';
                                oldid = docs[id]._id;
                                docs[id]._id = 'mesh//' + docs[id]._id.substring(5);
                                if (docs[id].links) {
                                    for (var linkid in docs[id].links) {
                                        var linkid2 = 'user//' + linkid.substring(5);
                                        docs[id].links[linkid2] = docs[id].links[linkid];
                                        delete docs[id].links[linkid];
                                    }
                                }
                                changed = true;
                            }
                            if (changed == true) {
                                if (oldid) obj.Remove(oldid);
                                obj.Set(docs[id]);
                            }
                        }
                    });
                    
                    // Add the default domain to all events
                    obj.GetAllType('event', function (err, docs) {
                        var changed = false;
                        for (var id in docs) {
                            var oldid;
                            changed = true;
                            if (docs[id].domain == undefined) {
                                docs[id].domain = '';
                                obj.Set(docs[id]);
                            }
                        }
                        
                        obj.Set({ _id: 'SchemaVersion', value: 1 });
                        ver = 1;
                        if (changed == true) { console.log('Upgraded database to version 1.'); }
                        func(ver);
                    });
                });

            } else { func(ver); }
        });
    }
    
    obj.Set = function (data) { obj.file.update({ _id: data._id }, data, { upsert: true }); }
    obj.Get = function (id, func) { obj.file.find({ _id: id }, func); }
    obj.GetAllTypeNoTypeFeild = function (type, domain, func) { obj.file.find({ type: type, domain: domain }, { type : 0 }, func); }
    obj.GetAllTypeNoTypeFeildMeshFiltered = function (meshes, domain, type, func) { obj.file.find({ type: type, domain: domain, meshid: { $in: meshes } }, { type : 0 }, func); }
    obj.GetAllType = function (type, func) { obj.file.find({ type: type }, func); }
    obj.GetAllIdsOfType = function (ids, domain, type, func) { obj.file.find({ type: type, domain: domain, _id: { $in: ids } }, func); }
    obj.Remove = function (id) { obj.file.remove({ _id: id }); }
    obj.StoreEvent = function (ids, source, event) { obj.file.insert(event); }
    obj.GetEvents = function (ids, domain, func) { obj.file.find({ type: 'event', domain: domain, ids: { $in: ids } }, { type : 0, _id : 0 }).sort({ time: -1 }).exec(func); }
    obj.RemoveMesh = function (id) { obj.file.remove({ mesh: id }, { multi: true }); obj.file.remove({ _id: id }); }
    obj.RemoveAllEvents = function (domain) { obj.file.remove({ type: 'event', domain: domain }, { multi: true }); }
    obj.MakeSiteAdmin = function (username, domain) { obj.Get('user/' + domain + '/' + username, function (err, docs) { if (docs.length == 1) { docs[0].siteadmin = 0xFFFFFFFF; obj.Set(docs[0]); } }); }
    obj.DeleteDomain = function (domain, func) { obj.file.remove({ domain: domain }, { multi: true }, func); }
    obj.SetUser = function(user) { var u = Clone(user); if (u.subscriptions) { delete u.subscriptions; } obj.Set(u); }
    obj.dispose = function () { for (var x in obj) { if (obj[x].close) { obj[x].close(); } delete obj[x]; } }

    function Clone(v) { return JSON.parse(JSON.stringify(v)); }

    return obj;
}