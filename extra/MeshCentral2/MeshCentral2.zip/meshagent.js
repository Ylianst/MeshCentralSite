/**
* @description Meshcentral MeshAgent
* @author Ylian Saint-Hilaire & Bryan Roe
* @version v0.0.1
*/

// Construct a MeshAgent object, called upon connection
module.exports.CreateMeshAgent = function (parent, db, ws, req, args, domain) {
    var obj = {};
    obj.parent = parent;
    obj.db = db;
    obj.ws = ws;
    obj.args = args;
    obj.nodeid = req.query.nodeid.toUpperCase();
    obj.meshid = req.query.meshid.toUpperCase();
    obj.dbNodeKey = 'node/' + domain.id + '/' + obj.nodeid;
    obj.dbMeshKey = 'mesh/' + domain.id + '/' + obj.meshid;
    
    // TODO: Start authenticate the mesh agent
    
    // Check that the mesh exists
    obj.db.Get(obj.dbMeshKey, function (err, meshes) {
        if (meshes.length == 0) { console.log('Agent connected with invalid domain/mesh'); try { obj.ws.close(); } catch (e) { } return; } 
        var mesh = meshes[0];
        if (mesh.mtype != 2) { console.log('Agent connected with invalid mesh type'); try { obj.ws.close(); } catch (e) { } return; } 

        // Check that the node exists    
        obj.db.Get(obj.dbNodeKey, function (err, nodes) {
            if (nodes.length == 0) {
                // This node does not exist, create it.
                var deviceName = 'Test' // TODO
                var device = { type: 'node', mtype: mesh.mtype, _id: obj.dbNodeKey, meshid: obj.dbMeshKey, name: deviceName, domain: domain.id, host: null };
                obj.db.Set(device);
                
                // Event the new node
                var change = 'Added device ' + deviceName + ' to mesh ' + mesh.name;
                obj.parent.parent.DispatchEvent(['*', obj.dbMeshKey], obj, { etype: 'node', action: 'addnode', node: device, msg: change, domain: domain.id })
            }
            
            // Check if this agent is already connected
            var dupAgent = obj.parent.wsagents[obj.dbNodeKey];
            obj.parent.wsagents[obj.dbNodeKey] = obj;
            if (dupAgent) {
                // Close the duplicate agent
                dupAgent.close();
            } else {
                // Indicate the agent is connected
                AddAgentConnectivityState(obj.dbMeshKey, obj.dbNodeKey);
            }

            // When data is received from the mesh agent web socket
            ws.on('message', function (msg) {
                //console.log('MeshAgent message, len = ' + msg.length);
                processAgentData(msg);
            });
            
            // If the mesh agent web socket is closed, clean up.
            ws.on('close', function (req) { obj.close(1); });
        });
    });
    
    function processAgentData(msg) {
        var str = msg.toString('utf8');
        if (str[0] == '{') {
            try { command = JSON.parse(str) } catch (e) { return; } // If the command can't be parsed, ignore it.
            switch (command.action) {
                case 'msg':
                    {
                        // Route a message.
                        // This this command has a sessionid, that is the target.
                        if (command.sessionid != undefined) {
                            var splitsessionid = command.sessionid.split('/');
                            // Check that we are in the same domain and the user has rights over this node.
                            if ((splitsessionid[0] == 'user') && (splitsessionid[1] == domain.id)) {
                                // Check if this user has rights to get this message
                                //if (mesh.links[user._id] == undefined || ((mesh.links[user._id].rights & 16) == 0)) return; // TODO!!!!!!!!!!!!!!!!!!!!!
                                
                                // See if the session is connected
                                var ws = obj.parent.wssessions2[command.sessionid];
                                
                                // Go ahead and send this message to the target node
                                if (ws != undefined) {
                                    command.nodeid = obj.dbNodeKey; // Set the nodeid, required for responses.
                                    delete command.sessionid;       // Remove the sessionid, since we are sending to that sessionid, so it's implyed.
                                    ws.send(JSON.stringify(command));
                                }
                            }
                        }
                        break;
                    }
            }
        }
    }

    // Send a message to the mesh agent
    obj.send = function (data) {
        obj.ws.send(data);
        //processAgentData(data); // DEBUG
    }
    
    // Disconnect this agent
    obj.close = function (arg) {
        //console.log('MeshAgent.close(' + arg + ')');
        if (arg !== 1) { obj.ws.close(); }
        if (obj.parent.wsagents[obj.dbNodeKey] == obj) {
            delete obj.parent.wsagents[obj.dbNodeKey];
            RemoveAgentConnectivityState(obj.dbMeshKey, obj.dbNodeKey);
        }
        // Other clean up may be needed here
    }
    
    function AddAgentConnectivityState(meshid, nodeid) {
        // Add the agent connection to the nodes connection list
        var eventConnectChange = 0;
        var connectivity = obj.parent.parent.connectivityByNode[nodeid];
        if (connectivity) {
            if ((connectivity & 1) == 0) {
                connectivity |= 1;
                obj.parent.parent.connectivityByNode[nodeid] = connectivity;
                eventConnectChange = 1;
            }
        } else {
            obj.parent.parent.connectivityByNode[nodeid] = connectivity = 1;
            eventConnectChange = 1;
        }
        
        if (eventConnectChange == 1) {
            // Add the connection to the mesh connection list
            if (!obj.parent.parent.connectivityByMesh[meshid]) { obj.parent.parent.connectivityByMesh[meshid] = {}; }
            obj.parent.parent.connectivityByMesh[meshid][nodeid] = connectivity;
            
            // Event the node connection change
            obj.parent.parent.DispatchEvent(['*', meshid], obj, { action: 'nodeconnect', meshid: meshid, nodeid: nodeid, conn: connectivity, nolog: 1 })
        }
    }
    
    function RemoveAgentConnectivityState(meshid, nodeid) {
        // Remove the agent connection from the nodes connection list
        var connectivity = obj.parent.parent.connectivityByNode[nodeid];
        if (connectivity && ((connectivity & 1) != 0)) {
            connectivity -= 1;
            if (connectivity != 0) {
                obj.parent.parent.connectivityByNode[nodeid] = connectivity;
                obj.parent.parent.connectivityByMesh[meshid][nodeid] = connectivity;
            } else {
                delete obj.parent.parent.connectivityByNode[nodeid];
                delete obj.parent.parent.connectivityByMesh[meshid][nodeid];
            }
            
            // Event the node connection change
            obj.parent.parent.DispatchEvent(['*', meshid], obj, { action: 'nodeconnect', meshid: meshid, nodeid: nodeid, conn: connectivity, nolog: 1 })
        }
    }

    return obj;
}
