/**
* @description Meshcentral web server
* @author Ylian Saint-Hilaire
* @version v0.0.1
*/

// ExpressJS login sample
// https://github.com/expressjs/express/blob/master/examples/auth/index.js

// Construct a HTTP redirection web server object
module.exports.CreateRedirServer = function (parent, db, args, certificates) {
    var obj = {};
    obj.parent = parent;
    obj.db = db;
    obj.args = args;
    obj.certificates = certificates;
    obj.express = require('express');
    obj.net = require('net');
    obj.app = obj.express();
    obj.tcpServer;
        
    // Perform an HTTP to HTTPS redirection
    function performRedirection(req, res) {
        if (req.headers && req.headers.host && (req.headers.host.split(':')[0].toLowerCase() == 'localhost')) { res.redirect('https://localhost:' + args.port + req.url); } else { res.redirect('https://' + certificates.CommonName + ':' + args.port + req.url); }
    }
    
    // Return the current domain of the request
    function getDomain(req) {
        var x = req.url.split('/');
        if (x.length < 2) return parent.config.domains[''];
        if (parent.config.domains[x[1].toLowerCase()]) return parent.config.domains[x[1].toLowerCase()];
        return parent.config.domains[''];
    }

    // Renter the terms of service.
    obj.app.get('/MeshServerRootCert.cer', function (req, res) {
        res.set({ 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache', 'Expires': '0', 'Content-Type': 'application/octet-stream', 'Content-Disposition': 'attachment; filename=' + certificates.RootName + '.cer' });
        var rootcert = obj.certificates.root.cert;
        var i = rootcert.indexOf("-----BEGIN CERTIFICATE-----\r\n");
        if (i >= 0) { rootcert = rootcert.substring(i + 29); }
        i = rootcert.indexOf("-----END CERTIFICATE-----");
        if (i >= 0) { rootcert = rootcert.substring(i, 0); }
        res.send(new Buffer(rootcert, 'base64'));
    });
    
    // Setup all HTTP redirection handlers
    //obj.app.set('etag', false);
    for (var i in parent.config.domains) {
        var url = parent.config.domains[i].url;
        obj.app.get(url, performRedirection);
        obj.app.post(url + 'amtevents.ashx', obj.parent.webserver.handleAmtEventRequest);
    }
    
    // Find a free port starting with the specified one and going up.
    function CheckListenPort(port, func) {
        var s = obj.net.createServer(function (socket) { });
        obj.tcpServer = s.listen(port, function () { s.close(function () { if (func) { func(port); } }); }).on('error', function (err) {
            if (args.exactports) { console.error('ERROR: MeshCentral HTTP web server port ' + port + ' not available.'); process.exit(); }
            else { if (port < 65535) { CheckListenPort(port + 1, func); } else { if (func) { func(0); } } }
        });
    }

    // Start the ExpressJS web server, if the port is busy try the next one.
    function StartRedirServer(port) {
        if (port == 0 || port == 65535) return;
        obj.args.redirport = port;
        obj.tcpServer = obj.app.listen(port, function () { console.log('MeshCentral HTTP redirection web server running on port ' + port + '.'); }).on('error', function (err) { if ((err.code == 'EACCES') && (port < 65535)) { StartRedirServer(port + 1); } else { console.log(err); } });
    }
    
    CheckListenPort(args.redirport, StartRedirServer);

    return obj;
}
