Meshcentral 2.0 Alpha 3
-----------------------

This software is licensed under Apache 2.0 license. This is a version of MeshCentral that is completely built using NodeJS. It's simpler, runs on anything that nodejs runs on and includes many other design improvements over the original MeshCentral C# code base. This is early software, preview quality at best.

If you are behind a proxy, first setup NodeJS to use the proxy:

	npm config set proxy http://proxy.company.com:8080
	npm config set https-proxy http://proxy.company.com:8080

Then, extract MeshCentral2 and run it like this:

	node meshcentral

Command line arguments on Windows only
   --install                         Install Meshcentral as a background service.
   --uninstall                       Uninstall Meshcentral background service.
   --start                           Start Meshcentral as a background service.
   --stop                            Stop Meshcentral background service.

Command line arguments on any platform
   --notls                           Use HTTP instead of HTTPS for the main web server.
   --user [username]                 Always login as [username] if account exists.
   --port [number]                   Web server port number.
   --mpsport [number]                Intel AMT server port number.
   --redirport [number]              Creates an additional HTTP server to redirect users to the HTTPS server.
   --exactports                      Server must run with correct ports or exit.
   --cert [name], (country), (org)   Create a web server certificate with [name]server name,
                                     country and organization can optionaly be set.

As an alternative to using command line arguments, you can create a ./data/config.json file, for example:

	{
	  "settings": {
	    "port": 8080,
	    "redirport": 81
	  },
	  "domains": {
	    "": {
	      "title": "MyServer",
	      "title2": "Servername"
	    },
	    "Customer1": {
	      "title": "Customer1",
	      "title2": "Extra String"
	    },
	    "Customer2": {
	      "title": "Customer2",
	      "title2": "Other String"
	    }
	  }
	}

The first "settings" part are just like the command line arguments. Instead of running with "--port 8080", you can put "port: 8080" in the settings portion of the config.json file. In addition, you can use the config.json file to create multi-tenancy servers. In the domains section, you can set the title for the root ("") domain in addition to creating new domains.

For the configuration above, the root domain will be accessible using:

	https://servername:8080/

And both other domains at:

	https://servername:8080/customer1
	https://servername:8080/customer2

When you setup many domains, the server host each domain seperatly. Each domain has seperate user accounts, administrators, etc.
